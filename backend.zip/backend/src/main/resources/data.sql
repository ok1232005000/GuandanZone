USE guandan;

INSERT INTO `user` (id, username, password, nickname, avatar) VALUES
(1, 'admin', '123456', '管理员', NULL),
(2, 'player1', '123456', '玩家1', NULL),
(3, 'player2', '123456', '玩家2', NULL),
(4, 'player3', '123456', '玩家3', NULL);

INSERT INTO room (id, room_no, status, creator_id) VALUES
(1, '8888', 0, 1);
