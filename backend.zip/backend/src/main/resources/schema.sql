CREATE DATABASE IF NOT EXISTS guandan CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE guandan;

CREATE TABLE `user` (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(100) NOT NULL COMMENT '密码',
    nickname VARCHAR(50) NOT NULL COMMENT '昵称',
    avatar VARCHAR(255) DEFAULT NULL COMMENT '头像',
    phone VARCHAR(20) DEFAULT NULL COMMENT '手机号',
    online TINYINT DEFAULT 0 COMMENT '在线状态:0-离线,1-在线',
    create_time DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户表';
ALTER TABLE `user` MODIFY COLUMN avatar LONGTEXT;
ALTER TABLE `user` ADD COLUMN deleted TINYINT DEFAULT 0 COMMENT '逻辑删除';

CREATE TABLE room (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    room_no VARCHAR(6) NOT NULL UNIQUE COMMENT '房间号',
    status TINYINT NOT NULL DEFAULT 0 COMMENT '状态:0-等待,1-游戏中,2-结束',
    creator_id BIGINT UNSIGNED NOT NULL COMMENT '创建者ID',
    level_team_a INT DEFAULT 2 COMMENT 'A队级别',
    level_team_b INT DEFAULT 2 COMMENT 'B队级别',
    current_trump_suit VARCHAR(20) DEFAULT NULL COMMENT '当前主牌花色',
    next_tribute_state VARCHAR(20) DEFAULT NULL COMMENT '下一把进贡状态',
    is_private TINYINT(1) DEFAULT 0 COMMENT '是否私密房间',
    config VARCHAR(500) DEFAULT NULL COMMENT '房间配置JSON',
    create_time DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='房间表';

CREATE TABLE game_record (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    room_id BIGINT UNSIGNED NOT NULL COMMENT '房间ID',
    winner_id BIGINT UNSIGNED DEFAULT NULL COMMENT '获胜者ID',
    score INT NOT NULL DEFAULT 0 COMMENT '分数',
    create_time DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) COMMENT '创建时间',
    INDEX idx_room_id (room_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='游戏记录表';

CREATE TABLE room_player (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    room_id BIGINT UNSIGNED NOT NULL COMMENT '房间ID',
    user_id BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    seat_index INT NOT NULL COMMENT '座位号',
    is_ready TINYINT DEFAULT 0 COMMENT '是否准备',
    card_count INT DEFAULT 0 COMMENT '手牌数量',
    update_time DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3) COMMENT '更新时间',
    UNIQUE KEY uk_room_user (room_id, user_id),
    INDEX idx_room_id (room_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='房间玩家表';

CREATE TABLE game_round (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    room_id BIGINT UNSIGNED NOT NULL COMMENT '房间ID',
    round_number INT NOT NULL COMMENT '回合数',
    winner_team TINYINT COMMENT '获胜队伍:1-A队,2-B队',
    start_time DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) COMMENT '开始时间',
    end_time DATETIME(3) DEFAULT NULL COMMENT '结束时间',
    tribute_record VARCHAR(500) DEFAULT NULL COMMENT '进贡记录JSON',
    INDEX idx_room_id (room_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='游戏回合表';

CREATE TABLE game_round_player (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    round_id BIGINT UNSIGNED NOT NULL COMMENT '回合ID',
    user_id BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    seat_index INT NOT NULL COMMENT '座位号',
    rank_order TINYINT COMMENT '排名:1-4',
    score_change INT DEFAULT 0 COMMENT '分数变化',
    highlights VARCHAR(500) DEFAULT NULL COMMENT '高光记录JSON',
    INDEX idx_round_id (round_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='回合玩家表';

CREATE TABLE user_stats (
    user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY COMMENT '用户ID',
    total_games INT DEFAULT 0 COMMENT '总场次',
    win_games INT DEFAULT 0 COMMENT '获胜场次',
    level_current INT DEFAULT 2 COMMENT '当前级别',
    max_bomb_rank VARCHAR(20) DEFAULT NULL COMMENT '最大炸弹等级'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户统计表';

CREATE TABLE tb_operation_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED DEFAULT NULL COMMENT '用户ID',
    username VARCHAR(50) DEFAULT NULL COMMENT '用户名',
    operation_type VARCHAR(50) DEFAULT NULL COMMENT '操作类型',
    operation_module VARCHAR(50) DEFAULT NULL COMMENT '操作模块',
    operation_desc VARCHAR(500) DEFAULT NULL COMMENT '操作描述',
    target_type VARCHAR(50) DEFAULT NULL COMMENT '目标类型',
    target_id BIGINT UNSIGNED DEFAULT NULL COMMENT '目标ID',
    request_ip VARCHAR(50) DEFAULT NULL COMMENT '请求IP',
    request_method VARCHAR(10) DEFAULT NULL COMMENT '请求方法',
    request_url VARCHAR(500) DEFAULT NULL COMMENT '请求URL',
    user_agent VARCHAR(500) DEFAULT NULL COMMENT '用户代理',
    response_status INT DEFAULT NULL COMMENT '响应状态',
    is_success TINYINT DEFAULT NULL COMMENT '是否成功:0-失败,1-成功',
    error_message VARCHAR(1000) DEFAULT NULL COMMENT '错误信息',
    execute_time DATETIME(3) DEFAULT NULL COMMENT '执行时间',
    create_time DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) COMMENT '创建时间',
    INDEX idx_user_id (user_id),
    INDEX idx_operation_type (operation_type),
    INDEX idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='操作日志表';
