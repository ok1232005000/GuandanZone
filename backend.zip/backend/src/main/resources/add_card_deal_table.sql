USE guandan;

CREATE TABLE game_card_deal (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    room_id BIGINT UNSIGNED NOT NULL COMMENT '房间ID',
    game_round_id BIGINT UNSIGNED DEFAULT NULL COMMENT '游戏回合ID',
    player_id VARCHAR(50) NOT NULL COMMENT '玩家ID',
    card_ids VARCHAR(255) NOT NULL COMMENT '发的卡牌ID列表，逗号分隔',
    deal_time DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) COMMENT '发牌时间',
    INDEX idx_room_id (room_id),
    INDEX idx_player_id (player_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='发牌记录表';