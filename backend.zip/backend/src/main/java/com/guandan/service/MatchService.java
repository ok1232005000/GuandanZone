package com.guandan.service;

import com.guandan.dto.NewGameRequest;
import com.guandan.game.service.GameLogicService;
import com.guandan.mapper.UserMapper;
import com.guandan.entity.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
public class MatchService {

    @Autowired
    private RoomCache roomCache;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private RoomService roomService;

    @Autowired
    private GameLogicService gameLogicService;

    public boolean joinMatchQueue(Long userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            return false;
        }

        roomCache.addToMatchQueue(userId);
        log.info("玩家 {} 加入匹配队列，当前队列人数: {}", userId, roomCache.getMatchQueueSize());
        
        // 检查是否可以匹配（异步执行）
        checkAndMatch();
        
        return true;
    }

    public boolean cancelMatch(Long userId) {
        roomCache.removeFromMatchQueue(userId);
        log.info("玩家 {} 取消匹配，当前队列人数: {}", userId, roomCache.getMatchQueueSize());
        return true;
    }

    public boolean isInMatchQueue(Long userId) {
        return roomCache.isInMatchQueue(userId);
    }

    public String getMatchResult(Long userId) {
        return roomCache.getMatchResult(userId);
    }

    /**
     * 检查匹配队列，如果达到4人则创建房间并匹配
     * 使用 synchronized 确保线程安全
     */
    public synchronized void checkAndMatch() {
        Set<Long> queue = roomCache.getMatchQueue();
        log.info("检查匹配队列，当前队列: {}, 队列大小: {}", queue, queue != null ? queue.size() : 0);

        if (queue == null || queue.size() < 4) {
            log.info("队列人数不足4人，当前: {}人，等待更多玩家...", queue != null ? queue.size() : 0);
            return;
        }

        // 取前4个玩家进行匹配
        List<Long> matchedPlayers = new ArrayList<>();
        int count = 0;
        for (Long playerId : queue) {
            if (count >= 4) {
                break;
            }
            matchedPlayers.add(playerId);
            count++;
        }

        log.info("从队列中提取玩家进行匹配: {}", matchedPlayers);

        if (matchedPlayers.size() == 4) {
            log.info("========== 开始匹配流程，4个玩家: {} ==========", matchedPlayers);

            try {
                // 创建房间（使用第一个玩家的ID作为创建者）
                NewGameRequest request = new NewGameRequest();
                request.setUserId(matchedPlayers.get(0));
                request.setIsPrivate(false);
                request.setConfig(null);

                log.info("调用 roomService.createRoom(), 创建者: {}", matchedPlayers.get(0));
                String roomNo = roomService.createRoom(request);
                String gameRoomId = "room_" + roomNo;
                log.info("房间创建成功! roomNo={}, gameRoomId={}", roomNo, gameRoomId);

                // 将4个玩家都加入房间（数据库和内存房间）
                for (Long userId : matchedPlayers) {
                    User user = userMapper.selectById(userId);
                    if (user != null) {
                        // 加入数据库房间
                        try {
                            log.info("将玩家 {} (用户名: {}) 加入数据库房间 {}", userId, user.getUsername(), roomNo);
                            roomService.joinRoom(roomNo, user.getUsername());
                            log.info("玩家 {} 成功加入数据库房间", userId);
                        } catch (Exception e) {
                            log.error("玩家 {} 加入数据库房间失败: {}", userId, e.getMessage(), e);
                        }

                        // 加入游戏内存房间
                        String playerId = String.valueOf(userId);
                        try {
                            log.info("将玩家 {} 加入游戏内存房间 {}", userId, gameRoomId);
                            gameLogicService.joinRoom(playerId, gameRoomId);
                            log.info("玩家 {} 成功加入游戏内存房间", userId);
                        } catch (Exception e) {
                            log.error("玩家 {} 加入游戏内存房间失败: {}", userId, e.getMessage(), e);
                        }
                    } else {
                        log.error("找不到玩家 {} 的用户信息!", userId);
                    }
                }

                // 从队列中移除这4个玩家，并设置匹配结果
                for (Long playerId : matchedPlayers) {
                    roomCache.removeFromMatchQueue(playerId);
                    roomCache.setMatchResult(playerId, roomNo);
                    log.info("玩家 {} 已从匹配队列移除，匹配结果已设置为房间号: {}", playerId, roomNo);
                }

                log.info("========== 匹配成功! 房间号: {}, 4个玩家: {} ==========", roomNo, matchedPlayers);
            } catch (Exception e) {
                log.error("========== 匹配失败! ==========", e);
                // 如果创建房间失败，重新将玩家加入队列
                for (Long playerId : matchedPlayers) {
                    if (!roomCache.isInMatchQueue(playerId)) {
                        roomCache.addToMatchQueue(playerId);
                        log.info("玩家 {} 已重新加入匹配队列", playerId);
                    }
                }
            }
        }
    }
}
