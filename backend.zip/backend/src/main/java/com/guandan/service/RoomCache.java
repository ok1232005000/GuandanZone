package com.guandan.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
public class RoomCache {

    private static final Map<Long, Integer> roomStatusMap = new ConcurrentHashMap<>();
    private static final Map<Long, Set<Long>> roomPlayersMap = new ConcurrentHashMap<>();
    private static final Set<Long> matchQueue = ConcurrentHashMap.newKeySet();
    private static final Map<Long, String> matchResultMap = new ConcurrentHashMap<>();
    private static final Map<Long, Long> matchResultExpiryMap = new ConcurrentHashMap<>();
    private static final long MATCH_RESULT_EXPIRY_TIME = 5 * 60 * 1000; // 5分钟过期时间
    private static final Map<Long, Long> onlineRooms = new ConcurrentHashMap<>();

    public void setRoomStatus(Long roomId, Integer status) {
        roomStatusMap.put(roomId, status);
        log.debug("设置房间状态: roomId={}, status={}", roomId, status);
    }

    public Integer getRoomStatus(Long roomId) {
        return roomStatusMap.get(roomId);
    }

    public void addPlayerToRoom(Long roomId, Long playerId) {
        roomPlayersMap.computeIfAbsent(roomId, k -> ConcurrentHashMap.newKeySet()).add(playerId);
        log.debug("添加玩家到房间: roomId={}, playerId={}", roomId, playerId);
    }

    public List<Long> getRoomPlayers(Long roomId) {
        Set<Long> players = roomPlayersMap.get(roomId);
        return players != null ? new ArrayList<>(players) : new ArrayList<>();
    }

    public void removePlayerFromRoom(Long roomId, Long playerId) {
        Set<Long> players = roomPlayersMap.get(roomId);
        if (players != null) {
            players.remove(playerId);
            if (players.isEmpty()) {
                roomPlayersMap.remove(roomId);
            }
        }
        log.debug("从房间移除玩家: roomId={}, playerId={}", roomId, playerId);
    }

    public void addToMatchQueue(Long playerId) {
        matchQueue.add(playerId);
        log.debug("添加玩家到匹配队列: playerId={}, queueSize={}", playerId, matchQueue.size());
    }

    public void removeFromMatchQueue(Long playerId) {
        matchQueue.remove(playerId);
        log.debug("从匹配队列移除玩家: playerId={}, queueSize={}", playerId, matchQueue.size());
    }

    public Long getMatchQueueSize() {
        return (long) matchQueue.size();
    }

    public boolean isInMatchQueue(Long playerId) {
        return matchQueue.contains(playerId);
    }

    public Set<Long> getMatchQueue() {
        return new HashSet<>(matchQueue);
    }

    public void clearMatchQueue() {
        matchQueue.clear();
        log.info("清空匹配队列");
    }

    public void addOnlineRoom(Long roomId, Long timestamp) {
        onlineRooms.put(roomId, timestamp);
        log.debug("添加在线房间: roomId={}, timestamp={}", roomId, timestamp);
    }

    public Long getOnlineRoomCount() {
        return (long) onlineRooms.size();
    }

    public void deleteAllRoomData(Long roomId) {
        roomStatusMap.remove(roomId);
        roomPlayersMap.remove(roomId);
        onlineRooms.remove(roomId);
        log.info("删除房间所有数据: roomId={}", roomId);
    }

    // ========== 匹配结果存储相关方法 ==========

    public void setMatchResult(Long userId, String roomNo) {
        matchResultMap.put(userId, roomNo);
        matchResultExpiryMap.put(userId, System.currentTimeMillis() + MATCH_RESULT_EXPIRY_TIME);
        log.info("设置玩家匹配结果: userId={}, roomNo={}, 过期时间: {}",
                 userId, roomNo, System.currentTimeMillis() + MATCH_RESULT_EXPIRY_TIME);
    }

    public String getMatchResult(Long userId) {
        // 检查匹配结果是否过期
        Long expiryTime = matchResultExpiryMap.get(userId);
        if (expiryTime != null && System.currentTimeMillis() > expiryTime) {
            // 匹配结果已过期，移除
            removeMatchResult(userId);
            log.debug("玩家匹配结果已过期，自动移除: userId={}", userId);
            return null;
        }
        return matchResultMap.get(userId);
    }

    public void removeMatchResult(Long userId) {
        matchResultMap.remove(userId);
        matchResultExpiryMap.remove(userId);
        log.debug("移除玩家匹配结果: userId={}", userId);
    }
}
