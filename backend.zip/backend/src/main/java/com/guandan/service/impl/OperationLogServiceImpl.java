package com.guandan.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.guandan.entity.OperationLog;
import com.guandan.mapper.OperationLogMapper;
import com.guandan.service.OperationLogService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class OperationLogServiceImpl extends ServiceImpl<OperationLogMapper, OperationLog> implements OperationLogService {

    @Override
    @Async
    public void saveAsync(OperationLog operationLog) {
        try {
            this.save(operationLog);
            log.debug("操作日志保存成功: operationType={}, userId={}", operationLog.getOperationType(), operationLog.getUserId());
        } catch (Exception e) {
            log.error("操作日志保存失败: operationType={}, userId={}", operationLog.getOperationType(), operationLog.getUserId(), e);
        }
    }
}
