package com.guandan.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.guandan.entity.OperationLog;

public interface OperationLogService extends IService<OperationLog> {

    void saveAsync(OperationLog operationLog);
}
