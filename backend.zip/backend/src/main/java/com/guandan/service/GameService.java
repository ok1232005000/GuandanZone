package com.guandan.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.guandan.game.model.GameRoom;
import com.guandan.game.util.CardUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * 游戏逻辑服务类
 * 负责游戏房间管理、发牌、出牌验证等核心逻辑
 */
@Slf4j
@Service
public class GameService {
    
    /**
     * 房间存储：roomId -> GameRoom
     */
    private final Map<String, GameRoom> rooms = new ConcurrentHashMap<>();
    
    /**
     * 玩家到房间的映射：playerId -> roomId
     */
    private final Map<String, String> playerToRoom = new ConcurrentHashMap<>();
    
    /**
     * 游戏裁判服务（用于牌型校验和比牌）
     */
    private final GameReferee gameReferee;
    
    /**
     * 构造函数注入 GameReferee
     */
    @Autowired
    public GameService(GameReferee gameReferee) {
        this.gameReferee = gameReferee;
    }
    
    /**
     * 创建或加入房间
     * @param playerId 玩家ID
     * @param roomId 房间ID（如果为null则创建新房间）
     * @return 房间对象
     */
    public GameRoom joinRoom(String playerId, String roomId) {
        // 如果没有指定房间ID，创建新房间
        if (roomId == null || roomId.isEmpty()) {
            roomId = "room_" + System.currentTimeMillis();
        }
        
        GameRoom room = rooms.computeIfAbsent(roomId, GameRoom::new);
        
        // 检查玩家是否已经在房间中（重连情况）
        String existingRoomId = playerToRoom.get(playerId);
        if (existingRoomId != null && existingRoomId.equals(roomId)) {
            // 玩家已经在目标房间中，可能是重连
            GameRoom existingRoom = rooms.get(existingRoomId);
            if (existingRoom != null) {
                // 如果游戏正在进行中，确保玩家在playerIds中（可能因为断线被移除了）
                if (existingRoom.getStatus() == GameRoom.GameStatus.PLAYING) {
                    if (!existingRoom.getPlayerIds().contains(playerId)) {
                        // 玩家不在playerIds中，重新添加（但不创建新手牌，手牌数据应该还在）
                        existingRoom.getPlayerIds().add(playerId);
                        // 如果手牌数据丢失，创建一个空列表（这种情况不应该发生，但作为保护）
                        if (!existingRoom.getHandCards().containsKey(playerId)) {
                            existingRoom.getHandCards().put(playerId, new ArrayList<>());
                            log.warn("玩家 {} 重连时手牌数据丢失，创建空手牌", playerId);
                        }
                        log.info("玩家 {} 重连，恢复游戏状态", playerId);
                    } else {
                        log.info("玩家 {} 重连，已在房间中", playerId);
                    }
                }
                // 恢复映射关系
                playerToRoom.put(playerId, roomId);
                return existingRoom;
            }
        }
        
        // 如果玩家在其他房间，先移除
        if (existingRoomId != null && !existingRoomId.equals(roomId)) {
            GameRoom existingRoom = rooms.get(existingRoomId);
            if (existingRoom != null) {
                existingRoom.getPlayerIds().remove(playerId);
                existingRoom.getHandCards().remove(playerId);
            }
        }
        
        // 添加玩家到房间
        if (room.addPlayer(playerId)) {
            playerToRoom.put(playerId, roomId);
            log.info("玩家 {} 加入房间 {}", playerId, roomId);
        } else {
            log.warn("玩家 {} 无法加入房间 {} (可能已满或已在房间中)", playerId, roomId);
        }
        
        return room;
    }
    
    /**
     * 开始游戏（当房间满4人时）
     * @param roomId 房间ID
     * @return 是否成功开始游戏
     */
    public boolean startGame(String roomId) {
        GameRoom room = rooms.get(roomId);
        if (room == null) {
            log.error("房间 {} 不存在", roomId);
            return false;
        }
        
        if (!room.isFull()) {
            log.warn("房间 {} 玩家未满，无法开始游戏", roomId);
            return false;
        }
        
        // 生成并洗牌
        List<Integer> deck = generateDeck();
        Collections.shuffle(deck);
        
        // 发牌：每人27张
        int cardsPerPlayer = 27;
        int cardIndex = 0;
        
        for (String playerId : room.getPlayerIds()) {
            List<Integer> hand = new ArrayList<>();
            for (int i = 0; i < cardsPerPlayer && cardIndex < deck.size(); i++) {
                hand.add(deck.get(cardIndex++));
            }
            // 排序手牌（便于调试）
            Collections.sort(hand);
            room.getHandCards().put(playerId, hand);
            
            log.info("玩家 {} 获得 {} 张手牌: {}", 
                    playerId, hand.size(), 
                    Arrays.toString(CardUtils.idsToStrings(hand.stream().mapToInt(i->i).toArray())));
        }
        
        // 初始化轮转：从第一个玩家开始
        room.setCurrentPlayerIndex(0);
        room.setStatus(GameRoom.GameStatus.PLAYING);
        log.info("房间 {} 游戏开始，当前轮到玩家: {}", roomId, room.getCurrentPlayerId());
        return true;
    }
    
    /**
     * 生成一副完整的牌（0-107）
     * @return 卡牌ID列表
     */
    private List<Integer> generateDeck() {
        List<Integer> deck = new ArrayList<>();
        // 两副牌：0-103 (104张普通牌) + 104-107 (4张大小王)
        for (int i = 0; i < 108; i++) {
            deck.add(i);
        }
        return deck;
    }
    
    /**
     * 玩家出牌
     * @param playerId 玩家ID
     * @param cardIds 要出的卡牌ID列表
     * @return 是否成功出牌
     */
    public boolean playCards(String playerId, List<Integer> cardIds) {
        String roomId = playerToRoom.get(playerId);
        if (roomId == null) {
            log.error("玩家 {} 不在任何房间中", playerId);
            return false;
        }
        
        GameRoom room = rooms.get(roomId);
        if (room == null) {
            log.error("房间 {} 不存在", roomId);
            return false;
        }
        
        if (room.getStatus() != GameRoom.GameStatus.PLAYING) {
            log.warn("房间 {} 不在游戏中，无法出牌", roomId);
            return false;
        }
        
        // 验证是否是当前玩家的回合（轮转逻辑）
        if (!room.isCurrentPlayer(playerId)) {
            String currentPlayerId = room.getCurrentPlayerId();
            log.warn("玩家 {} 尝试出牌失败：当前不是他的回合，应该轮到玩家 {}", 
                    playerId, currentPlayerId);
            return false;
        }
        
        // ========== 牌型识别与规则判定 ==========
        // 1. 先验证牌型是否合法（无论手牌是否包含，先检查牌型）
        if (!gameReferee.isValidHand(cardIds, room.getLevelCardRank())) {
            log.warn("玩家 {} 尝试出牌失败：牌型不合法 {}", 
                    playerId, Arrays.toString(CardUtils.idsToStrings(cardIds.stream().mapToInt(i -> i).toArray())));
            return false;
        }
        
        // 2. 验证手牌中是否包含要出的卡牌
        List<Integer> hand = room.getHandCards().get(playerId);
        if (hand == null) {
            log.warn("玩家 {} 尝试出牌失败：手牌为空", playerId);
            return false;
        }
        
        for (Integer cardId : cardIds) {
            if (!hand.contains(cardId)) {
                log.warn("玩家 {} 尝试出牌失败：手牌中不包含指定的卡牌 {}", 
                        playerId, cardId);
                return false;
            }
        }
        
        // 3. 检查是否能管住上一手牌
        List<Integer> lastHand = room.getLastHandCards();
        if (!gameReferee.canBeat(lastHand, cardIds, room.getLevelCardRank())) {
            log.warn("玩家 {} 尝试出牌失败：无法管住上一手牌。上一手: {}, 当前: {}", 
                    playerId,
                    lastHand != null ? Arrays.toString(CardUtils.idsToStrings(lastHand.stream().mapToInt(i -> i).toArray())) : "无",
                    Arrays.toString(CardUtils.idsToStrings(cardIds.stream().mapToInt(i -> i).toArray())));
            return false;
        }
        
        // 4. 验证通过后，移除手牌
        if (!room.removeCards(playerId, cardIds)) {
            log.warn("玩家 {} 尝试出牌失败：移除手牌时出错", playerId);
            return false;
        }
        
        log.info("玩家 {} 出牌: {}", 
                playerId, 
                Arrays.toString(CardUtils.idsToStrings(cardIds.stream().mapToInt(i->i).toArray())));
        
        // 5. 获取移除后的剩余手牌
        List<Integer> remainingCards = room.getHandCards().get(playerId);
        if (remainingCards == null) {
            remainingCards = new ArrayList<>();
        }
        
        // 6. 检查是否获胜（手牌为空）
        boolean isWinner = remainingCards.isEmpty();
        if (isWinner) {
            log.info("玩家 {} 获胜！手牌已出完", playerId);
            room.setStatus(GameRoom.GameStatus.FINISHED);
        }
        
        // 7. 更新上一手牌和出牌玩家，重置连续跳过次数
        room.setLastHandCards(cardIds);
        room.setLastHandPlayerId(playerId);
        room.resetPassCount(); // 有人出牌，重置连续跳过计数
        
        // 8. 出牌成功后，切换到下一个玩家（轮转）
        room.nextPlayer();
        log.info("房间 {} 轮到下一个玩家: {}", roomId, room.getCurrentPlayerId());
        
        // 9. 将剩余手牌信息存储到返回值中（通过返回值传递）
        // 注意：这里我们通过修改 GameRoom 的状态来传递信息
        // WebSocketServer 会在广播时获取最新的手牌信息
        
        return true;
    }
    
    /**
     * 玩家放弃出牌（过牌）
     * @param playerId 玩家ID
     * @return 是否成功放弃出牌
     */
    public boolean passTurn(String playerId) {
        String roomId = playerToRoom.get(playerId);
        if (roomId == null) {
            log.error("玩家 {} 不在任何房间中", playerId);
            return false;
        }
        
        GameRoom room = rooms.get(roomId);
        if (room == null) {
            log.error("房间 {} 不存在", roomId);
            return false;
        }
        
        if (room.getStatus() != GameRoom.GameStatus.PLAYING) {
            log.warn("房间 {} 不在游戏中，无法放弃出牌", roomId);
            return false;
        }
        
        // 验证是否是当前玩家的回合
        if (!room.isCurrentPlayer(playerId)) {
            String currentPlayerId = room.getCurrentPlayerId();
            log.warn("玩家 {} 尝试放弃出牌失败：当前不是他的回合，应该轮到玩家 {}", 
                    playerId, currentPlayerId);
            return false;
        }
        
        // 如果上一手牌为空（首出），不能放弃
        if (room.getLastHandCards() == null || room.getLastHandCards().isEmpty()) {
            log.warn("玩家 {} 尝试放弃出牌失败：当前是首出，不能放弃", playerId);
            return false;
        }
        
        log.info("玩家 {} 放弃出牌", playerId);
        
        // 增加连续跳过次数
        room.incrementPassCount();
        
        // 放弃出牌后，切换到下一个玩家（轮转）
        room.nextPlayer();
        String nextPlayerId = room.getCurrentPlayerId();
        log.info("房间 {} 轮到下一个玩家: {}，连续跳过次数: {}", 
                roomId, nextPlayerId, room.getConsecutivePassCount());
        
        // 关键修复：检测是否所有玩家都跳过
        // 如果连续跳过次数 >= 3（其他3人都不要），且轮回到出上一手牌的玩家
        String lastHandPlayerId = room.getLastHandPlayerId();
        if (room.getConsecutivePassCount() >= 3 && 
            lastHandPlayerId != null && 
            nextPlayerId != null && 
            nextPlayerId.equals(lastHandPlayerId)) {
            // 所有玩家都跳过了，清空上一手牌，让下一轮可以首出任意牌型
            room.clearLastHandCards();
            log.info("房间 {} 所有玩家都跳过，清空上一手牌，玩家 {} 可以首出任意牌型", 
                    roomId, nextPlayerId);
        }
        
        return true;
    }
    
    /**
     * 获取玩家所在房间
     * @param playerId 玩家ID
     * @return 房间对象，如果不存在则返回null
     */
    public GameRoom getPlayerRoom(String playerId) {
        String roomId = playerToRoom.get(playerId);
        if (roomId == null) {
            return null;
        }
        return rooms.get(roomId);
    }
    
    /**
     * 获取房间
     * @param roomId 房间ID
     * @return 房间对象
     */
    public GameRoom getRoom(String roomId) {
        return rooms.get(roomId);
    }
    
    /**
     * 移除玩家（断开连接时）
     * 注意：如果游戏正在进行中，不删除手牌数据，以便重连时恢复
     * @param playerId 玩家ID
     */
    public void removePlayer(String playerId) {
        String roomId = playerToRoom.get(playerId);
        if (roomId != null) {
            GameRoom room = rooms.get(roomId);
            if (room != null) {
                // 如果游戏正在进行中，只移除玩家ID映射，保留手牌数据以便重连时恢复
                if (room.getStatus() == GameRoom.GameStatus.PLAYING) {
                    // 游戏进行中，不删除手牌，只移除映射关系
                    playerToRoom.remove(playerId);
                    log.info("玩家 {} 断开连接（游戏进行中，保留手牌数据）", playerId);
                } else {
                    // 游戏未开始或已结束，可以删除所有数据
                    playerToRoom.remove(playerId);
                    room.getPlayerIds().remove(playerId);
                    room.getHandCards().remove(playerId);
                    log.info("玩家 {} 离开房间 {}", playerId, roomId);
                }
            }
        }
    }
    
    /**
     * 验证牌型是否合法（供外部调用）
     * @param cardIds 卡牌ID列表
     * @param levelCardRank 级牌点数 (0-12对应2-A)
     * @return 如果合法返回true，否则返回false
     */
    public boolean isValidHand(List<Integer> cardIds, int levelCardRank) {
        return gameReferee.isValidHand(cardIds, levelCardRank);
    }
    
    /**
     * 判断当前手牌是否能管住上一手牌（供外部调用）
     * @param lastHand 上一手牌
     * @param currentHand 当前手牌
     * @param levelCardRank 级牌点数 (0-12对应2-A)
     * @return 如果能管住返回true，否则返回false
     */
    public boolean canBeat(List<Integer> lastHand, List<Integer> currentHand, int levelCardRank) {
        return gameReferee.canBeat(lastHand, currentHand, levelCardRank);
    }
}
