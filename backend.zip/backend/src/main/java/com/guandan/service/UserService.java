package com.guandan.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.guandan.dto.ChangePasswordRequest;
import com.guandan.dto.RegisterRequest;
import com.guandan.dto.UserInfoResponse;
import com.guandan.entity.User;
import com.guandan.entity.UserStats;
import com.guandan.mapper.UserMapper;
import com.guandan.mapper.UserStatsMapper;
import com.guandan.util.PasswordUtil;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserService {

    @Resource
    private UserMapper userMapper;

    @Resource
    private UserStatsMapper userStatsMapper;

    public User register(RegisterRequest request) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", request.getUsername());
        if (userMapper.selectCount(queryWrapper) > 0) {
            throw new RuntimeException("用户名已存在");
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(PasswordUtil.hashPassword(request.getPassword()));
        user.setNickname(request.getNickname());
        user.setAvatar(request.getAvatar());
        user.setPhone(request.getPhone());

        userMapper.insert(user);

        UserStats stats = new UserStats();
        stats.setUserId(user.getId());
        stats.setTotalGames(0);
        stats.setWinGames(0);
        stats.setLevelCurrent(2);
        userStatsMapper.insert(stats);

        return user;
    }

    public User login(String username, String password) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        User user = userMapper.selectOne(queryWrapper);

        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        if (!PasswordUtil.checkPassword(password, user.getPassword())) {
            throw new RuntimeException("密码错误");
        }

        return user;
    }

    public User getUserById(Long userId) {
        return userMapper.selectById(userId);
    }

    public UserInfoResponse getUserInfo(Long userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        UserStats stats = userStatsMapper.selectById(userId);

        UserInfoResponse response = new UserInfoResponse();
        response.setId(user.getId());
        response.setUsername(user.getUsername());
        response.setNickname(user.getNickname());
        response.setAvatar(user.getAvatar());
        response.setPhone(user.getPhone());

        if (stats != null) {
            response.setTotalGames(stats.getTotalGames());
            response.setWinGames(stats.getWinGames());
            response.setLevelCurrent(stats.getLevelCurrent());
        } else {
            response.setTotalGames(0);
            response.setWinGames(0);
            response.setLevelCurrent(2);
        }

        return response;
    }

    public boolean existsByUsername(String username) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        return userMapper.selectCount(queryWrapper) > 0;
    }

    public void logout(Long userId) {
        User user = userMapper.selectById(userId);
        if (user != null) {
            user.setOnline(0);
            userMapper.updateById(user);
            // 在线状态由SessionManager管理，不需要更新数据库
            log.info("用户退出登录: userId={}", userId);
        }
    }

    public void changePassword(ChangePasswordRequest request) {
        User user = userMapper.selectById(request.getUserId());
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        if (!PasswordUtil.checkPassword(request.getOldPassword(), user.getPassword())) {
            throw new RuntimeException("原密码错误");
        }

        user.setPassword(PasswordUtil.hashPassword(request.getNewPassword()));
        userMapper.updateById(user);
    }
}
