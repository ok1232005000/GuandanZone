package com.guandan.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.guandan.dto.NewGameRequest;
import com.guandan.entity.Room;
import com.guandan.entity.RoomPlayer;
import com.guandan.entity.User;
import com.guandan.mapper.RoomMapper;
import com.guandan.mapper.RoomPlayerMapper;
import com.guandan.mapper.UserMapper;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 房间服务类
 * 职责：房间基础信息管理（创建、查询）
 * 注意：游戏核心逻辑（加入房间、分配座位等）由成员A的 GuandanLogic 处理
 */
@Slf4j
@Service
public class RoomService {

    @Resource
    private RoomMapper roomMapper;

    @Resource
    private RoomPlayerMapper roomPlayerMapper;

    @Resource
    private UserMapper userMapper;

    /**
     * 创建新游戏/房间
     */
    public String createRoom(NewGameRequest request) {
        // 生成6位房间号
        String roomNo = generateRoomNo();

        // 检查房间号是否已存在
        QueryWrapper<Room> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("room_no", roomNo);
        if (roomMapper.selectCount(queryWrapper) > 0) {
            // 极低概率重复，重新生成
            return createRoom(request);
        }

        // 创建房间
        Room room = new Room();
        room.setRoomNo(roomNo);
        room.setStatus(0); // 0-等待中
        room.setCreatorId(request.getUserId());
        room.setIsPrivate(request.getIsPrivate() != null ? request.getIsPrivate() : false);
        room.setLevelTeamA(2);
        room.setLevelTeamB(2);
        room.setConfig(request.getConfig());

        roomMapper.insert(room);

        // 自动将创建者加入房间
        try {
            User creator = userMapper.selectById(request.getUserId());
            if (creator != null) {
                RoomPlayer roomPlayer = new RoomPlayer();
                roomPlayer.setRoomId(room.getId());
                roomPlayer.setUserId(request.getUserId());
                roomPlayer.setSeatIndex(0); // 创建者默认为0号座位
                roomPlayer.setIsReady(0);
                roomPlayer.setCardCount(0);
                roomPlayerMapper.insert(roomPlayer);
                log.info("创建者 {} 已自动加入房间 {}", request.getUserId(), roomNo);
            }
        } catch (Exception e) {
            log.error("自动将创建者加入房间失败", e);
        }

        return roomNo;
    }

    /**
     * 根据房间号获取房间信息
     */
    public Room getRoomByRoomNo(String roomNo) {
        QueryWrapper<Room> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("room_no", roomNo);
        return roomMapper.selectOne(queryWrapper);
    }

    /**
     * 根据ID获取房间信息
     */
    public Room getRoomById(Long roomId) {
        return roomMapper.selectById(roomId);
    }

    /**
     * 更新房间状态
     */
    public void updateRoomStatus(Long roomId, Integer status) {
        Room room = new Room();
        room.setId(roomId);
        room.setStatus(status);
        roomMapper.updateById(room);
    }

    public void updateRoomCreatorId(Long roomId, Long creatorId) {
        Room room = new Room();
        room.setId(roomId);
        room.setCreatorId(creatorId);
        roomMapper.updateById(room);
    }

    /**
     * 获取所有可用房间（等待中和游戏中的房间）
     * 用于大厅显示房间列表
     */
    public List<Room> getAvailableRooms() {
        QueryWrapper<Room> queryWrapper = new QueryWrapper<>();
        // 查询等待中和游戏中的房间（0-等待中, 1-游戏中）
        queryWrapper.in("status", 0, 1);
        queryWrapper.orderByDesc("id");
        List<Room> rooms = roomMapper.selectList(queryWrapper);

        // 返回所有房间，并设置人数
        for (Room room : rooms) {
            Integer playerCount = getPlayerCount(room.getId());
            room.setUserCount(playerCount);
        }

        return rooms;
    }

    /**
     * 获取房间玩家数量
     */
    public Integer getPlayerCount(Long roomId) {
        QueryWrapper<RoomPlayer> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("room_id", roomId);
        return roomPlayerMapper.selectCount(queryWrapper).intValue();
    }

    /**
     * 获取房间玩家列表
     */
    public List<RoomPlayer> getRoomPlayers(Long roomId) {
        QueryWrapper<RoomPlayer> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("room_id", roomId);
        return roomPlayerMapper.selectList(queryWrapper);
    }

    /**
     * 获取用户当前所在的房间
     * 
     * @param userId 用户ID
     * @return 房间信息，如果用户不在任何房间则返回null
     */
    public Room getCurrentRoom(Long userId) {
        // 1. 查询用户所在的房间玩家记录
        QueryWrapper<RoomPlayer> playerQuery = new QueryWrapper<>();
        playerQuery.eq("user_id", userId);
        playerQuery.orderByDesc("id");
        playerQuery.last("LIMIT 1");
        RoomPlayer roomPlayer = roomPlayerMapper.selectOne(playerQuery);

        if (roomPlayer == null) {
            return null;
        }

        // 2. 根据房间ID查询房间信息
        return roomMapper.selectById(roomPlayer.getRoomId());
    }

    /**
     * 生成6位房间号
     */
    private String generateRoomNo() {
        Random random = new Random();
        int roomNo = 100000 + random.nextInt(900000);
        return String.valueOf(roomNo);
    }

    /**
     * 创建房间（兼容接口用）
     */
    public Room createRoom(Boolean isPrivate, String config) {
        // 生成6位房间号
        String roomNo = generateRoomNo();

        // 检查房间号是否已存在
        QueryWrapper<Room> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("room_no", roomNo);
        if (roomMapper.selectCount(queryWrapper) > 0) {
            // 极低概率重复，重新生成
            return createRoom(isPrivate, config);
        }

        // 创建房间
        Room room = new Room();
        room.setRoomNo(roomNo);
        room.setStatus(0); // 0-等待中
        room.setCreatorId(1L); // 兼容接口默认创建者ID（实际应该从token获取）
        room.setIsPrivate(isPrivate != null ? isPrivate : false);
        room.setLevelTeamA(2);
        room.setLevelTeamB(2);
        room.setConfig(config);

        roomMapper.insert(room);

        return room;
    }

    /**
     * 加入房间（兼容接口用）
     */
    public RoomPlayer joinRoom(String roomNo, String username) {
        // 1. 查询房间
        Room room = getRoomByRoomNo(roomNo);
        if (room == null) {
            throw new RuntimeException("房间不存在");
        }

        // 2. 查询用户
        QueryWrapper<com.guandan.entity.User> userQuery = new QueryWrapper<>();
        userQuery.eq("username", username);
        com.guandan.entity.User user = userMapper.selectOne(userQuery);
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        // 3. 检查是否已在房间中
        QueryWrapper<RoomPlayer> playerQuery = new QueryWrapper<>();
        playerQuery.eq("room_id", room.getId());
        playerQuery.eq("user_id", user.getId());
        RoomPlayer existing = roomPlayerMapper.selectOne(playerQuery);
        if (existing != null) {
            return existing; // 已在房间中
        }

        // 4. 检查房间人数
        QueryWrapper<RoomPlayer> countQuery = new QueryWrapper<>();
        countQuery.eq("room_id", room.getId());
        Long playerCount = roomPlayerMapper.selectCount(countQuery);
        if (playerCount >= 4) {
            throw new RuntimeException("房间已满");
        }

        // 5. 分配座位
        int seatIndex = playerCount.intValue();

        // 6. 创建房间玩家记录
        RoomPlayer roomPlayer = new RoomPlayer();
        roomPlayer.setRoomId(room.getId());
        roomPlayer.setUserId(user.getId());
        roomPlayer.setSeatIndex(seatIndex);
        roomPlayer.setIsReady(0);
        roomPlayer.setCardCount(0);

        roomPlayerMapper.insert(roomPlayer);

        return roomPlayer;
    }

    /**
     * 删除房间
     */
    public void deleteRoom(Long roomId) {
        // 删除房间玩家记录
        QueryWrapper<RoomPlayer> playerQuery = new QueryWrapper<>();
        playerQuery.eq("room_id", roomId);
        roomPlayerMapper.delete(playerQuery);

        // 删除房间记录
        roomMapper.deleteById(roomId);
    }
}
