package com.guandan.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
public class TokenCache {

    private static final int MAX_TOKENS_PER_USER = 5;

    private static final Map<Long, Deque<String>> tokenMap = new ConcurrentHashMap<>();

    @Value("${jwt.expiration:86400000}")
    private Long jwtExpiration;

    private long getExpirationSeconds() {
        return jwtExpiration / 1000;
    }

    private static final String TOKEN_KEY_PREFIX = "token:";
    private static final String USER_TOKEN_KEY = TOKEN_KEY_PREFIX + "user:";

    public void setUserToken(Long userId, String token) {
        try {
            Deque<String> tokens = tokenMap.computeIfAbsent(userId, k -> new ConcurrentLinkedDeque<>());

            // 去重后放到队首
            tokens.remove(token);
            tokens.addFirst(token);

            while (tokens.size() > MAX_TOKENS_PER_USER) {
                tokens.pollLast();
            }
            log.debug("保存用户Token: userId={}, token={}", userId, maskToken(token));
        } catch (Exception e) {
            log.warn("保存Token失败，但继续执行: userId={}, error={}", userId, e.getMessage());
        }
    }

    public String getUserToken(Long userId) {
        Deque<String> tokens = tokenMap.get(userId);
        String token = tokens == null ? null : tokens.peekFirst();
        if (token != null) {
            log.debug("获取用户Token: userId={}", userId);
            return token;
        }
        return null;
    }

    public void deleteUserToken(Long userId) {
        try {
            tokenMap.remove(userId);
            log.info("删除用户Token: userId={}", userId);
        } catch (Exception e) {
            log.warn("删除Token失败: userId={}, error={}", userId, e.getMessage());
        }
    }

    public boolean validateToken(Long userId, String token) {
        try {
            Deque<String> tokens = tokenMap.get(userId);
            if (tokens == null || tokens.isEmpty()) {
                log.warn("Token不存在: userId={}", userId);
                return false;
            }
            boolean valid = tokens.contains(token);
            if (!valid) {
                log.warn("Token不匹配: userId={}", userId);
            }
            return valid;
        } catch (Exception e) {
            log.warn("Token验证失败: userId={}, error={}", userId, e.getMessage());
            return true;
        }
    }

    public void refreshTokenExpire(Long userId) {
        log.debug("刷新Token过期时间: userId={}", userId);
    }

    public boolean isUserOnline(Long userId) {
        Deque<String> tokens = tokenMap.get(userId);
        return tokens != null && !tokens.isEmpty();
    }

    public Long getTokenTtl(Long userId) {
        return getExpirationSeconds();
    }

    private String maskToken(String token) {
        if (token == null || token.length() < 12) {
            return "***";
        }
        return token.substring(0, 6) + "..." + token.substring(token.length() - 6);
    }
}
