package com.guandan.service;

import com.guandan.dto.LoginResponse;
import com.guandan.dto.RegisterRequest;
import com.guandan.dto.RegisterResponse;
import com.guandan.dto.UserInfoResponse;
import com.guandan.entity.User;
import com.guandan.util.JwtUtil;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

/**
 * 认证服务类
 */
@Service
public class AuthService {

    @Resource
    private UserService userService;

    @Resource
    private JwtUtil jwtUtil;

    @Resource
    private TokenCache tokenCache;

    /**
     * 注册
     */
    public RegisterResponse register(RegisterRequest request) {
        User user = userService.register(request);

        // 生成Token
        String token = jwtUtil.generateToken(user.getId(), user.getUsername());

        // 保存Token到Redis
        tokenCache.setUserToken(user.getId(), token);

        RegisterResponse response = new RegisterResponse();
        response.setUserId(user.getId());
        response.setUsername(user.getUsername());
        response.setToken(token);
        response.setNickname(user.getNickname());
        response.setAvatar(user.getAvatar());

        return response;
    }

    /**
     * 注册（兼容接口用）
     */
    public Long register(String username, String password, String nickname) {
        RegisterRequest request = new RegisterRequest();
        request.setUsername(username);
        request.setPassword(password);
        request.setNickname(nickname);
        User user = userService.register(request);
        return user.getId();
    }

    /**
     * 登录
     */
    public LoginResponse login(String username, String password) {
        User user = userService.login(username, password);

        // 生成Token
        String token = jwtUtil.generateToken(user.getId(), user.getUsername());

        // 保存Token到Redis
        tokenCache.setUserToken(user.getId(), token);

        LoginResponse response = new LoginResponse();
        response.setToken(token);
        response.setUserId(user.getId());
        response.setUsername(user.getUsername());
        response.setNickname(user.getNickname());
        response.setAvatar(user.getAvatar());

        return response;
    }

    /**
     * 获取用户信息
     */
    public UserInfoResponse getUserInfo(Long userId) {
        return userService.getUserInfo(userId);
    }

    /**
     * 验证Token
     */
    public Long validateToken(String token) {
        if (!jwtUtil.validateToken(token)) {
            throw new RuntimeException("Token无效或已过期");
        }
        return jwtUtil.getUserIdFromToken(token);
    }
}
