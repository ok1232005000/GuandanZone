package com.guandan.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.guandan.entity.UserStats;
import com.guandan.vo.PlayerGameRecordVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;

@Mapper
public interface UserStatsMapper extends BaseMapper<UserStats> {
    Page<PlayerGameRecordVO> selectRecordsByUserId(@Param("userId") Long userId,
                                                     @Param("startTime") LocalDateTime startTime,
                                                     @Param("endTime") LocalDateTime endTime,
                                                     Page<PlayerGameRecordVO> page);
}
