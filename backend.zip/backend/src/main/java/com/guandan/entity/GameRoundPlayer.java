package com.guandan.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("game_round_player")
public class GameRoundPlayer {

    @TableId(type = IdType.AUTO)
    private Long id;

    @TableField("round_id")
    private Long roundId;

    @TableField("user_id")
    private Long userId;

    @TableField("seat_index")
    private Integer seatIndex;

    @TableField("rank_order")
    private Integer rankOrder;

    @TableField("score_change")
    private Integer scoreChange;

    private String highlights;
}
