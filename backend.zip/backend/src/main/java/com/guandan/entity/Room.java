package com.guandan.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("room")
public class Room {

    @TableId(type = IdType.AUTO)
    private Long id;

    @TableField("room_no")
    private String roomNo;

    private Integer status;

    @TableField("creator_id")
    private Long creatorId;

    @TableField("level_team_a")
    private Integer levelTeamA;

    @TableField("level_team_b")
    private Integer levelTeamB;

    @TableField("current_trump_suit")
    private String currentTrumpSuit;

    @TableField("next_tribute_state")
    private String nextTributeState;

    @TableField("is_private")
    private Boolean isPrivate;

    private String config;

    @TableField(exist = false)
    private Integer userCount;
}
