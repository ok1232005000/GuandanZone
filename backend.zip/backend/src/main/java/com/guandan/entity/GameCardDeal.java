package com.guandan.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("game_card_deal")
public class GameCardDeal {

    @TableId(type = IdType.AUTO)
    private Long id;

    @TableField("room_id")
    private Long roomId;

    @TableField("game_round_id")
    private Long gameRoundId;

    @TableField("player_id")
    private String playerId;

    @TableField("card_ids")
    private String cardIds;

    @TableField("deal_time")
    private LocalDateTime dealTime;
}
