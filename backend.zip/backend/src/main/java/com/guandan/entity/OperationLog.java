package com.guandan.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("tb_operation_log")
public class OperationLog {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private String username;

    private String operationType;

    private String operationModule;

    private String operationDesc;

    private String targetType;

    private Long targetId;

    private String requestIp;

    private String requestMethod;

    private String requestUrl;

    private String userAgent;

    private Integer responseStatus;

    private Integer isSuccess;

    private String errorMessage;

    private LocalDateTime executeTime;

    private LocalDateTime createTime;
}
