package com.guandan.interceptor;

import com.guandan.annotation.IgnoreAuth;
import com.guandan.common.ResponseCode;
import com.guandan.exception.BusinessException;
import com.guandan.service.TokenCache;
import com.guandan.util.JwtUtil;
import com.guandan.util.UserContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import java.lang.reflect.Method;

@Slf4j
@Component
public class TokenInterceptor implements HandlerInterceptor {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private TokenCache tokenCache;

    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        if (!(handler instanceof HandlerMethod)) {
            return true;
        }

        HandlerMethod handlerMethod = (HandlerMethod) handler;
        Method method = handlerMethod.getMethod();

        if (method.getAnnotation(IgnoreAuth.class) != null ||
                handlerMethod.getBeanType().getAnnotation(IgnoreAuth.class) != null) {
            log.debug("接口标记了@IgnoreAuth，跳过Token验证: {}", request.getRequestURI());
            return true;
        }

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        String token = extractToken(request);
        if (token == null || token.isEmpty()) {
            log.warn("Token缺失: {}", request.getRequestURI());
            throw new BusinessException(ResponseCode.UNAUTHORIZED, "未登录，请先登录");
        }

        try {
            if (!jwtUtil.validateToken(token)) {
                log.warn("Token无效或已过期: {}", request.getRequestURI());
                throw new BusinessException(ResponseCode.UNAUTHORIZED, "登录已过期，请重新登录");
            }

            Long userId = jwtUtil.getUserIdFromToken(token);
            String username = jwtUtil.getUsernameFromToken(token);

            if (userId == null || username == null) {
                log.warn("Token解析失败: {}", request.getRequestURI());
                throw new BusinessException(ResponseCode.UNAUTHORIZED, "登录信息无效，请重新登录");
            }

            if (!tokenCache.validateToken(userId, token)) {
                log.warn("Token已在Redis中失效，可能已被强制登出: userId={}", userId);
                throw new BusinessException(ResponseCode.UNAUTHORIZED, "登录已在其他设备失效，请重新登录");
            }

            UserContext.setContext(userId, username, token);

            log.debug("Token验证成功: userId={}, username={}, uri={}", userId, username, request.getRequestURI());
            return true;

        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            log.error("Token验证异常: {}", request.getRequestURI(), e);
            throw new BusinessException(ResponseCode.UNAUTHORIZED, "登录验证失败，请重新登录");
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        UserContext.clear();
    }

    private String extractToken(HttpServletRequest request) {
        String bearerToken = request.getHeader(AUTHORIZATION_HEADER);

        if (bearerToken != null && bearerToken.startsWith(BEARER_PREFIX)) {
            return bearerToken.substring(BEARER_PREFIX.length());
        }

        return null;
    }
}
