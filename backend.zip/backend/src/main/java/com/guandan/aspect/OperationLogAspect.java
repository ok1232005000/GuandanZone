package com.guandan.aspect;

import com.guandan.annotation.LogRecord;
import com.guandan.entity.OperationLog;
import com.guandan.service.OperationLogService;
import com.guandan.util.UserContext;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.lang.reflect.Method;
import java.time.LocalDateTime;

@Slf4j
@Aspect
@Component
public class OperationLogAspect {

    @Autowired
    private OperationLogService operationLogService;

    @Around("@annotation(com.guandan.annotation.LogRecord)")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        OperationLog operationLog = new OperationLog();
        Object result = null;

        try {
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            Method method = signature.getMethod();
            LogRecord logRecord = method.getAnnotation(LogRecord.class);

            operationLog.setOperationType(logRecord.operationType());
            operationLog.setOperationModule(logRecord.operationModule());
            operationLog.setOperationDesc(logRecord.operationDesc());
            operationLog.setTargetType(logRecord.targetType().isEmpty() ? null : logRecord.targetType());

            Long userId = UserContext.getUserId();
            String username = UserContext.getUsername();
            operationLog.setUserId(userId);
            operationLog.setUsername(username);

            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attributes != null) {
                HttpServletRequest request = attributes.getRequest();
                operationLog.setRequestIp(getClientIp(request));
                operationLog.setRequestMethod(request.getMethod());
                operationLog.setRequestUrl(request.getRequestURI());
                operationLog.setUserAgent(request.getHeader("User-Agent"));
            }

            result = joinPoint.proceed();

            operationLog.setExecuteTime(LocalDateTime.now());
            operationLog.setIsSuccess(1);
            operationLog.setResponseStatus(200);

            return result;

        } catch (Exception e) {
            operationLog.setExecuteTime(LocalDateTime.now());
            operationLog.setIsSuccess(0);
            operationLog.setResponseStatus(500);
            operationLog.setErrorMessage(e.getMessage() != null && e.getMessage().length() > 500 
                    ? e.getMessage().substring(0, 500) : e.getMessage());

            throw e;

        } finally {
            try {
                Object[] args = joinPoint.getArgs();
                if (args != null && args.length > 0) {
                    for (Object arg : args) {
                        if (arg != null) {
                            if (arg instanceof Long) {
                                operationLog.setTargetId((Long) arg);
                                break;
                            }
                        }
                    }
                }

                operationLogService.saveAsync(operationLog);
            } catch (Exception e) {
                log.error("操作日志保存失败", e);
            }
        }
    }

    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        return ip;
    }
}
