package com.guandan.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = UsernameValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface Username {

    String message() default "用户名格式不正确（4-20位字母、数字、下划线，必须以字母开头）";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
