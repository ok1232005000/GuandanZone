package com.guandan.game.service;

import com.guandan.model.CardType;
import java.util.List;
import java.util.Map;

/**
 * 游戏算法接口
 * 负责人：成员A（核心引擎与逻辑）
 *
 * 说明：
 * - 成员B（通讯与架构层）通过调用此接口来验证游戏规则
 * - 成员A需要实现此接口，提供具体的算法逻辑
 *
 * @author 成员A
 */
public interface GameAlgorithm {

    /**
     * 校验出牌是否合法
     *
     * 使用场景：
     * - 玩家点击"出牌"按钮时，后端需要验证这组牌是否符合掼蛋规则
     * - 例如：3556 是否是三连对？3334 是否是三条？...
     *
     * @param cards 要出的牌（卡牌ID列表，0-107）
     * @param lastCards 上家出的牌（如果是我方先出牌，则为null或空）
     * @param levelCard 当前级牌（例如：2表示级牌是2，14表示小王）
     * @return 是否合法
     */
    boolean isValidPlay(List<Integer> cards, List<Integer> lastCards, int levelCard);

    /**
     * 比较两组牌的大小
     *
     * 使用场景：
     * - 当两家都出合法牌型时，需要判断谁大谁小
     * - 例如：炸弹 vs 三连对，谁的牌更大？
     *
     * @param cards1 我的牌
     * @param cards2 对家的牌
     * @param levelCard 当前级牌
     * @return cards1 是否大于 cards2（true表示我的牌更大）
     */
    boolean compareCards(List<Integer> cards1, List<Integer> cards2, int levelCard);

    /**
     * 判断牌型
     *
     * 使用场景：
     * - 需要向玩家显示这组牌是什么牌型（例如："三连对"、"炸弹"）
     *
     * @param cards 牌组
     * @param levelCard 当前级牌（例如：2表示级牌是2，14表示小王）
     * @return 牌型枚举（例如：SINGLE, PAIR, TRIPLE, STRAIGHT, BOMB, ...）
     */
    CardType getCardType(List<Integer> cards, int levelCard);

    /**
     * 判断游戏是否结束
     *
     * 使用场景：
     * - 每次出牌后，需要检查是否有玩家手牌出完
     * - 如果有玩家手牌出完，游戏结束
     *
     * @param handCardsMap 所有玩家的手牌（playerId -> 手牌列表）
     * @return 游戏结果（如果游戏未结束，返回null）
     */
    GameResult checkGameOver(Map<String, List<Integer>> handCardsMap);

    /**
     * 计算当前级牌
     *
     * 使用场景：
     * - 游戏开始时，需要确定当前级牌
     * - 一局结束后，需要计算下一局的级牌
     *
     * @param currentLevel 当前级数（2-A对应3-15）
     * @param isUpgrade 是否升级（赢家升1级，输家不变）
     * @return 下一局的级牌点数
     */
    int calculateNextLevel(int currentLevel, boolean isUpgrade);

    /**
     * 计算游戏积分
     *
     * 使用场景：
     * - 游戏结束后，根据输赢情况计算积分
     * - 例如：一级过：赢家+3分，输家-3分
     *
     * @param winnerId 赢家玩家ID
     * @param level 当前级数
     * @param isTeamWin 是否是团队胜利（我的队友赢了）
     * @return 积分变化（正数表示加分，负数表示扣分）
     */
    int calculateScore(String winnerId, int level, boolean isTeamWin);

    /**
     * 游戏结果
     */
    class GameResult {
        private String winnerId;      // 赢家玩家ID
        private boolean isTeamWin;    // 是否是团队胜利
        private int level;            // 当前级数
        private int scoreChange;      // 积分变化

        public GameResult(String winnerId, boolean isTeamWin, int level, int scoreChange) {
            this.winnerId = winnerId;
            this.isTeamWin = isTeamWin;
            this.level = level;
            this.scoreChange = scoreChange;
        }

        public String getWinnerId() {
            return winnerId;
        }

        public boolean isTeamWin() {
            return isTeamWin;
        }

        public int getLevel() {
            return level;
        }

        public int getScoreChange() {
            return scoreChange;
        }
    }
}
