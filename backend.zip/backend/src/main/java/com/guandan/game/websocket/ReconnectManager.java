package com.guandan.game.websocket;

import com.guandan.game.model.GameRoom;
import com.guandan.game.service.GameLogicService;
import com.guandan.game.dto.WebSocketMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 重连管理器
 * 负责人：成员B（通讯与架构）
 *
 * 功能：
 * 1. 处理玩家断线重连
 * 2. 恢复游戏状态
 * 3. 同步玩家数据
 */
@Slf4j
@Component
public class ReconnectManager {

    @Autowired
    private SessionManager sessionManager;

    @Autowired
    private GameLogicService gameLogicService;

    /**
     * 处理重连请求
     *
     * @param playerId 玩家ID
     * @return 重连结果消息
     */
    public WebSocketMessage handleReconnect(String playerId) {
        log.info("玩家 {} 请求重连", playerId);

        // 检查会话是否存在
        SessionManager.SessionInfo sessionInfo = sessionManager.getSession(playerId);

        if (sessionInfo == null) {
            log.warn("玩家 {} 不存在会话记录，无法重连", playerId);
            return WebSocketMessage.error("会话不存在，请重新加入房间");
        }

        // 检查是否已经在游戏中
        String roomId = sessionInfo.getRoomId();
        
        if (roomId == null || roomId.isEmpty()) {
            log.warn("玩家 {} 不在任何房间中", playerId);
            return WebSocketMessage.error("您不在任何房间中，请先加入房间");
        }
        
        GameRoom room = gameLogicService.getRoom(roomId);

        if (room == null) {
            log.warn("玩家 {} 的房间 {} 不存在", playerId, roomId);
            return WebSocketMessage.error("房间不存在");
        }

        // 标记为在线
        boolean reconnected = sessionManager.reconnect(playerId);

        if (!reconnected) {
            log.warn("玩家 {} 重连失败：会话状态异常", playerId);
            return WebSocketMessage.error("重连失败");
        }

        // 构建重连响应数据
        ReconnectData data = new ReconnectData();
        data.setPlayerId(playerId);
        data.setRoomId(roomId);
        data.setRoomStatus(room.getStatus().name());

        // 恢复手牌数据
        if (room.getStatus() == GameRoom.GameStatus.PLAYING) {
            java.util.List<Integer> myCards = room.getHandCards().get(playerId);
            data.setMyCards(myCards);
            data.setCurrentPlayerIndex(room.getCurrentPlayerIndex());
            data.setReconnectMessage("欢迎回来！游戏进行中");
        } else {
            data.setReconnectMessage("欢迎回来！等待游戏开始");
        }

        log.info("玩家 {} 重连成功，房间={}, 状态={}", playerId, roomId, room.getStatus());
        return new WebSocketMessage("RECONNECT_SUCCESS", data);
    }

    /**
     * 保存游戏状态（用于断线后恢复）
     * MVP版本：游戏状态已在GameLogicService的内存中维护
     * 扩展版本：可保存到数据库
     *
     * @param roomId 房间ID
     */
    public void saveGameState(String roomId) {
        // MVP版本：GameLogicService已经在内存中维护游戏状态
        // 扩展版本：可以在这里保存到数据库
        log.debug("保存房间 {} 的游戏状态", roomId);

        // TODO: 扩展功能 - 将GameRoom状态序列化到数据库
        // 1. 获取房间状态
        // GameRoom room = gameLogicService.getRoom(roomId);
        // 2. 保存到数据库
        // gameRecordRepository.save(room);
    }

    /**
     * 从数据库恢复游戏状态
     * MVP版本：暂不实现
     * 扩展版本：从数据库读取GameRoom状态并恢复
     *
     * @param roomId 房间ID
     * @return 是否恢复成功
     */
    public boolean restoreGameState(String roomId) {
        // MVP版本：暂不实现
        log.debug("恢复房间 {} 的游戏状态（暂未实现）", roomId);

        // TODO: 扩展功能 - 从数据库恢复游戏状态
        // 1. 从数据库读取
        // GameRoom room = gameRecordRepository.findByRoomId(roomId);
        // 2. 恢复到GameLogicService
        // gameLogicService.restoreRoom(room);
        // 3. 恢复玩家手牌
        // gameLogicService.restoreHandCards(room);

        return false;
    }

    /**
     * 重连数据
     */
    @lombok.Data
    public static class ReconnectData {
        private String playerId;
        private String roomId;
        private String roomStatus;
        private java.util.List<Integer> myCards;
        private Integer currentPlayerIndex;
        private String reconnectMessage;
    }
}
