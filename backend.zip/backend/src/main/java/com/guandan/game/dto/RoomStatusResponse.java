package com.guandan.game.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 房间状态响应
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoomStatusResponse {
    private String roomId;          // 房间ID
    private String status;          // 房间状态：WAITING（等待中）、PLAYING（游戏中）、FINISHED（已结束）
    private int playerCount;        // 当前玩家数量
    private int maxPlayers;         // 最大玩家数量（4）
    private String message;         // 提示信息
}
