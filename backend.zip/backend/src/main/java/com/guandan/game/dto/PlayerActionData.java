package com.guandan.game.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

/**
 * 玩家出牌广播消息的数据部分
 * 负责人：成员A（核心引擎与逻辑）
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlayerActionData {
    /**
     * 出牌的玩家ID
     */
    private String playerId;

    /**
     * 出的卡牌ID列表
     */
    private List<Integer> cards;
}
