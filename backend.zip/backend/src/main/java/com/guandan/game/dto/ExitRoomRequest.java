package com.guandan.game.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 退出房间请求
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExitRoomRequest {
    private String playerId;        // 玩家ID
    private String roomId;          // 房间ID
}
