package com.guandan.game.websocket;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.guandan.game.config.WebSocketServerConfigurator;
import com.guandan.game.dto.*;
import com.guandan.game.model.GameRoom;
import com.guandan.game.service.AIService;
import com.guandan.game.service.GameLogicService;
import com.guandan.game.util.CardUtils;
import com.guandan.entity.User;
import com.guandan.mapper.UserMapper;
import com.guandan.service.GameReferee;
import com.guandan.model.CardType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jakarta.websocket.*;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * WebSocket服务器端点（增强版）
 * 负责人：成员A（核心引擎与逻辑） + 成员B（通讯与架构）
 *
 * 功能：
 * 1. 处理客户端连接、消息接收和广播
 * 2. 心跳检测
 * 3. 断线重连
 * 4. 会话管理
 * 5. 跨域支持
 */
@Slf4j
@Component
@ServerEndpoint(
    value = "/ws/game/{playerId}",
    configurator = WebSocketServerConfigurator.class
)
public class GameWebSocketServer {

    /**
     * JSON解析器
     */
    private static final ObjectMapper objectMapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

    /**
     * 游戏服务（通过静态方式注入，因为WebSocket是单例）
     */
    private static GameLogicService gameLogicService;

    /**
     * 会话管理器
     */
    private static SessionManager sessionManager;

    /**
     * 重连管理器
     */
    private static ReconnectManager reconnectManager;

    /**
     * AI服务
     */
    private static AIService aiService;

    /**
     * 游戏裁判服务（规则验证）
     */
    private static GameReferee gameReferee;

    /**
     * 用户Mapper
     */
    private static UserMapper userMapper;

    /**
     * 房间服务
     */
    private static com.guandan.service.RoomService roomService;

    @Autowired
    public void setGameLogicService(GameLogicService gameLogicService) {
        GameWebSocketServer.gameLogicService = gameLogicService;
    }

    public static void broadcastTableClear(String gameRoomId) {
        if (gameLogicService == null) {
            return;
        }

        try {
            GameRoom gameRoom = gameLogicService.getRoom(gameRoomId);
            if (gameRoom == null) {
                return;
            }

            WebSocketMessage msg = new WebSocketMessage("TABLE_CLEAR", new java.util.HashMap<>());
            for (String playerId : gameRoom.getPlayerIds()) {
                sendToPlayer(playerId, msg);
            }
        } catch (Exception e) {
            log.warn("广播清桌面失败: roomId={}", gameRoomId, e);
        }
    }

    public static void broadcastGameStartStatic(String gameRoomId) {
        if (gameLogicService == null) {
            log.warn("服务未初始化，无法广播游戏开始");
            return;
        }
        GameRoom room = gameLogicService.getRoom(gameRoomId);
        if (room == null) {
            log.warn("广播游戏开始失败：房间不存在 roomId={}", gameRoomId);
            return;
        }

        if (room.getPlayerIds() == null || room.getPlayerIds().isEmpty()) {
            log.warn("游戏开始广播失败：房间没有玩家");
            return;
        }

        for (int i = 0; i < room.getPlayerIds().size(); i++) {
            String playerId = room.getPlayerIds().get(i);
            try {
                List<Integer> myCards = room.getHandCards().get(playerId);
                if (myCards == null) {
                    continue;
                }

                Map<String, String> playerPositions = new java.util.HashMap<>();
                playerPositions.put("我", playerId);
                playerPositions.put("右对手", room.getPlayerIds().get((i + 1) % 4));
                playerPositions.put("队友", room.getPlayerIds().get((i + 2) % 4));
                playerPositions.put("左对手", room.getPlayerIds().get((i + 3) % 4));

                GameStartData startData = new GameStartData();
                startData.setMyCards(myCards);
                startData.setPlayerId(playerId);
                startData.setRoomId(room.getRoomId());
                startData.setLevelCard(room.getLevelCardRank());
                startData.setPlayerPositions(playerPositions);

                sendToPlayer(playerId, new WebSocketMessage("GAME_START", startData));
            } catch (Exception e) {
                log.error("向玩家 {} 发送游戏开始消息失败", playerId, e);
            }
        }
    }

    public static void broadcastInitialTurnStatic(String gameRoomId) {
        if (gameLogicService == null) {
            log.warn("服务未初始化，无法广播回合信息");
            return;
        }
        GameRoom room = gameLogicService.getRoom(gameRoomId);
        if (room == null) {
            return;
        }

        String currentPlayerId = room.getCurrentPlayerId();
        if (currentPlayerId == null) {
            return;
        }

        for (String playerId : room.getPlayerIds()) {
            WebSocketMessage.TurnChangeData turnData = new WebSocketMessage.TurnChangeData();
            turnData.setCurrentPlayerId(currentPlayerId);
            turnData.setMyTurn(playerId.equals(currentPlayerId));
            sendToPlayer(playerId, WebSocketMessage.turnChange(turnData));
        }
    }

    private static List<Map<String, Object>> buildPlayerInfos(List<com.guandan.entity.RoomPlayer> roomPlayers) {
        List<Map<String, Object>> players = new java.util.ArrayList<>();
        if (roomPlayers == null) {
            return players;
        }

        for (com.guandan.entity.RoomPlayer rp : roomPlayers) {
            Map<String, Object> info = new java.util.HashMap<>();
            info.put("userId", rp.getUserId());
            info.put("seatIndex", rp.getSeatIndex());
            info.put("isReady", rp.getIsReady());

            User user = null;
            try {
                if (userMapper != null && rp.getUserId() != null) {
                    user = userMapper.selectById(rp.getUserId());
                }
            } catch (Exception ignored) {
            }

            if (user != null) {
                info.put("username", user.getUsername());
                info.put("nickname", user.getNickname());
                info.put("avatar", user.getAvatar());
            }

            int online = 0;
            try {
                if (sessionManager != null && rp.getUserId() != null) {
                    online = sessionManager.isOnline(String.valueOf(rp.getUserId())) ? 1 : 0;
                } else if (user != null && user.getOnline() != null) {
                    online = user.getOnline();
                }
            } catch (Exception ignored) {
            }
            info.put("online", online);
            players.add(info);
        }

        return players;
    }

    @Autowired
    public void setSessionManager(SessionManager sessionManager) {
        GameWebSocketServer.sessionManager = sessionManager;
    }

    @Autowired
    public void setReconnectManager(ReconnectManager reconnectManager) {
        GameWebSocketServer.reconnectManager = reconnectManager;
    }

    @Autowired
    public void setGameReferee(GameReferee gameReferee) {
        GameWebSocketServer.gameReferee = gameReferee;
    }

    @Autowired
    public void setAIService(AIService aiService) {
        GameWebSocketServer.aiService = aiService;
    }

    @Autowired
    public void setUserMapper(UserMapper userMapper) {
        GameWebSocketServer.userMapper = userMapper;
    }

    @Autowired
    public void setRoomService(com.guandan.service.RoomService roomService) {
        GameWebSocketServer.roomService = roomService;
    }

    /**
     * 连接建立时调用
     */
    @OnOpen
    public void onOpen(Session session, @PathParam("playerId") String playerId) {
        log.info("WebSocket连接建立: playerId={}, sessionId={}", playerId, session.getId());

        // 检查依赖是否已注入
        if (gameLogicService == null || sessionManager == null) {
            log.error("服务未注入，无法处理连接");
            try {
                session.close(new CloseReason(CloseReason.CloseCodes.UNEXPECTED_CONDITION, "服务未就绪"));
            } catch (IOException e) {
                log.error("关闭连接失败", e);
            }
            return;
        }

        // 保存WebSocket Session引用到SessionManager
        sessionManager.saveSession(playerId, session);

        // 检查是否是重连
        SessionManager.SessionInfo existingSession = sessionManager.getSession(playerId);
        String roomId;

        if (existingSession != null && !existingSession.isOnline()) {
            // 重连场景
            log.info("玩家 {} 检测到重连，恢复会话", playerId);
            roomId = existingSession.getRoomId();

            // 如果玩家之前在房间中，恢复房间信息
            if (roomId != null && !roomId.isEmpty()) {
                // 检查房间是否还存在
                GameRoom room = gameLogicService.getRoom(roomId);
                if (room != null) {
                    // 恢复玩家到房间
                    gameLogicService.joinRoom(playerId, roomId);
                    sessionManager.reconnect(playerId);
                    
                    // 发送重连成功消息
                    WebSocketMessage reconnectMsg = reconnectManager.handleReconnect(playerId);
                    sendMessage(session, playerId, reconnectMsg);
                } else {
                    log.warn("玩家 {} 重连失败，房间 {} 不存在", playerId, roomId);
                    // 房间不存在，清除房间信息
                    sessionManager.addSession(playerId, null);
                }
            } else {
                log.info("玩家 {} 重连，但之前不在任何房间中", playerId);
                sessionManager.reconnect(playerId);
            }
        } else {
            // 新连接场景 - 不自动加入房间，等待客户端主动加入
            log.info("玩家 {} 建立新连接，等待加入房间", playerId);
            sessionManager.addSession(playerId, null);
        }
    }

    /**
     * 接收客户端消息
     */
    @OnMessage
    public void onMessage(String message, Session session, @PathParam("playerId") String playerId) {
        log.debug("收到消息 from {}: {}", playerId, message);

        try {
            if (message == null || message.trim().isEmpty()) {
                log.warn("收到空消息 from {}", playerId);
                return;
            }

            // 解析JSON消息
            WebSocketMessage wsMessage = objectMapper.readValue(message, WebSocketMessage.class);
            
            if (wsMessage == null) {
                log.warn("消息解析失败，结果为 null from {}", playerId);
                sendToPlayer(playerId, WebSocketMessage.error("消息格式错误"));
                return;
            }

            String type = wsMessage.getType();
            
            if (type == null || type.trim().isEmpty()) {
                log.warn("消息类型为空 from {}: {}", playerId, message);
                sendToPlayer(playerId, WebSocketMessage.error("消息类型不能为空"));
                return;
            }

            switch (type) {
                case "PLAY_CARD":
                    handlePlayCard(playerId, wsMessage.getData());
                    break;
                case "JOIN_ROOM":
                    handleJoinRoom(playerId, wsMessage.getData());
                    break;
                case "HEARTBEAT":
                    handleHeartbeat(playerId);
                    break;
                case "RECONNECT":
                    handleReconnect(playerId);
                    break;
                case "START_GAME":
                    handleStartGame(playerId, wsMessage.getData());
                    break;
                case "GAME_OVER":
                    handleGameOver(playerId, wsMessage.getData());
                    break;
                case "SUGGEST_CARDS":
                    handleSuggestCards(playerId, wsMessage.getData());
                    break;
                case "CHAT_MESSAGE":
                    handleChatMessage(playerId, wsMessage.getData());
                    break;
                default:
                    log.warn("未知的消息类型: {}", type);
                    sendToPlayer(playerId, WebSocketMessage.error("未知的消息类型: " + type));
            }
        } catch (Exception e) {
            log.error("处理消息时发生错误, message: {}", message, e);
            sendToPlayer(playerId, WebSocketMessage.error("消息解析错误: " + e.getMessage()));
        }
    }

    /**
     * 处理心跳消息
     */
    private void handleHeartbeat(String playerId) {
        sessionManager.updateHeartbeat(playerId);
        log.debug("玩家 {} 心跳更新", playerId);
        
        // 发送心跳响应
        Session session = sessionManager.getWebSocketSession(playerId);
        if (session != null && session.isOpen()) {
            try {
                String json = objectMapper.writeValueAsString(new WebSocketMessage("pong", null));
                session.getBasicRemote().sendText(json);
                log.debug("发送心跳响应给玩家 {}", playerId);
            } catch (Exception e) {
                log.debug("发送心跳响应失败: playerId={}", playerId);
            }
        }
    }

    /**
     * 处理重连请求
     */
    private void handleReconnect(String playerId) {
        WebSocketMessage message = reconnectManager.handleReconnect(playerId);
        sendToPlayer(playerId, message);
    }

    /**
     * 处理出牌消息
     */
    private void handlePlayCard(String playerId, Object data) {
        if (gameLogicService == null) {
            sendToPlayer(playerId, WebSocketMessage.error("服务器未就绪"));
            return;
        }

        try {
            // 将data转换为PlayCardData
            PlayCardData playCardData = objectMapper.convertValue(data, PlayCardData.class);
            List<Integer> cardIds = playCardData.getCards();

            // 执行出牌逻辑
            boolean success = gameLogicService.playCards(playerId, cardIds);

            if (success) {
                // 获取房间信息
                GameRoom room = gameLogicService.getPlayerRoom(playerId);
                if (room != null) {
                    // 广播给房间内所有玩家（包括出牌玩家自己）
                    PlayerActionData actionData = new PlayerActionData(playerId, cardIds);
                    WebSocketMessage playerActionMsg = WebSocketMessage.playerAction(actionData);

                    // 发送给所有玩家
                    for (String player : room.getPlayerIds()) {
                        sendToPlayer(player, playerActionMsg);
                    }

                    // 切换到下一回合，处理AI玩家出牌
                    String nextPlayerId = gameLogicService.nextTurn(room);
                    log.info("下一回合玩家: {}", nextPlayerId);

                    // 发送回合更新消息给所有玩家
                    if (nextPlayerId != null) {
                        for (String player : room.getPlayerIds()) {
                            WebSocketMessage.TurnChangeData turnData = new WebSocketMessage.TurnChangeData();
                            turnData.setCurrentPlayerId(nextPlayerId);
                            turnData.setMyTurn(player.equals(nextPlayerId));
                            WebSocketMessage turnMsg = WebSocketMessage.turnChange(turnData);
                            sendToPlayer(player, turnMsg);
                        }
                    }
                }
            } else {
                // 获取房间信息，用于判断具体错误
                GameRoom room = gameLogicService.getPlayerRoom(playerId);
                if (room != null) {
                    // 首先检查是否是当前玩家的回合
                    String currentPlayerId = room.getCurrentPlayerId();
                    if (!playerId.equals(currentPlayerId)) {
                        sendToPlayer(playerId, WebSocketMessage.error("现在不是你的回合！"));
                        return;
                    }

                    List<Integer> hand = room.getPlayerHandCards(playerId);
                    List<Integer> lastHand = room.getLastHandCards();
                    int levelCardRank = room.getLevelCardRank();

                    // 判断具体错误类型（排除不出牌的情况）
                    if (cardIds == null) {
                        sendToPlayer(playerId, WebSocketMessage.error("请选择要出的牌"));
                    } else if (hand == null || !hand.containsAll(cardIds)) {
                        sendToPlayer(playerId, WebSocketMessage.error("手牌中不包含指定的卡牌"));
                    } else if (!gameReferee.isValidHand(cardIds, levelCardRank)) {
                        sendToPlayer(playerId, WebSocketMessage.error("牌型不合法，请检查出牌规则"));
                    } else if (lastHand != null && !lastHand.isEmpty() && !gameReferee.canBeat(lastHand, cardIds, levelCardRank)) {
                        log.info("出牌被判定太小: playerId={}, lastHand={}, currentHand={}",
                                playerId,
                                java.util.Arrays.toString(CardUtils.idsToStrings(lastHand.stream().mapToInt(i -> i).toArray())),
                                java.util.Arrays.toString(CardUtils.idsToStrings(cardIds.stream().mapToInt(i -> i).toArray())));
                        sendToPlayer(playerId, WebSocketMessage.error("牌太小，无法管住上一手牌"));
                    } else {
                        sendToPlayer(playerId, WebSocketMessage.error("出牌失败，请重试"));
                    }
                } else {
                    sendToPlayer(playerId, WebSocketMessage.error("出牌失败：房间不存在"));
                }
            }
        } catch (Exception e) {
            log.error("处理出牌消息时发生错误", e);
            sendToPlayer(playerId, WebSocketMessage.error("出牌处理错误: " + e.getMessage()));
        }
    }

    /**
     * 处理游戏开始请求
     */
    private void handleStartGame(String playerId, Object data) {
        if (gameLogicService == null) {
            sendToPlayer(playerId, WebSocketMessage.error("服务器未就绪"));
            return;
        }

        try {
            // 解析房间ID
            String roomId = "default_room"; // 默认房间
            try {
                // 尝试解析data中的roomId
                com.fasterxml.jackson.databind.JsonNode node = objectMapper.valueToTree(data);
                if (node.has("roomId")) {
                    roomId = node.get("roomId").asText();
                    // 如果roomId不是以"room_"开头，添加前缀
                    if (roomId != null && !roomId.isEmpty() && !roomId.startsWith("room_")) {
                        roomId = "room_" + roomId;
                    }
                }
            } catch (Exception e) {
                log.warn("解析房间ID失败，使用默认房间", e);
            }

            // 校验：需要所有玩家准备好才允许开始
            try {
                if (roomService != null) {
                    String roomNo = roomId.replace("room_", "");
                    com.guandan.entity.Room dbRoom = roomService.getRoomByRoomNo(roomNo);
                    if (dbRoom != null) {
                        try {
                            Long uid = Long.parseLong(playerId);
                            if (dbRoom.getCreatorId() != null && !dbRoom.getCreatorId().equals(uid)) {
                                sendToPlayer(playerId, WebSocketMessage.error("只有房主可以开始游戏"));
                                return;
                            }
                        } catch (Exception e) {
                            sendToPlayer(playerId, WebSocketMessage.error("用户信息异常，无法开始游戏"));
                            return;
                        }

                        List<com.guandan.entity.RoomPlayer> roomPlayers = roomService.getRoomPlayers(dbRoom.getId());
                        if (roomPlayers.size() < 2) {
                            sendToPlayer(playerId, WebSocketMessage.error("等待更多玩家加入"));
                            return;
                        }
                        Long creatorId = dbRoom.getCreatorId();
                        boolean allReady = roomPlayers.stream().allMatch(p -> {
                            if (creatorId != null && creatorId.equals(p.getUserId())) {
                                return true;
                            }
                            return p.getIsReady() != null && p.getIsReady() == 1;
                        });
                        if (!allReady) {
                            sendToPlayer(playerId, WebSocketMessage.error("还有玩家未准备"));
                            return;
                        }
                    }
                }
            } catch (Exception e) {
                log.warn("校验准备状态失败", e);
            }

            // 调用游戏逻辑服务开始游戏
            boolean started = gameLogicService.startGame(roomId);
            if (started) {
                // 获取房间信息
                GameRoom room = gameLogicService.getRoom(roomId);
                if (room != null) {
                    // 向所有玩家发送游戏开始消息
                    broadcastGameStart(room);
                    broadcastInitialTurnStatic(roomId);
                }
                log.info("房间 {} 游戏开始", roomId);
            } else {
                log.warn("房间 {} 游戏开始失败", roomId);
                sendToPlayer(playerId, WebSocketMessage.error("游戏开始失败，请稍后重试"));
            }
        } catch (Exception e) {
            log.error("处理游戏开始请求时发生错误", e);
            sendToPlayer(playerId, WebSocketMessage.error("游戏开始处理错误: " + e.getMessage()));
        }
    }

    /**
     * 处理游戏结束请求
     */
    private void handleGameOver(String playerId, Object data) {
        if (gameLogicService == null) {
            sendToPlayer(playerId, WebSocketMessage.error("服务器未就绪"));
            return;
        }

        try {
            // 解析房间ID
            String roomId = null;
            try {
                // 尝试解析data中的roomId
                com.fasterxml.jackson.databind.JsonNode node = objectMapper.valueToTree(data);
                if (node.has("roomId")) {
                    roomId = node.get("roomId").asText();
                }
            } catch (Exception e) {
                log.warn("解析房间ID失败", e);
            }

            // 获取房间信息
            GameRoom room = null;
            if (roomId != null) {
                room = gameLogicService.getRoom(roomId);
            }
            if (room == null) {
                // 如果通过roomId找不到房间，尝试通过playerId获取
                room = gameLogicService.getPlayerRoom(playerId);
            }
            if (room != null) {
                // 更新游戏状态为已结束
                room.setStatus(GameRoom.GameStatus.FINISHED);
                log.info("房间 {} 游戏结束", room.getRoomId());
            } else {
                log.warn("无法找到玩家 {} 所在的房间", playerId);
            }
        } catch (Exception e) {
            log.error("处理游戏结束请求时发生错误", e);
            sendToPlayer(playerId, WebSocketMessage.error("游戏结束处理错误: " + e.getMessage()));
        }
    }

    /**
     * 处理加入房间消息
     */
    private void handleJoinRoom(String playerId, Object data) {
        if (gameLogicService == null) {
            sendToPlayer(playerId, WebSocketMessage.error("服务器未就绪"));
            return;
        }

        // 解析房间ID
        String roomId = "default_room"; // 默认房间
        try {
            // 尝试解析data中的roomId
            com.fasterxml.jackson.databind.JsonNode node = objectMapper.valueToTree(data);
            if (node.has("roomId")) {
                roomId = node.get("roomId").asText();
                // 如果roomId不是以"room_"开头，添加前缀
                if (roomId != null && !roomId.isEmpty() && !roomId.startsWith("room_")) {
                    roomId = "room_" + roomId;
                }
            }
        } catch (Exception e) {
            log.warn("解析房间ID失败，使用默认房间", e);
        }

        // 检查玩家是否已经在游戏中
        GameRoom existingRoom = gameLogicService.getPlayerRoom(playerId);
        if (existingRoom != null) {
            // 如果玩家已经在同一个房间中，直接返回成功
            if (existingRoom.getRoomId().equals(roomId)) {
                log.info("玩家 {} 已经在房间 {} 中", playerId, roomId);
                sendToPlayer(playerId, new WebSocketMessage("JOIN_ROOM_SUCCESS", 
                    java.util.Map.of("roomId", roomId, "message", "已在房间中")));
                return;
            }
            
            // 如果玩家在其他房间中，且该房间正在游戏中，阻止加入
            if (existingRoom.getStatus() == GameRoom.GameStatus.PLAYING) {
                log.warn("玩家 {} 正在游戏中，无法加入其他房间", playerId);
                sendToPlayer(playerId, WebSocketMessage.error("您正在游戏中，无法加入其他房间"));
                return;
            }
            
            // 如果玩家在其他房间中，但游戏未开始，先移除玩家
            log.info("玩家 {} 从房间 {} 移除，准备加入新房间", playerId, existingRoom.getRoomId());
            gameLogicService.removePlayer(playerId);
        }

        // 加入房间
        GameRoom room = gameLogicService.joinRoom(playerId, roomId);

        // 更新SessionManager中的房间信息
        sessionManager.updatePlayerRoom(playerId, roomId);

        // 发送加入房间成功消息
        Map<String, Object> joinSuccessData = new java.util.HashMap<>();
        joinSuccessData.put("roomId", roomId);
        joinSuccessData.put("message", "加入房间成功");
        sendToPlayer(playerId, new WebSocketMessage("JOIN_ROOM_SUCCESS", joinSuccessData));

        // 广播房间人数更新给房间内所有玩家
        broadcastRoomInfoUpdate(roomId);

        // 正常环境：不自动开始游戏，等待玩家点击就绪
        // 测试环境自动开始游戏功能已禁用
    }

    /**
     * 广播房间信息更新（人数、准备状态）
     * 静态方法，供其他类调用
     */
    public static void broadcastRoomInfoUpdateStatic(String gameRoomId) {
        if (gameLogicService == null || roomService == null) {
            log.warn("服务未初始化，无法广播房间更新");
            return;
        }
        
        try {
            GameRoom gameRoom = gameLogicService.getRoom(gameRoomId);
            if (gameRoom == null) {
                return;
            }

            // 解析房间号，获取数据库中的房间信息
            String roomNo = gameRoomId.replace("room_", "");
            com.guandan.entity.Room dbRoom = roomService.getRoomByRoomNo(roomNo);
            if (dbRoom == null) {
                return;
            }

            // 获取房间玩家列表
            List<com.guandan.entity.RoomPlayer> roomPlayers = roomService.getRoomPlayers(dbRoom.getId());
            List<Map<String, Object>> players = buildPlayerInfos(roomPlayers);
            int playerCount = players.size();

            // 构建房间更新消息
            Map<String, Object> updateData = new java.util.HashMap<>();
            updateData.put("playerCount", playerCount);
            updateData.put("players", players);
            updateData.put("roomNo", roomNo);
            updateData.put("roomId", gameRoomId);
            updateData.put("creatorId", dbRoom.getCreatorId());

            // 向房间内所有玩家广播
            WebSocketMessage updateMessage = new WebSocketMessage("ROOM_UPDATE", updateData);
            for (String playerId : gameRoom.getPlayerIds()) {
                sendToPlayer(playerId, updateMessage);
            }

            log.info("房间 {} 信息已广播：人数={}", gameRoomId, playerCount);
        } catch (Exception e) {
            log.error("广播房间信息更新失败: roomId={}", gameRoomId, e);
        }
    }

    /**
     * 广播游戏结束
     * 静态方法，供其他类调用
     */
    public static void broadcastGameEnd(String gameRoomId, Long winnerId, Integer score, Integer levelTeamA, Integer levelTeamB) {
        if (gameLogicService == null) {
            log.warn("服务未初始化，无法广播游戏结束");
            return;
        }
        
        try {
            // 构建游戏结束消息
            Map<String, Object> endData = new java.util.HashMap<>();
            endData.put("winnerId", winnerId);
            endData.put("score", score);
            endData.put("roomId", gameRoomId);
            
            // 添加队伍级牌信息（使用传入的参数）
            endData.put("levelTeamA", levelTeamA);
            endData.put("levelTeamB", levelTeamB);

            // 向房间内所有玩家广播
            WebSocketMessage endMessage = new WebSocketMessage("GAME_END", endData);
            for (String playerId : gameLogicService.getPlayerIdsInRoom(gameRoomId)) {
                sendToPlayer(playerId, endMessage);
            }

            log.info("房间 {} 游戏结束已广播：获胜者={}, 分数={}, A队级牌={}, B队级牌={}", 
                    gameRoomId, winnerId, score, levelTeamA, levelTeamB);
        } catch (Exception e) {
            log.error("广播游戏结束失败: roomId={}", gameRoomId, e);
        }
    }

    /**
     * 广播房间信息更新（人数、准备状态）
     */
    private void broadcastRoomInfoUpdate(String gameRoomId) {
        try {
            GameRoom gameRoom = gameLogicService.getRoom(gameRoomId);
            if (gameRoom == null) {
                return;
            }

            // 解析房间号，获取数据库中的房间信息
            String roomNo = gameRoomId.replace("room_", "");
            com.guandan.entity.Room dbRoom = roomService.getRoomByRoomNo(roomNo);
            if (dbRoom == null) {
                return;
            }

            // 获取房间玩家列表
            List<com.guandan.entity.RoomPlayer> roomPlayers = roomService.getRoomPlayers(dbRoom.getId());
            List<Map<String, Object>> players = buildPlayerInfos(roomPlayers);
            int playerCount = players.size();

            // 构建房间更新消息
            Map<String, Object> updateData = new java.util.HashMap<>();
            updateData.put("playerCount", playerCount);
            updateData.put("players", players);
            updateData.put("roomNo", roomNo);
            updateData.put("roomId", gameRoomId);

            // 向房间内所有玩家广播
            WebSocketMessage updateMessage = new WebSocketMessage("ROOM_UPDATE", updateData);
            broadcastToRoom(gameRoomId, updateMessage);

            log.info("房间 {} 信息已广播：人数={}", gameRoomId, playerCount);
        } catch (Exception e) {
            log.error("广播房间信息更新失败: roomId={}", gameRoomId, e);
        }
    }

    /**
     * 处理出牌提示请求
     */
    private void handleSuggestCards(String playerId, Object data) {
        if (gameLogicService == null) {
            sendToPlayer(playerId, WebSocketMessage.error("服务器未就绪"));
            return;
        }

        try {
            // 获取房间信息
            GameRoom room = gameLogicService.getPlayerRoom(playerId);
            if (room == null) {
                sendToPlayer(playerId, WebSocketMessage.error("您不在任何房间中"));
                return;
            }

            if (room.getStatus() != GameRoom.GameStatus.PLAYING) {
                sendToPlayer(playerId, WebSocketMessage.error("游戏未开始"));
                return;
            }

            // 检查是否是当前玩家的回合
            if (!room.isCurrentPlayer(playerId)) {
                sendToPlayer(playerId, WebSocketMessage.error("不是您的回合"));
                return;
            }

            if (gameReferee == null) {
                sendToPlayer(playerId, new WebSocketMessage("SUGGEST_CARDS_SUCCESS", java.util.Map.of("message", "没有合适的牌可出")));
                return;
            }

            List<Integer> handCards = room.getPlayerHandCards(playerId);
            List<Integer> lastHandCards = room.getLastHandCards();

            boolean freePlay = lastHandCards == null || lastHandCards.isEmpty() || playerId.equals(room.getLastPlayerId());

            java.util.function.BiPredicate<List<Integer>, List<Integer>> containsAllWithCounts = (hand, need) -> {
                if (need == null || need.isEmpty()) return true;
                if (hand == null || hand.isEmpty()) return false;
                java.util.Map<Integer, Integer> cnt = new java.util.HashMap<>();
                for (Integer c : hand) {
                    if (c == null) continue;
                    cnt.put(c, cnt.getOrDefault(c, 0) + 1);
                }
                for (Integer c : need) {
                    if (c == null) return false;
                    Integer v = cnt.get(c);
                    if (v == null || v <= 0) return false;
                    cnt.put(c, v - 1);
                }
                return true;
            };

            java.util.function.Predicate<List<Integer>> isPlayable = (cards) -> {
                if (cards == null || cards.isEmpty()) return false;
                if (!containsAllWithCounts.test(handCards, cards)) return false;
                if (!gameReferee.isValidHand(cards, room.getLevelCardRank())) return false;
                if (freePlay) return true;
                return gameReferee.canBeat(lastHandCards, cards, room.getLevelCardRank());
            };

            // 获取上一次出牌信息
            String lastCardType = room.getLastCardType();
            Integer lastCardValue = room.getLastCardValue();

            // 如果没有上一次出牌，返回自由出牌建议
            if (lastCardType == null || playerId.equals(room.getLastPlayerId())) {
                List<Integer> suggestedCards = aiService.playFirstCard(
                    room.getPlayerHandCards(playerId), 
                    room.getLevelCardRank()
                );

                if (!isPlayable.test(suggestedCards)) {
                    suggestedCards = null;
                }

                if (suggestedCards == null) {
                    List<Integer> single = null;
                    if (handCards != null) {
                        List<Integer> sorted = new java.util.ArrayList<>(handCards);
                        sorted.sort(java.util.Comparator.comparingInt(com.guandan.game.util.CardUtils::getRank).thenComparingInt(Integer::intValue));
                        for (Integer c : sorted) {
                            List<Integer> candidate = java.util.Collections.singletonList(c);
                            if (isPlayable.test(candidate)) {
                                single = candidate;
                                break;
                            }
                        }
                    }
                    suggestedCards = single;
                }

                if (suggestedCards != null) {
                    sendToPlayer(playerId, new WebSocketMessage("SUGGEST_CARDS_SUCCESS", 
                        java.util.Map.of(
                            "cards", suggestedCards,
                            "cardType", CardUtils.getCardType(suggestedCards, room.getLevelCardRank()),
                            "message", "建议出牌"
                        )));
                } else {
                    sendToPlayer(playerId, new WebSocketMessage("SUGGEST_CARDS_SUCCESS", 
                        java.util.Map.of("message", "没有合适的牌可出")));
                }
            } else {
                // 根据上一次出牌类型，寻找合适的牌型回应
                List<Integer> suggestedCards = aiService.findResponseCards(
                    room.getPlayerHandCards(playerId),
                    lastCardType,
                    lastCardValue,
                    room.getLevelCardRank()
                );

                if (!isPlayable.test(suggestedCards)) {
                    suggestedCards = null;
                }

                if (suggestedCards == null) {
                    List<Integer> bombCards = aiService.findBomb(
                        room.getPlayerHandCards(playerId),
                        room.getLevelCardRank()
                    );

                    if (isPlayable.test(bombCards)) {
                        suggestedCards = bombCards;
                    }
                }

                if (suggestedCards == null) {
                    List<Integer> single = null;
                    if (handCards != null) {
                        List<Integer> sorted = new java.util.ArrayList<>(handCards);
                        sorted.sort(java.util.Comparator.comparingInt(com.guandan.game.util.CardUtils::getRank).thenComparingInt(Integer::intValue));
                        for (Integer c : sorted) {
                            List<Integer> candidate = java.util.Collections.singletonList(c);
                            if (isPlayable.test(candidate)) {
                                single = candidate;
                                break;
                            }
                        }
                    }
                    suggestedCards = single;
                }

                if (suggestedCards != null) {
                    sendToPlayer(playerId, new WebSocketMessage("SUGGEST_CARDS_SUCCESS", 
                        java.util.Map.of(
                            "cards", suggestedCards,
                            "cardType", CardUtils.getCardType(suggestedCards, room.getLevelCardRank()),
                            "message", "建议出牌"
                        )));
                } else {
                    sendToPlayer(playerId, new WebSocketMessage("SUGGEST_CARDS_SUCCESS", 
                        java.util.Map.of("message", "没有合适的牌可出")));
                }
            }
        } catch (Exception e) {
            log.error("处理出牌提示请求时发生错误", e);
            sendToPlayer(playerId, WebSocketMessage.error("出牌提示处理错误: " + e.getMessage()));
        }
    }

    private void handleChatMessage(String playerId, Object data) {
        try {
            if (data == null) {
                sendToPlayer(playerId, WebSocketMessage.error("聊天消息不能为空"));
                return;
            }

            Map<String, Object> chatData = (Map<String, Object>) data;
            String message = (String) chatData.get("message");
            String roomId = (String) chatData.get("roomId");

            if (message == null || message.trim().isEmpty()) {
                sendToPlayer(playerId, WebSocketMessage.error("聊天消息不能为空"));
                return;
            }

            log.info("收到聊天消息: playerId={}, roomId={}, message={}", playerId, roomId, message);

            // 获取房间信息
            GameRoom room = gameLogicService.getPlayerRoom(playerId);
            if (room == null) {
                sendToPlayer(playerId, WebSocketMessage.error("您不在任何房间中"));
                return;
            }

            // 获取玩家昵称
            String nickname = getPlayerNickname(playerId);

            // 构造聊天消息数据
            Map<String, Object> chatMessageData = new java.util.HashMap<>();
            chatMessageData.put("playerId", playerId);
            chatMessageData.put("nickname", nickname);
            chatMessageData.put("message", message);
            chatMessageData.put("type", chatData.getOrDefault("type", "quick"));
            chatMessageData.put("timestamp", System.currentTimeMillis());

            // 向房间内所有玩家广播聊天消息
            broadcastToRoom(room.getRoomId(), new WebSocketMessage("CHAT_MESSAGE", chatMessageData));

            log.info("聊天消息已广播: roomId={}, playerId={}, message={}", room.getRoomId(), playerId, message);
        } catch (Exception e) {
            log.error("处理聊天消息时发生错误", e);
            sendToPlayer(playerId, WebSocketMessage.error("聊天消息处理错误: " + e.getMessage()));
        }
    }

    /**
     * 连接关闭时调用
     */
    @OnClose
    public void onClose(Session session, CloseReason closeReason, @PathParam("playerId") String playerId) {
        log.info("WebSocket连接关闭: playerId={}, sessionId={}, closeReason={}", playerId, session.getId(), closeReason);

        boolean isNormalClose = false;
        try {
            if (closeReason != null && closeReason.getCloseCode() != null) {
                int code = closeReason.getCloseCode().getCode();
                // 1000 Normal closure / 1001 Going away（关闭页面/刷新常见）
                isNormalClose = (code == 1000 || code == 1001);
            }
        } catch (Exception ignored) {
        }

        GameRoom room = null;
        try {
            room = gameLogicService.getPlayerRoom(playerId);
        } catch (Exception ignored) {
        }

        if (isNormalClose) {
            // 正常关闭：视为主动离开房间（删除房间玩家记录，避免房间一直显示“游戏中”）
            try {
                gameLogicService.removePlayer(playerId);
            } catch (Exception ignored) {
            }
            try {
                sessionManager.removeSession(playerId);
            } catch (Exception ignored) {
            }
        } else {
            // 异常断线：标记离线，保留数据支持重连
            sessionManager.markOffline(playerId);
        }

        // 通知房间内其他玩家（可选）
        if (room != null) {
            PlayerDisconnectData data = new PlayerDisconnectData(playerId, isNormalClose ? "玩家离开" : "玩家掉线");
            WebSocketMessage message = new WebSocketMessage("PLAYER_DISCONNECT", data);
            broadcastToRoom(room, playerId, message);
            broadcastRoomInfoUpdate(room.getRoomId());

            // 房间没人了 / 或者游戏中有人离开：把数据库房间状态置为结束，避免大厅一直显示“游戏中”
            try {
                if (roomService != null) {
                    String roomNo = room.getRoomId().replace("room_", "");
                    com.guandan.entity.Room dbRoom = roomService.getRoomByRoomNo(roomNo);
                    if (dbRoom != null) {
                        int cnt = roomService.getPlayerCount(dbRoom.getId());
                        if (cnt <= 0 || dbRoom.getStatus() == 1) {
                            roomService.updateRoomStatus(dbRoom.getId(), 2);
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }
    }

    /**
     * 发生错误时调用
     */
    @OnError
    public void onError(Session session, Throwable error, @PathParam("playerId") String playerId) {
        // ClosedChannelException是连接关闭时的正常情况，不记录为错误
        if (error instanceof java.nio.channels.ClosedChannelException) {
            log.info("WebSocket连接已关闭: playerId={}", playerId);
        } else {
            log.error("WebSocket错误: playerId={}", playerId, error);
        }

        // 只做清理，避免在 error 回调中再次广播导致循环写失败
        try {
            sessionManager.removeWebSocketSession(playerId);
        } catch (Exception ignored) {
        }
        try {
            sessionManager.markOffline(playerId);
        } catch (Exception ignored) {
        }
    }

    /**
     * 向指定玩家发送消息
     */
    private void sendMessage(Session session, String playerId, WebSocketMessage message) {
        if (session != null && session.isOpen()) {
            try {
                String json = objectMapper.writeValueAsString(message);
                session.getBasicRemote().sendText(json);
                log.debug("发送消息给 {}: {}", playerId, json);
            } catch (java.nio.channels.ClosedChannelException e) {
                log.info("发送消息失败，连接已关闭: playerId={}", playerId);
            } catch (IOException e) {
                log.error("发送消息失败: playerId={}", playerId, e);
            }
        }
    }

    /**
     * 向指定玩家发送消息（通过playerId查找session）
     */
    private static void sendToPlayer(String playerId, WebSocketMessage message) {
        try {
            if (sessionManager == null) {
                log.error("SessionManager未初始化，无法发送消息");
                return;
            }
            
            if (objectMapper == null) {
                log.error("ObjectMapper未初始化，无法发送消息");
                return;
            }
            
            // 从SessionManager获取WebSocket Session
            Session session = sessionManager.getWebSocketSession(playerId);

            if (session == null) {
                log.warn("无法发送消息给玩家 {}：Session不存在或已关闭", playerId);
                return;
            }

            if (!session.isOpen()) {
                log.warn("无法发送消息给玩家 {}：Session已关闭", playerId);
                return;
            }

            // 序列化消息并发送
            String json = objectMapper.writeValueAsString(message);
            session.getBasicRemote().sendText(json);
            log.debug("发送消息给玩家 {}: {}", playerId, json);

        } catch (java.nio.channels.ClosedChannelException | IllegalStateException e) {
            // 连接关闭的竞态：isOpen()判断到send之间可能被关闭，属于正常情况
            log.info("发送消息给玩家 {} 失败，连接已关闭", playerId);
            try {
                if (sessionManager != null) {
                    sessionManager.removeWebSocketSession(playerId);
                    sessionManager.markOffline(playerId);
                }
            } catch (Exception ignored) {
            }
        } catch (IOException e) {
            // Connection reset by peer 等：认为连接已不可用，清理引用避免后续反复发送
            log.info("发送消息给玩家 {} 失败(IO)，清理连接引用", playerId);
            try {
                if (sessionManager != null) {
                    sessionManager.removeWebSocketSession(playerId);
                    sessionManager.markOffline(playerId);
                }
            } catch (Exception ignored) {
            }
        } catch (Exception e) {
            log.error("发送消息给玩家 {} 时发生错误", playerId, e);
        }
    }

    /**
     * 向房间内所有玩家广播游戏开始消息
     */
    private void broadcastGameStart(GameRoom room) {
        if (room == null) {
            log.warn("游戏开始广播失败：房间为空");
            return;
        }

        if (room.getPlayerIds() == null || room.getPlayerIds().isEmpty()) {
            log.warn("游戏开始广播失败：房间没有玩家");
            return;
        }

        int successCount = 0;
        int failCount = 0;

        for (int i = 0; i < room.getPlayerIds().size(); i++) {
            String playerId = room.getPlayerIds().get(i);
            try {
                // 获取玩家手牌
                List<Integer> myCards = room.getHandCards().get(playerId);

                if (myCards == null) {
                    log.error("玩家 {} 的手牌数据不存在", playerId);
                    failCount++;
                    continue;
                }

                // 添加调试日志
                log.info("玩家 {} 的手牌ID列表: {}", playerId, myCards);

                // 构建玩家位置映射（从当前玩家的视角）
                Map<String, String> playerPositions = new java.util.HashMap<>();
                playerPositions.put("我", playerId);
                playerPositions.put("右对手", room.getPlayerIds().get((i + 1) % 4));
                playerPositions.put("队友", room.getPlayerIds().get((i + 2) % 4));
                playerPositions.put("左对手", room.getPlayerIds().get((i + 3) % 4));

                // 构建游戏开始数据
                GameStartData startData = new GameStartData();
                startData.setMyCards(myCards);
                startData.setPlayerId(playerId);
                startData.setRoomId(room.getRoomId());
                startData.setLevelCard(room.getLevelCardRank());
                startData.setPlayerPositions(playerPositions);

                // 构建消息
                WebSocketMessage message = new WebSocketMessage("GAME_START", startData);

                // 发送给玩家
                sendToPlayer(playerId, message);
                successCount++;

                log.info("向玩家 {} 发送游戏开始消息，手牌数: {}, 位置映射: {}", playerId, myCards.size(), playerPositions);

            } catch (Exception e) {
                log.error("向玩家 {} 发送游戏开始消息失败", playerId, e);
                failCount++;
            }
        }

        log.info("房间 {} 游戏开始广播完成：成功={}, 失败={}", room.getRoomId(), successCount, failCount);
    }

    /**
     * 向房间内除指定玩家外的所有玩家广播消息
     */
    private void broadcastToRoom(GameRoom room, String excludePlayerId, WebSocketMessage message) {
        if (room == null || room.getPlayerIds() == null) {
            log.warn("广播消息失败：房间为空或没有玩家");
            return;
        }

        int successCount = 0;
        int failCount = 0;

        for (String playerId : room.getPlayerIds()) {
            if (!playerId.equals(excludePlayerId)) {
                try {
                    sendToPlayer(playerId, message);
                    successCount++;
                } catch (Exception e) {
                    log.error("向玩家 {} 广播消息失败", playerId, e);
                    failCount++;
                }
            }
        }

        log.info("向房间 {} 广播消息完成（排除玩家 {}）：成功={}, 失败={}",
            room.getRoomId(), excludePlayerId, successCount, failCount);
    }

    /**
     * 向房间内所有玩家广播消息
     */
    private void broadcastToRoom(String roomId, WebSocketMessage message) {
        if (roomId == null) {
            log.warn("广播消息失败：房间ID为空");
            return;
        }

        GameRoom room = gameLogicService.getRoom(roomId);
        if (room == null) {
            log.warn("广播消息失败：房间不存在 roomId={}", roomId);
            return;
        }

        int successCount = 0;
        int failCount = 0;

        for (String playerId : room.getPlayerIds()) {
            try {
                sendToPlayer(playerId, message);
                successCount++;
            } catch (Exception e) {
                log.error("向玩家 {} 广播消息失败", playerId, e);
                failCount++;
            }
        }

        log.info("向房间 {} 广播消息完成：成功={}, 失败={}", roomId, successCount, failCount);
    }

    private String getPlayerNickname(String playerId) {
        try {
            Long userId = Long.parseLong(playerId);
            User user = userMapper.selectById(userId);
            return user != null ? user.getNickname() : "玩家" + playerId;
        } catch (Exception e) {
            log.error("获取玩家昵称失败: playerId={}", playerId, e);
            return "玩家" + playerId;
        }
    }
    
    /**
     * 处理AI玩家出牌（静态方法，供GameLogicService调用）
     */
    public static void handleAIPlayCard(String aiPlayerId, List<Integer> cardIds) {
        if (gameLogicService == null || sessionManager == null) {
            log.error("服务未初始化，无法处理AI出牌");
            return;
        }
        
        try {
            // 获取房间信息
            GameRoom room = gameLogicService.getPlayerRoom(aiPlayerId);
            if (room == null) {
                log.error("AI玩家 {} 不在任何房间中", aiPlayerId);
                return;
            }
            
            // 确保cardIds不为null，使用空数组表示不出牌
            if (cardIds == null) {
                cardIds = new java.util.ArrayList<>();
            }
            
            // 广播给房间内所有玩家（只向在线的玩家发送）
            PlayerActionData actionData = new PlayerActionData(aiPlayerId, cardIds);
            WebSocketMessage playerActionMsg = WebSocketMessage.playerAction(actionData);
            
            for (String player : room.getPlayerIds()) {
                // 检查玩家是否在线，只向在线的玩家发送消息
                if (!sessionManager.isOnline(player)) {
                    log.warn("玩家 {} 不在线，跳过发送消息", player);
                    continue;
                }
                sendToPlayer(player, playerActionMsg);
            }
            
            log.info("AI玩家 {} 出牌已广播给所有玩家", aiPlayerId);
        } catch (Exception e) {
            log.error("处理AI出牌广播时发生错误", e);
        }
    }

    /**
     * 玩家掉线数据
     */
    @lombok.Data
    private static class PlayerDisconnectData {
        private String playerId;
        private String reason;

        public PlayerDisconnectData(String playerId, String reason) {
            this.playerId = playerId;
            this.reason = reason;
        }
    }
}
