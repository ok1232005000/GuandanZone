package com.guandan.game.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;
import java.util.Map;

/**
 * 游戏开始消息的数据部分
 * 负责人：成员A（核心引擎与逻辑）
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GameStartData {
    /**
     * 当前玩家的手牌ID列表
     */
    private List<Integer> myCards;

    /**
     * 玩家ID（通讯层使用）
     */
    private String playerId;

    /**
     * 房间ID（通讯层使用）
     */
    private String roomId;
    
    /**
     * 级牌点数（0-12对应3,4,5,6,7,8,9,10,J,Q,K,A）
     */
    private Integer levelCard;
    
    /**
     * 玩家位置映射（位置名称 -> 玩家ID）
     * 用于前端显示每个位置对应的玩家
     */
    private Map<String, String> playerPositions;
}
