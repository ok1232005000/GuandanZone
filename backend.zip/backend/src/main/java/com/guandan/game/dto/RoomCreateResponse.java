package com.guandan.game.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 创建房间响应
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoomCreateResponse {
    private String roomId;      // 房间ID
    private String message;     // 提示信息
}
