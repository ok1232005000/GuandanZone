package com.guandan.game.service.impl;

import com.guandan.game.service.GameAlgorithm;
import com.guandan.game.util.CardUtils;
import com.guandan.model.CardType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 游戏算法实现（支持级牌和逢人配）
 * 负责人：成员A（核心引擎与逻辑）
 *
 * 实现掼蛋游戏的核心算法，包括：
 * - 级牌判断
 * - 逢人配（万能牌）变牌逻辑
 * - 牌型校验
 * - 比大小
 * - 进贡/还贡逻辑
 */
@Slf4j
@Service("gameAlgorithmImpl")
public class GameAlgorithmImpl implements GameAlgorithm {

    @Override
    public boolean isValidPlay(List<Integer> cards, List<Integer> lastCards, int levelCard) {
        if (cards == null || cards.isEmpty()) {
            log.warn("牌型校验失败：牌为空");
            return false;
        }

        // 先出牌：检查牌型是否合法
        if (lastCards == null || lastCards.isEmpty()) {
            CardType cardType = getCardType(cards, levelCard);
            boolean isValid = cardType != CardType.UNKNOWN;
            log.debug("先出牌校验：牌数={}，牌型={}，{}", cards.size(), cardType, isValid ? "合法" : "不合法");
            return isValid;
        }

        // 跟牌：检查牌型是否相同且能压过上家
        CardType myType = getCardType(cards, levelCard);
        CardType lastType = getCardType(lastCards, levelCard);

        if (myType == CardType.UNKNOWN) {
            log.warn("跟牌校验失败：牌型不合法");
            return false;
        }

        // 炸弹可以压任何牌
        if (myType.isBomb() && !lastType.isBomb()) {
            log.debug("跟牌校验：炸弹压非炸弹，合法");
            return true;
        }

        // 火箭可以压任何牌
        if (myType == CardType.ROCKET) {
            log.debug("跟牌校验：火箭压任何牌，合法");
            return true;
        }

        // 牌型必须相同
        if (myType != lastType) {
            log.debug("跟牌校验失败：牌型不同，我的牌型={}，上家牌型={}", myType, lastType);
            return false;
        }

        // 牌数必须相同
        if (cards.size() != lastCards.size()) {
            log.debug("跟牌校验失败：牌数不同，我的牌数={}，上家牌数={}", cards.size(), lastCards.size());
            return false;
        }

        // 比较大小
        boolean isBigger = compareCards(cards, lastCards, levelCard);
        log.debug("跟牌校验：牌型={}，{}", myType, isBigger ? "合法" : "不合法");
        return isBigger;
    }

    @Override
    public boolean compareCards(List<Integer> cards1, List<Integer> cards2, int levelCard) {
        CardType type1 = getCardType(cards1, levelCard);
        CardType type2 = getCardType(cards2, levelCard);

        // 火箭最大
        if (type1 == CardType.ROCKET) {
            return true;
        }
        if (type2 == CardType.ROCKET) {
            return false;
        }

        // 大炸弹比小炸弹大
        if (type1 == CardType.BIG_BOMB && type2 == CardType.SMALL_BOMB) {
            return true;
        }
        if (type2 == CardType.BIG_BOMB && type1 == CardType.SMALL_BOMB) {
            return false;
        }

        // 炸弹比非炸弹大
        if (type1.isBomb() && !type2.isBomb()) {
            return true;
        }
        if (type2.isBomb() && !type1.isBomb()) {
            return false;
        }

        // 牌型不同，无法比较
        if (type1 != type2) {
            return false;
        }

        // 使用分数比较
        int score1 = getCardScore(cards1, type1, levelCard);
        int score2 = getCardScore(cards2, type2, levelCard);

        boolean result = score1 > score2;
        log.debug("比大小：我的牌分数={}，对家牌分数={}，{}", score1, score2, result ? "我更大" : "对家更大");
        return result;
    }

    @Override
    public CardType getCardType(List<Integer> cards, int levelCard) {
        if (cards == null || cards.isEmpty()) {
            return CardType.UNKNOWN;
        }

        int size = cards.size();
        int levelCardRank = levelCard; // 使用传入的级牌参数

        // 统计每个点数的数量和级牌数量
        Map<Integer, Integer> rankCount = new HashMap<>();
        int levelCardNum = 0;
        for (Integer cardId : cards) {
            int rank = CardUtils.getRank(cardId);
            rankCount.put(rank, rankCount.getOrDefault(rank, 0) + 1);
            if (CardUtils.isLevelCard(cardId, levelCardRank)) {
                levelCardNum++;
            }
        }

        // 检查王炸（4张大小王）
        if (size == 4 && isJokerBomb(cards)) {
            return CardType.ROCKET;
        }

        // 检查炸弹（4张及以上同点数，考虑逢人配）
        if (size >= 4 && size <= 10) {
            if (isCommonBomb(cards, levelCardRank)) {
                return size >= 6 ? CardType.BIG_BOMB : CardType.SMALL_BOMB;
            }
        }

        // 根据牌数判断牌型
        switch (size) {
            case 1:
                return CardType.SINGLE;
            case 2:
                return isOneCouple(cards, levelCardRank) ? CardType.PAIR : CardType.UNKNOWN;
            case 3:
                return isThreePiece(cards, levelCardRank) ? CardType.TRIPLET : CardType.UNKNOWN;
            case 4:
                return CardType.UNKNOWN;
            case 5:
                if (isCommonFlush(cards, levelCardRank)) {
                    return CardType.STRAIGHT;
                }
                if (isThreeBringTwo(cards, levelCardRank)) {
                    return CardType.TRIPLET_WITH_TWO;
                }
                if (isSameColorFlush(cards, levelCardRank)) {
                    return CardType.FLUSH_STRAIGHT;
                }
                return CardType.UNKNOWN;
            case 6:
                if (isFlyOfThreePair(cards, levelCardRank)) {
                    return CardType.PAIR_STRAIGHT;
                }
                if (isTwoContinueThreePiece(cards, levelCardRank)) {
                    return CardType.TRIPLET_STRAIGHT;
                }
                return CardType.UNKNOWN;
            default:
                if (size >= 5 && isCommonFlush(cards, levelCardRank)) {
                    return CardType.STRAIGHT;
                }
                if (size >= 6 && size % 2 == 0 && isFlyOfThreePair(cards, levelCardRank)) {
                    return CardType.PAIR_STRAIGHT;
                }
                if (size >= 6 && size % 3 == 0 && isTwoContinueThreePiece(cards, levelCardRank)) {
                    return CardType.TRIPLET_STRAIGHT;
                }
                return CardType.UNKNOWN;
        }
    }

    @Override
    public GameResult checkGameOver(Map<String, List<Integer>> handCardsMap) {
        if (handCardsMap == null || handCardsMap.isEmpty()) {
            return null;
        }

        // 检测是否有玩家手牌为空
        for (Map.Entry<String, List<Integer>> entry : handCardsMap.entrySet()) {
            String playerId = entry.getKey();
            List<Integer> handCards = entry.getValue();

            if (handCards == null || handCards.isEmpty()) {
                log.info("游戏结束检测：玩家 {} 手牌为空，游戏结束", playerId);

                // 返回游戏结果
                return new GameResult(
                    playerId,    // 赢家
                    true,        // 假设是团队胜利
                    2,           // 当前级数（固定为2）
                    3            // 积分变化（+3分）
                );
            }
        }

        // 没有玩家手牌为空，游戏继续
        return null;
    }

    @Override
    public int calculateNextLevel(int currentLevel, boolean isUpgrade) {
        if (isUpgrade) {
            int nextLevel = currentLevel + 1;
            // 超过A（15）后回到2
            if (nextLevel > 15) {
                nextLevel = 2;
            }
            log.debug("级牌计算：当前级={}，升级，下一级={}", currentLevel, nextLevel);
            return nextLevel;
        } else {
            log.debug("级牌计算：当前级={}，不升级", currentLevel);
            return currentLevel;
        }
    }

    @Override
    public int calculateScore(String winnerId, int level, boolean isTeamWin) {
        // 简化积分计算：团队胜利+3分，失败-3分
        int score = isTeamWin ? 3 : -3;
        log.debug("积分计算：赢家={}，级={}，是否团队胜利={}，积分变化={}",
            winnerId, level, isTeamWin, score);
        return score;
    }

    // ==================== 私有辅助方法 ====================

    /**
     * 计算牌的分数（用于比牌）
     * @param cards 牌列表
     * @param type 牌型
     * @param levelCard 级牌
     * @return 牌的分数
     */
    private int getCardScore(List<Integer> cards, CardType type, int levelCard) {
        if (cards == null || cards.isEmpty()) {
            return 0;
        }

        // 火箭分数最大
        if (type == CardType.ROCKET) {
            return Integer.MAX_VALUE;
        }

        // 大炸弹分数计算
        if (type == CardType.BIG_BOMB) {
            int bombCount = getBombCardCount(cards, levelCard);
            return bombCount * 40 + getMainRank(cards, levelCard);
        }

        // 小炸弹分数计算
        if (type == CardType.SMALL_BOMB) {
            int bombCount = getBombCardCount(cards, levelCard);
            return bombCount * 20 + getMainRank(cards, levelCard);
        }

        // 其他牌型：返回主牌的等级
        return getMainRank(cards, levelCard);
    }

    /**
     * 获取炸弹的张数
     */
    private int getBombCardCount(List<Integer> cards, int levelCard) {
        Map<Integer, Integer> rankCount = new HashMap<>();
        for (Integer cardId : cards) {
            int rank = CardUtils.getGameLevel(cardId, levelCard);
            rankCount.put(rank, rankCount.getOrDefault(rank, 0) + 1);
        }
        return rankCount.values().stream().max(Integer::compare).orElse(0);
    }

    /**
     * 获取主牌的等级（用于分数计算）
     * @param cards 牌列表
     * @param levelCard 级牌
     * @return 主牌等级
     */
    private int getMainRank(List<Integer> cards, int levelCard) {
        if (cards == null || cards.isEmpty()) {
            return 0;
        }

        // 统计每个等级的数量
        Map<Integer, Integer> rankCount = new HashMap<>();
        for (Integer cardId : cards) {
            int rank = CardUtils.getGameLevel(cardId, levelCard);
            rankCount.put(rank, rankCount.getOrDefault(rank, 0) + 1);
        }

        // 返回出现次数最多的等级（主牌）
        return rankCount.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(0);
    }

    /**
     * 判断是否为对子
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 是否为对子
     */
    private boolean isOneCouple(List<Integer> cards, int levelCardRank) {
        if (cards.size() != 2) {
            return false;
        }
        return isSameFaceValue(cards, levelCardRank);
    }

    /**
     * 判断是否为三张
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 是否为三张
     */
    private boolean isThreePiece(List<Integer> cards, int levelCardRank) {
        if (cards.size() != 3) {
            return false;
        }
        return isSameFaceValue(cards, levelCardRank);
    }

    /**
     * 判断是否为顺子
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 是否为顺子
     */
    private boolean isCommonFlush(List<Integer> cards, int levelCardRank) {
        if (cards.size() < 5) {
            return false;
        }

        int rankCardNum = checkBefore(cards, levelCardRank);

        // 1.先排序
        List<Integer> sortedCards = new ArrayList<>(cards);
        Collections.sort(sortedCards, (a, b) -> CardUtils.getRank(a) - CardUtils.getRank(b));

        // 2.判断特殊情况，以及级牌充当空位的情况
        int beginValue = 0;
        for (Integer cardId : sortedCards) {
            int rank = CardUtils.getRank(cardId);
            if (CardUtils.isWildCard(cardId, levelCardRank)) {
                // 恢复数据
                continue;
            } else if (beginValue == 0) {
                beginValue = rank;
            } else {
                // 1.判断 A 2 3 4 5的情况
                if (rank == 11) { // A
                    if (beginValue == 3 && rankCardNum == 2) {
                        return true;
                    }
                    if (beginValue == 4 && rankCardNum == 1) {
                        return true;
                    }
                    if (beginValue == 5) {
                        return true;
                    }
                }
                int cnt = rank - beginValue;
                // 2.剩下的其余情况
                if (cnt > 3) {
                    return false;
                } else if (cnt > 1) {
                    if (cnt <= rankCardNum) {
                        cnt--;
                        rankCardNum -= cnt;
                    } else {
                        return false;
                    }
                    beginValue = rank;
                } else {
                    beginValue = rank;
                }
            }
        }

        return false;
    }

    /**
     * 判断是否为三带二
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 是否为三带二
     */
    private boolean isThreeBringTwo(List<Integer> cards, int levelCardRank) {
        if (cards.size() != 5) {
            return false;
        }

        int rankCardNum = checkBefore(cards, levelCardRank);
        int[] number = new int[5];
        int i = 0;
        List<Integer> sortedCards = new ArrayList<>(cards);
        Collections.sort(sortedCards, (a, b) -> CardUtils.getRank(a) - CardUtils.getRank(b));
        
        for (Integer cardId : sortedCards) {
            if (CardUtils.isWildCard(cardId, levelCardRank)) {
                number[i++] = -1;
                continue;
            } else {
                number[i++] = CardUtils.getRank(cardId);
            }
        }

        // 3代2，极端情况下也只有一张逢人配
        if (rankCardNum == 1) {
            // 1张逢人配，则需要两个对子
            boolean isSame1 = number[1] == number[2];
            boolean isSame2 = number[3] == number[4];
            return isSame1 && isSame2;
        } else if (rankCardNum == 2) {
            // 脑残出发
            boolean isSame1 = number[3] == number[4];
            boolean isSame2 = number[3] == number[2];
            return isSame1 || isSame2;
        } else {
            // 一个对子和一个三张
            boolean isSame1 = number[0] == number[1];
            boolean isSame2 = number[3] == number[4];
            boolean isSame3 = (number[2] == number[1] || number[2] == number[3]);
            return isSame1 && isSame2 && isSame3;
        }
    }

    /**
     * 判断是否为三连对
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 是否为三连对
     */
    private boolean isFlyOfThreePair(List<Integer> cards, int levelCardRank) {
        if (cards.size() != 6) {
            return false;
        }

        int rankCardNum = checkBefore(cards, levelCardRank);

        List<Integer> sortedCards = new ArrayList<>(cards);
        Collections.sort(sortedCards, (a, b) -> CardUtils.getRank(a) - CardUtils.getRank(b));
        int[] number = new int[6];
        int i = 0;
        for (Integer cardId : sortedCards) {
            if (CardUtils.isWildCard(cardId, levelCardRank)) {
                number[i++] = -1;
                continue;
            }
            number[i++] = CardUtils.getRank(cardId);
        }

        // 两张级牌
        if (rankCardNum == 2) {
            // 三连对的话，抛出两张逢人配，必须有一个对子，并且是连着的
            boolean isDouble = (number[2] == number[3] || number[3] == number[4] || number[4] == number[5]);
            boolean lens = (number[5] - number[2] == 2);
            return isDouble && lens;
        } else if (rankCardNum == 1) {
            // 三连对一张逢人配，必须两个对子，并且连着
            boolean isDouble = (number[2] == number[3] && number[4] == number[5]) ||
                    (number[1] == number[2] && number[4] == number[5]) || (number[1] == number[2] && number[4] == number[3]);
            boolean lens = (number[5] - number[1] == 2);
            return isDouble && lens;
        } else {
            boolean isDouble = (number[0] == number[1]) && (number[2] == number[3]) && number[4] == number[5];
            boolean lens = (number[5] - number[0] == 2);
            return isDouble && lens;
        }
    }

    /**
     * 判断是否为三顺
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 是否为三顺
     */
    private boolean isTwoContinueThreePiece(List<Integer> cards, int levelCardRank) {
        if (cards.size() != 6) {
            return false;
        }

        int rankCardNum = checkBefore(cards, levelCardRank);

        List<Integer> sortedCards = new ArrayList<>(cards);
        Collections.sort(sortedCards, (a, b) -> CardUtils.getRank(a) - CardUtils.getRank(b));
        int[] number = new int[6];
        int i = 0;
        for (Integer cardId : sortedCards) {
            if (CardUtils.isWildCard(cardId, levelCardRank)) {
                number[i++] = -1;
                continue;
            }
            number[i++] = CardUtils.getRank(cardId);
        }

        // 两张级牌
        if (rankCardNum == 2) {
            // 两个三张，两个逢人配的话，需要保证两个对子，或者一个三张一个单
            boolean lens = (number[5] - number[2] == 1);
            boolean isThree = (number[2] == number[3] && number[4] == number[5]) ||
                    (number[2] == number[3] && number[3] == number[4]) || (number[4] == number[3] && number[5] == number[4]);
            return lens && isThree;
        } else if (rankCardNum == 1) {
            // 两个三张，一个逢人配的话，需要保证一个对子，一个三张
            boolean lens = (number[5] - number[2] == 1);
            boolean isThree = (number[1] == number[2] && number[2] == number[3] && number[4] == number[5]) ||
                    (number[1] == number[2] && number[4] == number[3] && number[4] == number[5]);
            return lens && isThree;
        } else {
            // 两个三张，0个逢人配的话，需要保证2个三张
            boolean lens = (number[5] - number[2] == 1);
            boolean isThree = (number[0] == number[1] && number[1] == number[2] && number[4] == number[3] && number[4] == number[5]);
            return lens && isThree;
        }
    }

    /**
     * 判断是否为同花顺
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 是否为同花顺
     */
    private boolean isSameColorFlush(List<Integer> cards, int levelCardRank) {
        return isCommonFlush(cards, levelCardRank) && isSameColor(cards, levelCardRank);
    }

    /**
     * 判断是否为普通炸弹
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 是否为炸弹
     */
    private boolean isCommonBomb(List<Integer> cards, int levelCardRank) {
        if (cards.size() < 4 || cards.size() > 10) {
            return false;
        }
        return isSameFaceValue(cards, levelCardRank);
    }

    /**
     * 判断是否为王炸
     * @param cards 牌列表
     * @return 是否为王炸
     */
    private boolean isJokerBomb(List<Integer> cards) {
        if (cards.size() != 4) {
            return false;
        }

        int smallJokerNum = 0, bigJokerNum = 0;
        for (Integer cardId : cards) {
            int suit = CardUtils.getSuit(cardId);
            if (suit != -1) {
                return false;
            }
            int rank = CardUtils.getRank(cardId);
            if (rank == 13) {
                smallJokerNum++;
            } else if (rank == 14) {
                bigJokerNum++;
            }
        }

        return smallJokerNum == bigJokerNum && smallJokerNum == 2;
    }

    /**
     * 判断是否为相同面值（考虑逢人配）
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 是否为相同面值
     */
    private boolean isSameFaceValue(List<Integer> cards, int levelCardRank) {
        int valueCheck = -1;
        for (Integer cardId : cards) {
            int suit = CardUtils.getSuit(cardId);
            int rank = CardUtils.getRank(cardId);
            if (suit == 2 && rank == levelCardRank) {
                continue;
            } else if (valueCheck == -1) {
                valueCheck = rank;
            } else {
                if (rank != valueCheck) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 判断是否为相同花色（考虑逢人配）
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 是否为相同花色
     */
    private boolean isSameColor(List<Integer> cards, int levelCardRank) {
        int beginColor = -1;

        for (Integer cardId : cards) {
            int suit = CardUtils.getSuit(cardId);
            int rank = CardUtils.getRank(cardId);
            if (rank == levelCardRank && suit == 2) {
                continue;
            } else if (beginColor == -1) {
                beginColor = suit;
            } else {
                if (beginColor != suit) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 检查并记录级牌数量
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 级牌数量
     */
    private int checkBefore(List<Integer> cards, int levelCardRank) {
        int rankCardNum = 0;
        // 0.移除级牌，记录数量
        for (Integer cardId : cards) {
            int suit = CardUtils.getSuit(cardId);
            int rank = CardUtils.getRank(cardId);
            if (rank == levelCardRank && suit == 2) {
                rankCardNum++;
            }
        }

        if (rankCardNum > 2) {
            throw new RuntimeException("牌面错误");
        }
        return rankCardNum;
    }

    /**
     * 逢人配变牌逻辑
     * 将逢人配变为各种可能的牌，生成所有可能的牌型组合
     * @param cards 牌列表
     * @param levelCardRank 级牌等级
     * @return 所有可能的牌型组合
     */
    private List<List<Integer>> transformWildCards(List<Integer> cards, int levelCardRank) {
        List<List<Integer>> result = new ArrayList<>();
        
        // 获取逢人配
        List<Integer> wildCards = CardUtils.getWildCards(cards, levelCardRank);
        int wildCardCount = wildCards.size();
        
        if (wildCardCount == 0) {
            // 没有逢人配，直接返回原牌
            result.add(new ArrayList<>(cards));
            return result;
        }
        
        // 移除逢人配
        List<Integer> nonWildCards = new ArrayList<>(cards);
        nonWildCards.removeAll(wildCards);
        
        // 生成逢人配的所有可能组合
        List<List<Integer>> wildCombinations = generateWildCardCombinations(wildCardCount);
        
        // 对于每种组合，尝试将逢人配变为各种牌
        for (List<Integer> wildCombo : wildCombinations) {
            // 尝试将逢人配变为各种可能的牌
            List<List<Integer>> transformedCards = tryTransformWildCards(nonWildCards, wildCombo, levelCardRank);
            result.addAll(transformedCards);
        }
        
        return result;
    }

    /**
     * 生成逢人配的所有可能组合
     * @param wildCardCount 逢人配数量
     * @return 所有可能的组合
     */
    private List<List<Integer>> generateWildCardCombinations(int wildCardCount) {
        List<List<Integer>> result = new ArrayList<>();
        
        if (wildCardCount == 1) {
            // 1张逢人配，可以变为任意牌
            for (int rank = 0; rank <= 12; rank++) {
                for (int suit = 0; suit <= 3; suit++) {
                    List<Integer> combo = new ArrayList<>();
                    combo.add(suit * 13 + rank);
                    result.add(combo);
                }
            }
        } else if (wildCardCount == 2) {
            // 2张逢人配，可以变为任意两张牌
            for (int rank1 = 0; rank1 <= 12; rank1++) {
                for (int suit1 = 0; suit1 <= 3; suit1++) {
                    for (int rank2 = 0; rank2 <= 12; rank2++) {
                        for (int suit2 = 0; suit2 <= 3; suit2++) {
                            List<Integer> combo = new ArrayList<>();
                            combo.add(suit1 * 13 + rank1);
                            combo.add(suit2 * 13 + rank2);
                            result.add(combo);
                        }
                    }
                }
            }
        }
        
        return result;
    }

    /**
     * 尝试将逢人配变为各种牌
     * @param nonWildCards 非逢人配的牌
     * @param wildCombo 逢人配的组合
     * @param levelCardRank 级牌等级
     * @return 变换后的牌列表
     */
    private List<List<Integer>> tryTransformWildCards(List<Integer> nonWildCards, List<Integer> wildCombo, int levelCardRank) {
        List<List<Integer>> result = new ArrayList<>();
        
        // 将非逢人配的牌和逢人配的组合合并
        List<Integer> transformed = new ArrayList<>(nonWildCards);
        transformed.addAll(wildCombo);
        
        // 检查变换后的牌是否合法
        CardType cardType = getCardType(transformed, levelCardRank);
        if (cardType != CardType.UNKNOWN) {
            result.add(transformed);
        }
        
        return result;
    }
}
