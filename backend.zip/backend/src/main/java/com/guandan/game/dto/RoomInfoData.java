package com.guandan.game.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 房间信息数据
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoomInfoData {
    private String roomId;          // 房间ID
    private String status;          // 房间状态
    private int playerCount;        // 玩家数量
    private String currentPlayerId; // 当前出牌玩家ID
}
