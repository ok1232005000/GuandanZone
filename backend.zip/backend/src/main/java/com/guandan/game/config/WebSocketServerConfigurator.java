package com.guandan.game.config;

import com.guandan.util.JwtUtil;
import jakarta.websocket.EndpointConfig;
import jakarta.websocket.server.HandshakeRequest;
import jakarta.websocket.server.ServerEndpointConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * WebSocket跨域配置器和JWT认证
 * 负责人：成员B（通讯与架构）
 *
 * 功能：
 * 1. 允许跨域WebSocket连接
 * 2. JWT Token验证
 */
@Slf4j
@Component
public class WebSocketServerConfigurator extends ServerEndpointConfig.Configurator {

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, jakarta.websocket.HandshakeResponse response) {
        // 允许跨域握手
        log.debug("WebSocket握手请求来自: {}", request.getHeaders().get("Origin"));

        // 设置允许跨域的响应头
        response.getHeaders().put("Access-Control-Allow-Origin", Collections.singletonList("*"));
        response.getHeaders().put("Access-Control-Allow-Methods", Collections.singletonList("GET, POST, OPTIONS"));
        response.getHeaders().put("Access-Control-Allow-Headers", Collections.singletonList("*"));
        response.getHeaders().put("Access-Control-Allow-Credentials", Collections.singletonList("true"));

        // 验证JWT Token
        Map<String, List<String>> headers = request.getHeaders();
        List<String> authHeaders = headers.get("Authorization");
        
        if (authHeaders != null && !authHeaders.isEmpty()) {
            String authHeader = authHeaders.get(0);
            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                String token = authHeader.substring(7);
                try {
                    if (jwtUtil != null && jwtUtil.validateToken(token)) {
                        Long userId = jwtUtil.getUserIdFromToken(token);
                        log.debug("JWT Token验证成功: userId={}", userId);
                        // 将userId存储在用户属性中，供后续使用
                        sec.getUserProperties().put("userId", String.valueOf(userId));
                        sec.getUserProperties().put("token", token);
                    } else {
                        log.warn("JWT Token验证失败");
                        response.getHeaders().put("X-WebSocket-Auth-Error", Collections.singletonList("Invalid token"));
                    }
                } catch (Exception e) {
                    log.error("JWT Token验证异常", e);
                    response.getHeaders().put("X-WebSocket-Auth-Error", Collections.singletonList("Token validation error"));
                }
            }
        } else {
            // 从查询参数中获取token（兼容性）
            Map<String, List<String>> pathParams = request.getParameterMap();
            List<String> tokenList = pathParams.get("token");
            String token = (tokenList != null && !tokenList.isEmpty()) ? tokenList.get(0) : null;
            if (token != null && !token.isEmpty()) {
                try {
                    if (jwtUtil != null && jwtUtil.validateToken(token)) {
                        Long userId = jwtUtil.getUserIdFromToken(token);
                        log.debug("JWT Token验证成功（查询参数）: userId={}", userId);
                        sec.getUserProperties().put("userId", String.valueOf(userId));
                        sec.getUserProperties().put("token", token);
                    } else {
                        log.warn("JWT Token验证失败（查询参数）");
                        response.getHeaders().put("X-WebSocket-Auth-Error", Collections.singletonList("Invalid token"));
                    }
                } catch (Exception e) {
                    log.error("JWT Token验证异常（查询参数）", e);
                    response.getHeaders().put("X-WebSocket-Auth-Error", Collections.singletonList("Token validation error"));
                }
            } else {
                log.warn("WebSocket连接未提供JWT Token");
                response.getHeaders().put("X-WebSocket-Auth-Error", Collections.singletonList("No token provided"));
            }
        }

        super.modifyHandshake(sec, request, response);
    }
}
