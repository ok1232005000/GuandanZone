package com.guandan.game.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * WebSocket消息DTO
 * 用于前后端消息传递的统一格式
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WebSocketMessage {

    /**
     * 消息类型
     * GAME_START: 游戏开始
     * PLAYER_ACTION: 玩家出牌
     * ERROR: 错误消息
     */
    private String type;

    /**
     * 消息数据（根据type不同，data的结构也不同）
     */
    private Object data;

    /**
     * 创建游戏开始消息
     */
    public static WebSocketMessage gameStart(Object data) {
        return new WebSocketMessage("GAME_START", data);
    }

    /**
     * 创建玩家出牌消息
     */
    public static WebSocketMessage playerAction(Object data) {
        return new WebSocketMessage("PLAYER_ACTION", data);
    }

    /**
     * 创建回合更新消息
     */
    public static WebSocketMessage turnChange(Object data) {
        return new WebSocketMessage("TURN_CHANGE", data);
    }

    /**
     * 创建错误消息
     */
    public static WebSocketMessage error(String errorMsg) {
        return new WebSocketMessage("ERROR", new ErrorData(errorMsg));
    }

    /**
     * 错误数据内部类
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ErrorData {
        private String message;
    }

    /**
     * 回合更新数据内部类
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TurnChangeData {
        private String currentPlayerId;
        private boolean isMyTurn;
    }
}
