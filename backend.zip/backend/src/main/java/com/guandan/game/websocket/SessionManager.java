package com.guandan.game.websocket;

import jakarta.websocket.Session;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * WebSocket会话管理器
 * 负责人：成员B（通讯与架构）
 *
 * 功能：
 * 1. 管理所有WebSocket连接
 * 2. 心跳检测（发现断线）
 * 3. 断线重连支持
 * 4. 会话信息统计
 */
@Slf4j
@Component
public class SessionManager {

    /**
     * 会话信息存储：playerId -> SessionInfo
     */
    private final ConcurrentHashMap<String, SessionInfo> sessions = new ConcurrentHashMap<>();

    /**
     * WebSocket Session引用存储：playerId -> Session
     * 用于实际发送消息
     */
    private final ConcurrentHashMap<String, Session> webSocketSessions = new ConcurrentHashMap<>();

    /**
     * 房间到玩家的映射：roomId -> Set<playerId>
     */
    private final ConcurrentHashMap<String, ConcurrentHashMap<String, Boolean>> roomPlayers = new ConcurrentHashMap<>();

    /**
     * 心跳检测间隔（秒）
     */
    private static final int HEARTBEAT_INTERVAL = 30;

    /**
     * 连接超时时间（秒）- 超过这个时间没心跳认为断线
     */
    private static final int CONNECTION_TIMEOUT = 60;

    /**
     * 断线保留时间（秒）- 断线后多久清理数据
     */
    private static final int DISCONNECTED_RETENTION_TIME = 300; // 5分钟

    /**
     * 定时线程池
     */
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    /**
     * 在线玩家数量
     */
    private final AtomicInteger onlineCount = new AtomicInteger(0);

    /**
     * 初始化：启动心跳检测任务
     */
    public SessionManager() {
        // 每30秒执行一次心跳检测
        scheduler.scheduleAtFixedRate(this::heartbeatCheck, HEARTBEAT_INTERVAL, HEARTBEAT_INTERVAL, TimeUnit.SECONDS);
        log.info("SessionManager初始化完成，心跳检测已启动（间隔{}秒）", HEARTBEAT_INTERVAL);
    }

    /**
     * 添加会话
     */
    public void addSession(String playerId, String roomId) {
        SessionInfo sessionInfo = new SessionInfo();
        sessionInfo.setPlayerId(playerId);
        sessionInfo.setRoomId(roomId);
        sessionInfo.setConnectTime(System.currentTimeMillis());
        sessionInfo.setLastHeartbeatTime(System.currentTimeMillis());
        sessionInfo.setOnline(true);

        sessions.put(playerId, sessionInfo);

        // 添加到房间（只有roomId不为null时才添加）
        if (roomId != null && !roomId.isEmpty()) {
            roomPlayers.computeIfAbsent(roomId, k -> new ConcurrentHashMap<>())
                    .put(playerId, true);
        }

        int count = onlineCount.incrementAndGet();
        log.info("玩家 {} 加入房间 {}, 当前在线人数: {}", playerId, roomId, count);
    }

    /**
     * 更新心跳时间
     */
    public void updateHeartbeat(String playerId) {
        SessionInfo sessionInfo = sessions.get(playerId);
        if (sessionInfo != null) {
            sessionInfo.setLastHeartbeatTime(System.currentTimeMillis());
            log.debug("玩家 {} 心跳更新", playerId);
        }
    }

    /**
     * 标记会话为离线（不删除数据，支持重连）
     */
    public void markOffline(String playerId) {
        SessionInfo sessionInfo = sessions.get(playerId);
        if (sessionInfo != null && sessionInfo.isOnline()) {
            sessionInfo.setOnline(false);
            sessionInfo.setDisconnectTime(System.currentTimeMillis());

            int count = onlineCount.decrementAndGet();
            log.info("玩家 {} 断开连接，当前在线人数: {}", playerId, count);
        }
    }

    /**
     * 重连：将会话标记为在线
     */
    public boolean reconnect(String playerId) {
        SessionInfo sessionInfo = sessions.get(playerId);
        if (sessionInfo != null && !sessionInfo.isOnline()) {
            sessionInfo.setOnline(true);
            sessionInfo.setLastHeartbeatTime(System.currentTimeMillis());
            sessionInfo.setReconnectCount(sessionInfo.getReconnectCount() + 1);

            int count = onlineCount.incrementAndGet();
            log.info("玩家 {} 重连成功，重连次数: {}, 当前在线人数: {}",
                    playerId, sessionInfo.getReconnectCount(), count);
            return true;
        }
        return false;
    }

    /**
     * 完全移除会话
     */
    public void removeSession(String playerId) {
        SessionInfo sessionInfo = sessions.remove(playerId);
        if (sessionInfo != null) {
            // 从房间中移除
            ConcurrentHashMap<String, Boolean> players = roomPlayers.get(sessionInfo.getRoomId());
            if (players != null) {
                players.remove(playerId);
                // 如果房间空了，删除房间
                if (players.isEmpty()) {
                    roomPlayers.remove(sessionInfo.getRoomId());
                }
            }

            if (sessionInfo.isOnline()) {
                onlineCount.decrementAndGet();
            }
            log.info("玩家 {} 会话已完全移除", playerId);
        }

        // 同时移除WebSocket Session引用
        Session wsSession = webSocketSessions.remove(playerId);
        if (wsSession != null) {
            log.debug("玩家 {} 的WebSocket Session引用已移除", playerId);
        }
    }

    /**
     * 保存WebSocket Session引用
     * @param playerId 玩家ID
     * @param session WebSocket Session对象
     */
    public void saveSession(String playerId, Session session) {
        webSocketSessions.put(playerId, session);
        log.debug("玩家 {} 的WebSocket Session引用已保存", playerId);
    }

    public void removeWebSocketSession(String playerId) {
        Session wsSession = webSocketSessions.remove(playerId);
        if (wsSession != null) {
            log.debug("玩家 {} 的WebSocket Session引用已移除", playerId);
        }
    }

    /**
     * 更新玩家的房间信息
     * @param playerId 玩家ID
     * @param roomId 房间ID
     */
    public void updatePlayerRoom(String playerId, String roomId) {
        SessionInfo sessionInfo = sessions.get(playerId);
        if (sessionInfo != null) {
            // 从旧房间中移除
            if (sessionInfo.getRoomId() != null && !sessionInfo.getRoomId().isEmpty()) {
                ConcurrentHashMap<String, Boolean> oldRoomPlayers = roomPlayers.get(sessionInfo.getRoomId());
                if (oldRoomPlayers != null) {
                    oldRoomPlayers.remove(playerId);
                    if (oldRoomPlayers.isEmpty()) {
                        roomPlayers.remove(sessionInfo.getRoomId());
                    }
                }
            }
            
            // 更新房间ID
            sessionInfo.setRoomId(roomId);
            
            // 添加到新房间
            if (roomId != null && !roomId.isEmpty()) {
                roomPlayers.computeIfAbsent(roomId, k -> new ConcurrentHashMap<>())
                        .put(playerId, true);
            }
            
            log.info("玩家 {} 房间信息已更新: {}", playerId, roomId);
        }
    }

    /**
     * 获取WebSocket Session引用
     * @param playerId 玩家ID
     * @return WebSocket Session对象，如果不存在或已关闭则返回null
     */
    public Session getWebSocketSession(String playerId) {
        Session session = webSocketSessions.get(playerId);
        if (session != null && !session.isOpen()) {
            // Session已关闭，移除引用
            webSocketSessions.remove(playerId);
            log.warn("玩家 {} 的WebSocket Session已关闭，移除引用", playerId);
            return null;
        }
        return session;
    }

    /**
     * 获取会话信息
     */
    public SessionInfo getSession(String playerId) {
        return sessions.get(playerId);
    }

    /**
     * 检查玩家是否在线
     */
    public boolean isOnline(String playerId) {
        SessionInfo sessionInfo = sessions.get(playerId);
        return sessionInfo != null && sessionInfo.isOnline();
    }

    /**
     * 获取房间内的所有玩家（包括离线的）
     */
    public ConcurrentHashMap<String, Boolean> getRoomPlayers(String roomId) {
        return roomPlayers.get(roomId);
    }

    /**
     * 获取当前在线人数
     */
    public int getOnlineCount() {
        return onlineCount.get();
    }

    /**
     * 心跳检测：定期检查并清理超时连接
     */
    private void heartbeatCheck() {
        long currentTime = System.currentTimeMillis();
        int timeoutCount = 0;
        int cleanedCount = 0;

        for (Map.Entry<String, SessionInfo> entry : sessions.entrySet()) {
            SessionInfo sessionInfo = entry.getValue();

            if (sessionInfo.isOnline()) {
                // 检查在线玩家是否超时
                long elapsed = (currentTime - sessionInfo.getLastHeartbeatTime()) / 1000;
                if (elapsed > CONNECTION_TIMEOUT) {
                    log.warn("玩家 {} 心跳超时（{}秒未活动），标记为离线",
                            entry.getKey(), elapsed);
                    markOffline(entry.getKey());
                    timeoutCount++;
                }
            } else {
                // 检查离线玩家是否需要清理
                long disconnectedTime = (currentTime - sessionInfo.getDisconnectTime()) / 1000;
                if (disconnectedTime > DISCONNECTED_RETENTION_TIME) {
                    log.info("玩家 {} 离线超过{}秒，清理会话", entry.getKey(), disconnectedTime);
                    removeSession(entry.getKey());
                    cleanedCount++;
                }
            }
        }

        if (timeoutCount > 0 || cleanedCount > 0) {
            log.info("心跳检测完成：超时断线={}, 清理会话={}, 当前在线={}",
                    timeoutCount, cleanedCount, getOnlineCount());
        }
    }

    /**
     * 获取所有会话信息（用于调试）
     */
    public ConcurrentHashMap<String, SessionInfo> getAllSessions() {
        return sessions;
    }

    /**
     * 获取会话统计信息
     */
    public SessionStats getStats() {
        SessionStats stats = new SessionStats();
        stats.setOnlineCount(onlineCount.get());
        stats.setTotalSessions(sessions.size());
        stats.setRoomCount(roomPlayers.size());

        int offlineCount = 0;
        int reconnectCount = 0;
        for (SessionInfo info : sessions.values()) {
            if (!info.isOnline()) {
                offlineCount++;
            }
            reconnectCount += info.getReconnectCount();
        }

        stats.setOfflineCount(offlineCount);
        stats.setTotalReconnects(reconnectCount);
        return stats;
    }

    /**
     * 关闭管理器
     */
    public void shutdown() {
        scheduler.shutdown();
        log.info("SessionManager已关闭");
    }

    /**
     * 会话信息
     */
    @Data
    public static class SessionInfo {
        private String playerId;
        private String roomId;
        private long connectTime;          // 连接时间
        private long lastHeartbeatTime;    // 最后心跳时间
        private long disconnectTime;       // 断开时间
        private boolean online;            // 是否在线
        private int reconnectCount;        // 重连次数
    }

    /**
     * 会话统计信息
     */
    @Data
    public static class SessionStats {
        private int onlineCount;       // 在线人数
        private int offlineCount;      // 离线人数
        private int totalSessions;     // 总会话数
        private int roomCount;         // 房间数
        private int totalReconnects;   // 总重连次数
    }
}
