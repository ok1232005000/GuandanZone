package com.guandan.game.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 聊天消息数据
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatData {
    private String playerId;    // 发送者玩家ID
    private String message;     // 消息内容
    private String timestamp;   // 时间戳
}
