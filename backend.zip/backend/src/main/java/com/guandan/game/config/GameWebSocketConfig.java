package com.guandan.game.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.server.standard.ServerEndpointExporter;

/**
 * WebSocket配置类（使用@ServerEndpoint注解方式）
 * 负责人：成员A（核心引擎与逻辑） + 成员B（通讯与架构）
 *
 * 启用WebSocket支持，用于扫描@ServerEndpoint注解
 */
@Configuration
public class GameWebSocketConfig {

    /**
     * 注册WebSocket端点
     * Spring Boot需要这个Bean来扫描@ServerEndpoint注解
     */
    @Bean
    public ServerEndpointExporter serverEndpointExporter() {
        return new ServerEndpointExporter();
    }
}
