package com.guandan.game.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 玩家信息
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlayerInfo {
    private String playerId;        // 玩家ID
    private String nickname;        // 昵称
    private int cardCount;          // 剩余手牌数量
    private String position;        // 位置：bottom（我）、top（队友）、left（左对手）、right（右对手）
    private boolean isOnline;       // 是否在线
}
