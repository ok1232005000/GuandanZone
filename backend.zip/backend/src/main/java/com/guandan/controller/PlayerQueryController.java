package com.guandan.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.guandan.annotation.IgnoreAuth;
import com.guandan.common.Result;
import com.guandan.entity.User;
import com.guandan.game.model.GameRoom;
import com.guandan.game.service.GameLogicService;
import com.guandan.mapper.UserMapper;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(originPatterns = "*")
@RestController
@RequestMapping("/api")
public class PlayerQueryController {

    @Resource
    private GameLogicService gameLogicService;

    @Resource
    private UserMapper userMapper;

    @IgnoreAuth
    @GetMapping("/get_player_game_state/{userIdentifier}/{roomNo}")
    public Result<Map<String, Object>> getPlayerGameState(
            @PathVariable String userIdentifier,
            @PathVariable String roomNo) {
        try {
            String roomId = "room_" + roomNo;

            GameRoom gameRoom = gameLogicService.getRoom(roomId);
            if (gameRoom == null) {
                return Result.error("游戏房间不存在：" + roomNo);
            }

            String playerId = null;
            User user = null;

            try {
                Long userId = Long.parseLong(userIdentifier);
                user = userMapper.selectById(userId);
                if (user != null) {
                    playerId = String.valueOf(userId);
                }
            } catch (NumberFormatException e) {
                QueryWrapper<User> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("username", userIdentifier);
                user = userMapper.selectOne(queryWrapper);
                if (user != null) {
                    playerId = String.valueOf(user.getId());
                }
            }

            if (playerId == null) {
                return Result.error("用户不存在：" + userIdentifier);
            }

            if (!gameRoom.getPlayerIds().contains(playerId)) {
                return Result.error("玩家不在该房间中");
            }

            List<Integer> handCards = gameRoom.getHandCards().get(playerId);

            Map<String, Object> data = new HashMap<>();
            data.put("userId", playerId);
            data.put("username", user != null ? user.getUsername() : "");
            data.put("nickname", user != null ? user.getNickname() : "");
            data.put("roomNo", roomNo);
            data.put("roomStatus", gameRoom.getStatus().name());
            data.put("handCards", handCards);
            data.put("cardCount", handCards != null ? handCards.size() : 0);

            return Result.success(data);
        } catch (Exception e) {
            return Result.error("查询失败：" + e.getMessage());
        }
    }
}
