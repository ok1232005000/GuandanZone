package com.guandan.controller;

import com.guandan.dto.LoginRequest;
import com.guandan.dto.LoginResponse;
import com.guandan.dto.legacy.JoinGameRequestLegacy;
import com.guandan.dto.legacy.NewGameRequestLegacy;
import com.guandan.dto.legacy.RegisterRequestLegacy;
import com.guandan.entity.Room;
import com.guandan.entity.RoomPlayer;
import com.guandan.entity.User;
import com.guandan.game.model.GameRoom;
import com.guandan.game.service.GameLogicService;
import com.guandan.service.AuthService;
import com.guandan.service.RoomService;
import com.guandan.service.UserService;
import com.guandan.util.JwtUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 兼容层控制器（支持参考前端）
 * 负责人：成员B（通讯与架构）
 *
 * 功能：
 * 1. 提供兼容参考前端的接口
 * 2. 不影响原有接口（/api/*）
 * 3. 调用现有Service层，不重复造轮子
 */
@Slf4j
@RestController
@CrossOrigin(originPatterns = "*") // 允许跨域（使用originPatterns代替origins）
public class LegacyController {

    @Autowired
    private AuthService authService;

    @Autowired
    private UserService userService;

    @Autowired
    private RoomService roomService;

    @Autowired
    private GameLogicService gameLogicService;

    @Autowired
    private JwtUtil jwtUtil;

    /**
     * 1. 兼容登录接口
     * POST /login
     *
     * 参考前端期望：{token, userId}
     * 原有接口：POST /api/login → {code, message, data: {token, userId}}
     */
    @PostMapping("/login")
    public Map<String, Object> loginLegacy(@RequestBody LoginRequest request) {
        log.info("兼容登录接口：username={}", request.getUsername());

        try {
            // 调用现有的AuthService
            LoginResponse response = authService.login(request.getUsername(), request.getPassword());

            // 转换成参考前端期望的格式
            Map<String, Object> result = new HashMap<>();
            result.put("token", response.getToken());
            result.put("userId", response.getUserId());

            log.info("兼容登录成功：userId={}", response.getUserId());
            return result;

        } catch (Exception e) {
            log.error("兼容登录失败", e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", e.getMessage());
            return error;
        }
    }

    /**
     * 2. 兼容注册接口
     * POST /register
     *
     * 参考前端发送：{username, password, confirmation}
     * 原有接口：POST /api/register → {username, password, nickname}
     */
    @PostMapping("/register")
    public Map<String, Object> registerLegacy(@RequestBody RegisterRequestLegacy request) {
        log.info("兼容注册接口：username={}", request.getUsername());

        try {
            // 1. 验证确认密码（如果提供了）
            if (request.getConfirmation() != null &&
                !request.getPassword().equals(request.getConfirmation())) {
                throw new RuntimeException("密码不一致");
            }

            // 2. 自动生成nickname（如果没有提供nickname）
            String nickname = "Player" + request.getUsername();

            // 3. 调用现有的AuthService
            Long userId = authService.register(
                request.getUsername(),
                request.getPassword(),
                nickname
            );

            // 4. 生成token
            String token = jwtUtil.generateToken(userId, request.getUsername());

            // 5. 返回参考前端期望的格式
            Map<String, Object> result = new HashMap<>();
            result.put("token", token);
            result.put("userId", userId);

            log.info("兼容注册成功：userId={}", userId);
            return result;

        } catch (Exception e) {
            log.error("兼容注册失败", e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", e.getMessage());
            return error;
        }
    }

    /**
     * 3. 兼容创建游戏接口
     * POST /new_game
     *
     * 参考前端发送：{level, experimental}
     * 原有接口：POST /api/new-game → {isPrivate, config}
     */
    @PostMapping("/new_game")
    public Map<String, String> newGameLegacy(@RequestBody NewGameRequestLegacy request) {
        log.info("兼容创建游戏接口：level={}, experimental={}",
                 request.getLevel(), request.getExperimental());

        try {
            // 1. 转换参数
            // level → isPrivate（level > 2 为私密房间）
            Boolean isPrivate = request.getLevel() != null && request.getLevel() > 2;
            String config = null; // experimental参数暂不处理

            // 2. 调用现有的RoomService创建房间
            Room room = roomService.createRoom(isPrivate, config);

            // 3. 返回参考前端期望的格式 {token: roomNo}
            Map<String, String> result = new HashMap<>();
            result.put("token", room.getRoomNo());

            log.info("兼容创建游戏成功：roomNo={}", room.getRoomNo());
            return result;

        } catch (Exception e) {
            log.error("兼容创建游戏失败", e);
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return error;
        }
    }

    /**
     * 4. 兼容加入游戏接口
     * POST /join_game/{token}
     *
     * 参考前端发送：{username, token}
     * token就是房间号（roomNo）
     */
    @PostMapping("/join_game/{token}")
    public Map<String, Object> joinGameLegacy(
            @PathVariable String token,
            @RequestBody JoinGameRequestLegacy request) {

        log.info("兼容加入游戏接口：roomNo={}, username={}", token, request.getUsername());

        try {
            // 1. 根据房间号查询房间
            Room room = roomService.getRoomByRoomNo(token);
            if (room == null) {
                throw new RuntimeException("房间不存在");
            }

            // 2. 加入房间
            RoomPlayer roomPlayer = roomService.joinRoom(token, request.getUsername());

            // 3. 返回参考前端期望的格式 {player_number: seatIndex}
            Map<String, Object> result = new HashMap<>();
            result.put("player_number", roomPlayer.getSeatIndex());

            log.info("兼容加入游戏成功：player_number={}", roomPlayer.getSeatIndex());
            return result;

        } catch (Exception e) {
            log.error("兼容加入游戏失败", e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", e.getMessage());
            return error;
        }
    }

    /**
     * 5. 游戏状态查询接口（HTTP轮询方式）
     * GET /get_player_game_state/{token}/{player_id}
     *
     * token：房间号（roomNo）
     * player_id：玩家ID（可以是userId或seatIndex）
     */
    @GetMapping("/get_player_game_state/{token}/{player_id}")
    public Map<String, Object> getGameState(
            @PathVariable String token,
            @PathVariable String player_id) {

        log.info("游戏状态查询：roomNo={}, playerId={}", token, player_id);

        try {
            // 1. 根据房间号查询游戏房间
            GameRoom gameRoom = gameLogicService.getRoom(token);
            if (gameRoom == null) {
                throw new RuntimeException("游戏房间不存在");
            }

            // 2. 构建游戏状态数据
            Map<String, Object> gameState = new HashMap<>();

            // 房间状态
            gameState.put("room_status", gameRoom.getStatus().name());
            gameState.put("current_player_index", gameRoom.getCurrentPlayerIndex());

            // 玩家信息
            if (gameRoom.getHandCards() != null) {
                gameState.put("my_cards", gameRoom.getHandCards().get(player_id));
            }

            // 其他玩家手牌数量
            Map<String, Integer> otherPlayersCards = new HashMap<>();
            if (gameRoom.getHandCards() != null) {
                for (Map.Entry<String, java.util.List<Integer>> entry : gameRoom.getHandCards().entrySet()) {
                    if (!entry.getKey().equals(player_id)) {
                        otherPlayersCards.put(entry.getKey(), entry.getValue().size());
                    }
                }
            }
            gameState.put("other_players_cards", otherPlayersCards);

            // 3. 返回游戏状态
            log.info("游戏状态查询成功：roomNo={}", token);
            return gameState;

        } catch (Exception e) {
            log.error("游戏状态查询失败", e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", e.getMessage());
            return error;
        }
    }
}
