package com.guandan.controller;

import com.guandan.common.Result;
import com.guandan.dto.NewGameRequest;
import com.guandan.entity.Room;
import com.guandan.service.AuthService;
import com.guandan.service.RoomService;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 房间控制器
 * 职责：房间基础管理（创建房间）
 * 注意：游戏核心逻辑（加入房间、出牌等）由成员A的 GuandanLogic 处理
 */
@CrossOrigin(originPatterns = "*") // 允许跨域（使用originPatterns代替origins）
@RestController
@RequestMapping("/api")
public class RoomController {

    @Resource
    private RoomService roomService;

    @Resource
    private AuthService authService;

    /**
     * 创建新游戏/房间
     * 对应需求：US-4 私人房间创建
     *
     * POST /api/new-game
     *
     * @param token 用户认证Token
     * @param request 创建房间请求
     * @return 房间号
     */
    @PostMapping("/new-game")
    public Result<Map<String, String>> createGame(
            @RequestHeader("Authorization") String token,
            @Valid @RequestBody NewGameRequest request) {
        try {
            // 验证Token并获取用户ID
            Long userId = getUserIdFromToken(token);

            request.setUserId(userId);
            String roomNo = roomService.createRoom(request);

            Map<String, String> data = new HashMap<>();
            data.put("roomNo", roomNo);
            data.put("message", "房间创建成功");
            return Result.success(data);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 从Token中获取用户ID（工具方法）
     */
    private Long getUserIdFromToken(String token) {
        if (token.startsWith("Bearer ")) {
            token = token.substring(7);
        }
        return authService.validateToken(token);
    }

    /**
     * 获取所有可用房间列表
     * 对应需求：大厅显示可加入的房间
     *
     * GET /api/rooms
     *
     * @param token 用户认证Token
     * @return 等待中的房间列表
     */
    @GetMapping("/rooms")
    public Result<List<Room>> getAvailableRooms(@RequestHeader("Authorization") String token) {
        try {
            // 验证Token
            getUserIdFromToken(token);

            List<Room> rooms = roomService.getAvailableRooms();
            return Result.success(rooms);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 获取用户当前所在的房间
     * 对应需求：用户重新进入大厅时，显示自己所在的房间
     *
     * GET /api/room/current
     *
     * @param token 用户认证Token
     * @return 用户当前所在房间信息，如果不在任何房间则返回null
     */
    @GetMapping("/room/current")
    public Result<Room> getCurrentRoom(@RequestHeader("Authorization") String token) {
        try {
            Long userId = getUserIdFromToken(token);
            Room room = roomService.getCurrentRoom(userId);

            if (room == null) {
                return Result.success(null);
            }

            return Result.success(room);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}
