package com.guandan.controller;

import com.guandan.annotation.IgnoreAuth;
import com.guandan.common.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/health")
@IgnoreAuth
public class HealthController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    @GetMapping("/database")
    public Result<Map<String, Object>> testDatabaseConnection() {
        Map<String, Object> data = new HashMap<>();

        try {
            String version = jdbcTemplate.queryForObject("SELECT VERSION()", String.class);
            data.put("database", "MySQL");
            data.put("version", version);
            data.put("status", "connected");

            String database = jdbcTemplate.queryForObject("SELECT DATABASE()", String.class);
            data.put("currentDatabase", database);

            Integer tableCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = ?",
                    Integer.class,
                    "guandan"
            );
            data.put("tableCount", tableCount);

            return Result.success(data);
        } catch (Exception e) {
            data.put("status", "failed");
            data.put("error", e.getMessage());
            return Result.error("数据库连接失败");
        }
    }

    @GetMapping("/redis")
    public Result<Map<String, Object>> testRedisConnection() {
        Map<String, Object> data = new HashMap<>();

        try {
            String testKey = "guandan:health:test";
            String testValue = "pong";

            redisTemplate.opsForValue().set(testKey, testValue);
            data.put("status", "connected");

            Object result = redisTemplate.opsForValue().get(testKey);
            data.put("testResult", result);

            redisTemplate.delete(testKey);

            String info = redisTemplate.getConnectionFactory().getConnection().ping();
            data.put("ping", info);

            return Result.success(data);
        } catch (Exception e) {
            data.put("status", "failed");
            data.put("error", e.getMessage());
            return Result.error("Redis连接失败");
        }
    }

    @GetMapping("/system")
    public Result<Map<String, Object>> getSystemInfo() {
        Map<String, Object> data = new HashMap<>();

        Runtime runtime = Runtime.getRuntime();

        long maxMemory = runtime.maxMemory();
        long totalMemory = runtime.totalMemory();
        long freeMemory = runtime.freeMemory();
        long usedMemory = totalMemory - freeMemory;

        data.put("jvm", Map.of(
                "maxMemory", maxMemory / 1024 / 1024 + " MB",
                "totalMemory", totalMemory / 1024 / 1024 + " MB",
                "freeMemory", freeMemory / 1024 / 1024 + " MB",
                "usedMemory", usedMemory / 1024 / 1024 + " MB",
                "availableProcessors", runtime.availableProcessors()
        ));

        data.put("system", Map.of(
                "osName", System.getProperty("os.name"),
                "osVersion", System.getProperty("os.version"),
                "javaVersion", System.getProperty("java.version"),
                "javaHome", System.getProperty("java.home")
        ));

        return Result.success(data);
    }
}
