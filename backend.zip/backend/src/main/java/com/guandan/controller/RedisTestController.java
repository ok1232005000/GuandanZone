package com.guandan.controller;

import com.guandan.common.Result;
import com.guandan.service.RoomCache;
import com.guandan.service.TokenCache;
import com.guandan.util.RedisUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

@Tag(name = "Redis测试接口", description = "测试Redis缓存功能")
@RestController
@RequestMapping("/test/redis")
public class RedisTestController {

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private TokenCache tokenCache;

    @Autowired
    private RoomCache roomCache;

    @Operation(summary = "测试基本操作")
    @PostMapping("/basic")
    public Result<Map<String, Object>> testBasic() {
        Map<String, Object> result = new HashMap<>();

        String testKey = "test:key";
        String testValue = "Hello Redis!";
        redisUtil.set(testKey, testValue);
        result.put("set", "success");

        Object getValue = redisUtil.get(testKey);
        result.put("get", getValue);

        Boolean hasKey = redisUtil.hasKey(testKey);
        result.put("hasKey", hasKey);

        redisUtil.expire(testKey, 60);
        Long ttl = redisUtil.getExpire(testKey);
        result.put("expire", "60s");
        result.put("ttl", ttl);

        redisUtil.delete(testKey);
        Boolean deleted = !redisUtil.hasKey(testKey);
        result.put("delete", deleted);

        return Result.success(result);
    }

    @Operation(summary = "测试计数器")
    @PostMapping("/counter")
    public Result<Map<String, Object>> testCounter() {
        Map<String, Object> result = new HashMap<>();

        String counterKey = "test:counter";

        redisUtil.delete(counterKey);

        long value1 = redisUtil.increment(counterKey);
        result.put("increment1", value1);

        long value2 = redisUtil.increment(counterKey, 5);
        result.put("increment5", value2);

        long value3 = redisUtil.decrement(counterKey);
        result.put("decrement1", value3);

        long value4 = redisUtil.decrement(counterKey, 2);
        result.put("decrement2", value4);

        redisUtil.delete(counterKey);

        return Result.success(result);
    }

    @Operation(summary = "测试Hash操作")
    @PostMapping("/hash")
    public Result<Map<String, Object>> testHash() {
        Map<String, Object> result = new HashMap<>();

        String hashKey = "test:hash";

        redisUtil.hSet(hashKey, "name", "Alice");
        redisUtil.hSet(hashKey, "age", 25);
        redisUtil.hSet(hashKey, "city", "Beijing");
        result.put("hSet", "success");

        Object name = redisUtil.hGet(hashKey, "name");
        result.put("hGet.name", name);

        Map<Object, Object> all = redisUtil.hGetAll(hashKey);
        result.put("hGetAll", all);

        Boolean hasKey = redisUtil.hHasKey(hashKey, "name");
        result.put("hHasKey", hasKey);

        redisUtil.hDelete(hashKey, "age");
        result.put("hDelete", "age deleted");

        redisUtil.delete(hashKey);

        return Result.success(result);
    }

    @Operation(summary = "测试List操作")
    @PostMapping("/list")
    public Result<Map<String, Object>> testList() {
        Map<String, Object> result = new HashMap<>();

        String listKey = "test:list";

        redisUtil.delete(listKey);

        redisUtil.lRightPush(listKey, "item1");
        redisUtil.lRightPush(listKey, "item2");
        redisUtil.lRightPush(listKey, "item3");
        result.put("lRightPush", "3 items");

        Long size = redisUtil.lSize(listKey);
        result.put("lSize", size);

        List<Object> range = redisUtil.lRange(listKey, 0, -1);
        result.put("lRange", range);

        redisUtil.lLeftPush(listKey, "item0");
        List<Object> newRange = redisUtil.lRange(listKey, 0, -1);
        result.put("after lLeftPush", newRange);

        Object item1 = redisUtil.lIndex(listKey, 1);
        result.put("lIndex.1", item1);

        redisUtil.delete(listKey);

        return Result.success(result);
    }

    @Operation(summary = "测试Set操作")
    @PostMapping("/set")
    public Result<Map<String, Object>> testSet() {
        Map<String, Object> result = new HashMap<>();

        String setKey = "test:set";

        redisUtil.sAdd(setKey, "apple", "banana", "orange");
        result.put("sAdd", "3 fruits");

        Long size = redisUtil.sSize(setKey);
        result.put("sSize", size);

        Set<Object> members = redisUtil.sMembers(setKey);
        result.put("sMembers", members);

        Boolean isMember = redisUtil.sIsMember(setKey, "apple");
        result.put("sIsMember.apple", isMember);

        redisUtil.sRemove(setKey, "banana");
        result.put("sRemove", "banana removed");

        redisUtil.delete(setKey);

        return Result.success(result);
    }

    @Operation(summary = "测试ZSet操作")
    @PostMapping("/zset")
    public Result<Map<String, Object>> testZSet() {
        Map<String, Object> result = new HashMap<>();

        String zsetKey = "test:zset";

        redisUtil.zAdd(zsetKey, "Alice", 90.5);
        redisUtil.zAdd(zsetKey, "Bob", 85.0);
        redisUtil.zAdd(zsetKey, "Charlie", 95.0);
        result.put("zAdd", "3 students");

        Long size = redisUtil.zSize(zsetKey);
        result.put("zSize", size);

        Set<Object> range = redisUtil.zRange(zsetKey, 0, -1);
        result.put("zRange(asc)", range);

        Set<Object> reverseRange = redisUtil.zReverseRange(zsetKey, 0, -1);
        result.put("zReverseRange(desc)", reverseRange);

        Double score = redisUtil.zScore(zsetKey, "Alice");
        result.put("zScore.Alice", score);

        redisUtil.delete(zsetKey);

        return Result.success(result);
    }

    @Operation(summary = "测试TokenCache服务")
    @PostMapping("/token")
    public Result<Map<String, Object>> testTokenCache() {
        Map<String, Object> result = new HashMap<>();

        Long userId = 1001L;
        String token = "test-jwt-token-" + System.currentTimeMillis();

        tokenCache.setUserToken(userId, token);
        result.put("setUserToken", "success");

        String cachedToken = tokenCache.getUserToken(userId);
        result.put("getUserToken", cachedToken != null ? "found" : "not found");

        boolean valid = tokenCache.validateToken(userId, token);
        result.put("validateToken", valid);

        boolean online = tokenCache.isUserOnline(userId);
        result.put("isUserOnline", online);

        Long ttl = tokenCache.getTokenTtl(userId);
        result.put("getTokenTtl", ttl);

        tokenCache.deleteUserToken(userId);
        boolean deleted = !tokenCache.isUserOnline(userId);
        result.put("deleteUserToken", deleted);

        return Result.success(result);
    }

    @Operation(summary = "测试RoomCache服务")
    @PostMapping("/room")
    public Result<Map<String, Object>> testRoomCache() {
        Map<String, Object> result = new HashMap<>();

        Long roomId = 2001L;
        Long playerId1 = 3001L;
        Long playerId2 = 3002L;

        roomCache.setRoomStatus(roomId, 0);
        result.put("setRoomStatus", "success");

        Integer status = roomCache.getRoomStatus(roomId);
        result.put("getRoomStatus", status);

        roomCache.addPlayerToRoom(roomId, playerId1);
        roomCache.addPlayerToRoom(roomId, playerId2);
        result.put("addPlayerToRoom", "2 players");

        List<Long> players = roomCache.getRoomPlayers(roomId);
        result.put("getRoomPlayers", players);

        roomCache.addToMatchQueue(playerId1);
        result.put("addToMatchQueue", "success");

        Long queueSize = roomCache.getMatchQueueSize();
        result.put("getMatchQueueSize", queueSize);

        roomCache.addOnlineRoom(roomId, System.currentTimeMillis());
        result.put("addOnlineRoom", "success");

        Long roomCount = roomCache.getOnlineRoomCount();
        result.put("getOnlineRoomCount", roomCount);

        roomCache.removePlayerFromRoom(roomId, playerId1);
        result.put("removePlayerFromRoom", "player removed");

        roomCache.deleteAllRoomData(roomId);
        roomCache.removeFromMatchQueue(playerId1);
        result.put("cleanup", "success");

        return Result.success(result);
    }

    @Operation(summary = "测试过期策略")
    @PostMapping("/expire")
    public Result<Map<String, Object>> testExpire() throws InterruptedException {
        Map<String, Object> result = new HashMap<>();

        String expireKey = "test:expire";

        redisUtil.set(expireKey, "will expire", 10, TimeUnit.SECONDS);
        result.put("set", "10 seconds");

        Object value1 = redisUtil.get(expireKey);
        result.put("immediate get", value1);

        Long ttl1 = redisUtil.getExpire(expireKey);
        result.put("immediate ttl", ttl1);

        Thread.sleep(2000);
        Long ttl2 = redisUtil.getExpire(expireKey);
        result.put("after 2s ttl", ttl2);

        return Result.success(result);
    }

    @Operation(summary = "清理测试数据")
    @DeleteMapping("/cleanup")
    public Result<String> cleanupTestData() {
        Set<Object> keys = redisUtil.sMembers("test:*");
        if (keys != null && !keys.isEmpty()) {
            redisUtil.delete(keys.stream().map(Object::toString).toList());
        }

        roomCache.clearMatchQueue();

        return Result.success("测试数据已清理");
    }
}
