package com.guandan.controller;

import com.guandan.annotation.IgnoreAuth;
import com.guandan.common.Result;
import com.guandan.dto.ChangePasswordRequest;
import com.guandan.dto.LoginRequest;
import com.guandan.dto.LoginResponse;
import com.guandan.dto.RegisterRequest;
import com.guandan.dto.RegisterResponse;
import com.guandan.dto.UserInfoResponse;
import com.guandan.service.AuthService;
import com.guandan.service.UserService;
import com.guandan.util.JwtUtil;
import com.guandan.util.UserContext;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(originPatterns = "*")
@RestController
@RequestMapping("/api")
public class AuthController {

    @Resource
    private AuthService authService;

    @Resource
    private JwtUtil jwtUtil;

    @Resource
    private UserService userService;

    @PostMapping("/register")
    @IgnoreAuth
    public Result<RegisterResponse> register(@Valid @RequestBody RegisterRequest request) {
        try {
            RegisterResponse response = authService.register(request);
            return Result.success(response);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/login")
    @IgnoreAuth
    public Result<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        try {
            LoginResponse response = authService.login(request.getUsername(), request.getPassword());
            return Result.success(response);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/user/info")
    public Result<UserInfoResponse> getUserInfo() {
        try {
            Long userId = UserContext.getUserId();
            UserInfoResponse userInfo = authService.getUserInfo(userId);
            return Result.success(userInfo);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/user/logout")
    public Result<String> logout() {
        try {
            Long userId = UserContext.getUserId();
            userService.logout(userId);
            return Result.success("退出登录成功");
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/user/change-password")
    public Result<String> changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        try {
            Long userId = UserContext.getUserId();
            request.setUserId(userId);
            userService.changePassword(request);
            return Result.success("密码修改成功，请重新登录");
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/user/check-username")
    @IgnoreAuth
    public Result<Boolean> checkUsername(@RequestParam String username) {
        try {
            boolean exists = userService.existsByUsername(username);
            return Result.success(exists);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}
