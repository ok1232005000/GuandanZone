package com.guandan.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * 房间详细信息响应
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoomDetailResponse {

    /**
     * 房间号
     */
    private String roomNo;

    /**
     * 房间状态：WAITING/PLAYING/FINISHED
     */
    private String status;

    /**
     * 创建者ID
     */
    private Long creatorId;

    /**
     * A队级别
     */
    private Integer levelTeamA;

    /**
     * B队级别
     */
    private Integer levelTeamB;

    /**
     * 当前出牌玩家索引
     */
    private Integer currentPlayerIndex;

    /**
     * 当前玩家数量
     */
    private Integer playerCount;

    /**
     * 房间玩家列表
     */
    private List<Map<String, Object>> players;
}
