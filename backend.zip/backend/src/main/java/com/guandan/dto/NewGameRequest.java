package com.guandan.dto;

import lombok.Data;

/**
 * 创建游戏请求
 */
@Data
public class NewGameRequest {

    private Long userId;

    private Boolean isPrivate;

    private String config;
}
