package com.guandan.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class RegisterRequest {

    /**
     * 用户名（6位纯数字，与前端保持一致）
     */
    @NotBlank(message = "用户名不能为空")
    @Pattern(regexp = "^\\d{6}$", message = "账号必须是6位纯数字")
    private String username;

    /**
     * 密码（6-10位字母数字，与前端保持一致）
     */
    @NotBlank(message = "密码不能为空")
    @Size(min = 6, max = 10, message = "密码长度必须在6-10位之间")
    @Pattern(regexp = "^[a-zA-Z0-9]+$", message = "密码只能包含字母和数字")
    private String password;

    /**
     * 昵称（最多10位，与前端保持一致）
     */
    @NotBlank(message = "昵称不能为空")
    @Size(max = 10, message = "昵称长度不能超过10位")
    @Pattern(regexp = "^[a-zA-Z0-9\\u4e00-\\u9fa5]+$", message = "昵称只能包含字母、数字、汉字")
    private String nickname;

    /**
     * 头像（Base64 SVG）
     */
    private String avatar;

    /**
     * 手机号（可选）
     */
    private String phone;
}
