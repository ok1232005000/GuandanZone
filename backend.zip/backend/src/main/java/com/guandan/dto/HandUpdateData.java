package com.guandan.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

/**
 * 玩家手牌更新消息的数据部分
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HandUpdateData {
    /**
     * 玩家ID
     */
    private String playerId;
    
    /**
     * 更新后的手牌列表（剩余手牌）
     */
    private List<Integer> remainingCards;
    
    /**
     * 是否获胜（手牌为空）
     */
    private boolean isWinner;
}
