package com.guandan.dto;

import lombok.Data;

@Data
public class UserInfoResponse {

    private Long id;

    private String username;

    private String nickname;

    private String avatar;

    private String phone;

    private Integer totalGames;

    private Integer winGames;

    private Integer levelCurrent;
}
