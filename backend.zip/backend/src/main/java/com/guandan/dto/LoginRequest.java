package com.guandan.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class LoginRequest {

    /**
     * 用户名（6位纯数字）
     */
    @NotBlank(message = "用户名不能为空")
    @Pattern(regexp = "^\\d{6}$", message = "账号必须是6位纯数字")
    private String username;

    /**
     * 密码
     */
    @NotBlank(message = "密码不能为空")
    private String password;
}
