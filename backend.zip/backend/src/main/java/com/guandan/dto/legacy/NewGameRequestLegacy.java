package com.guandan.dto.legacy;

import lombok.Data;

/**
 * 参考前端创建游戏请求（兼容格式）
 */
@Data
public class NewGameRequestLegacy {
    private Integer level;         // 级别（可选）
    private Boolean experimental;   // 实验模式（可选）
}
