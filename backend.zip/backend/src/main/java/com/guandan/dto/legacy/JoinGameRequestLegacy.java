package com.guandan.dto.legacy;

import lombok.Data;

/**
 * 参考前端加入游戏请求（兼容格式）
 */
@Data
public class JoinGameRequestLegacy {
    private String username;
    private String token; // 房间token（即roomNo）
}
