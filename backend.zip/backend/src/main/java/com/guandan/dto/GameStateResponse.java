package com.guandan.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 游戏状态响应
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GameStateResponse {

    /**
     * 房间ID
     */
    private String roomId;

    /**
     * 房间状态：WAITING/PLAYING/FINISHED
     */
    private String status;

    /**
     * 当前出牌玩家索引
     */
    private Integer currentPlayerIndex;

    /**
     * 玩家数量
     */
    private Integer playerCount;

    /**
     * 我的手牌（卡牌ID列表）
     */
    private List<Integer> myCards;

    /**
     * 级牌（点数）
     */
    private Integer levelCard;

    /**
     * 当前级牌名称
     */
    private String levelCardName;

    /**
     * 我的级牌列表（卡牌ID列表）
     */
    private List<Integer> myLevelCards;

    /**
     * 我的逢人配列表（卡牌ID列表）
     */
    private List<Integer> myWildCards;
}
