package com.guandan.dto.legacy;

import lombok.Data;

/**
 * 参考前端注册请求（兼容格式）
 */
@Data
public class RegisterRequestLegacy {
    private String username;
    private String password;
    private String confirmation; // 确认密码（可选）
}
