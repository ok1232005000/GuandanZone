package com.guandan.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 玩家放弃出牌广播消息的数据部分
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PassData {
    /**
     * 放弃出牌的玩家ID
     */
    private String playerId;
    
    /**
     * 当前轮到出牌的玩家ID（放弃后的下一个玩家）
     */
    private String currentPlayerId;
}
