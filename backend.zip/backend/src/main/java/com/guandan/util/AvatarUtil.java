package com.guandan.util;

import java.util.Arrays;
import java.util.List;

public class AvatarUtil {

    private static final List<String> AVATAR_COLORS = Arrays.asList(
            "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4",
            "#FFEAA7", "#DDA0DD", "#98D8C8", "#F7DC6F"
    );

    private static final List<String> AVATAR_TEXTS = Arrays.asList(
            "A", "B", "C", "D", "E", "F", "G", "H"
    );

    public static String getAvatarColor(String username) {
        if (username == null || username.isEmpty()) {
            return AVATAR_COLORS.get(0);
        }
        int index = Math.abs(username.hashCode()) % AVATAR_COLORS.size();
        return AVATAR_COLORS.get(index);
    }

    public static String getAvatarText(String username) {
        if (username == null || username.isEmpty()) {
            return AVATAR_TEXTS.get(0);
        }
        return username.substring(0, 1).toUpperCase();
    }
}
