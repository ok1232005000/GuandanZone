#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成JMeter测试用户数据
用法: python generate_test_users.py --count 1000 --output test_users.csv
"""

import argparse
import csv
import random


def generate_username(start_num=123456, count=1000):
    """生成6位数字用户名"""
    usernames = []
    for i in range(count):
        username = str(start_num + i)
        # 确保是6位数字
        username = username.zfill(6)
        usernames.append(username)
    return usernames


def generate_test_users(count=1000, output_file='test_users.csv'):
    """生成测试用户CSV文件"""
    usernames = generate_username(count=count)
    password = 'test123'  # 统一密码，便于测试
    
    with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        # 写入标题行
        writer.writerow(['username', 'password'])
        # 写入数据行
        for username in usernames:
            writer.writerow([username, password])
    
    print(f"成功生成 {count} 个测试用户数据到 {output_file}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='生成JMeter测试用户数据')
    parser.add_argument('--count', type=int, default=1000, help='生成用户数量（默认1000）')
    parser.add_argument('--output', type=str, default='test_users.csv', help='输出文件名（默认test_users.csv）')
    
    args = parser.parse_args()
    generate_test_users(count=args.count, output_file=args.output)
