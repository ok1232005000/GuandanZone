#!/bin/bash

# 掼蛋游戏后端部署脚本
# 用法: ./deploy.sh [环境] [版本]
# 示例: ./deploy.sh prod 1.0.0

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 参数检查
ENV=${1:-prod}
VERSION=${2:-latest}

log_info "开始部署 - 环境: $ENV, 版本: $VERSION"

# 1. 检查必要文件
log_info "检查必要文件..."
if [ ! -f "Dockerfile" ]; then
    log_error "Dockerfile 不存在"
    exit 1
fi

if [ ! -f "docker-compose.yml" ]; then
    log_error "docker-compose.yml 不存在"
    exit 1
fi

# 2. 备份当前版本（如果存在）
if [ -f "target/guandan-backend-*.jar" ]; then
    log_info "备份当前版本..."
    BACKUP_DIR="backups/$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$BACKUP_DIR"
    cp target/guandan-backend-*.jar "$BACKUP_DIR/" 2>/dev/null || true
    log_info "备份完成: $BACKUP_DIR"
fi

# 3. 拉取最新代码（如果使用Git）
if [ -d ".git" ]; then
    log_info "拉取最新代码..."
    git pull origin main || git pull origin master || log_warn "Git拉取失败，继续使用当前代码"
fi

# 4. 编译打包
log_info "编译打包..."
mvn clean package -DskipTests

if [ $? -ne 0 ]; then
    log_error "编译失败"
    exit 1
fi

# 检查JAR文件是否存在
JAR_FILE=$(find target -name "guandan-backend-*.jar" -not -name "*-sources.jar" | head -n 1)
if [ -z "$JAR_FILE" ]; then
    log_error "JAR文件未找到"
    exit 1
fi

log_info "编译成功: $JAR_FILE"

# 5. 停止旧服务
log_info "停止旧服务..."
docker-compose down || log_warn "停止服务失败（可能服务未运行）"

# 6. 构建Docker镜像
log_info "构建Docker镜像..."
docker-compose build --no-cache backend

if [ $? -ne 0 ]; then
    log_error "Docker镜像构建失败"
    exit 1
fi

# 7. 启动服务
log_info "启动服务..."
docker-compose up -d

if [ $? -ne 0 ]; then
    log_error "服务启动失败"
    exit 1
fi

# 8. 等待服务启动
log_info "等待服务启动..."
sleep 10

# 9. 健康检查
log_info "执行健康检查..."
MAX_RETRIES=30
RETRY_COUNT=0

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
    if curl -f http://localhost:8081/actuator/health > /dev/null 2>&1; then
        log_info "健康检查通过"
        break
    fi
    
    RETRY_COUNT=$((RETRY_COUNT + 1))
    log_warn "健康检查失败，重试 $RETRY_COUNT/$MAX_RETRIES..."
    sleep 5
done

if [ $RETRY_COUNT -eq $MAX_RETRIES ]; then
    log_error "健康检查失败，服务可能未正常启动"
    log_error "查看日志: docker-compose logs backend"
    exit 1
fi

# 10. 显示服务状态
log_info "服务状态:"
docker-compose ps

# 11. 显示日志（最后20行）
log_info "服务日志（最后20行）:"
docker-compose logs --tail=20 backend

log_info "部署完成！"
log_info "服务地址: http://localhost:8081"
log_info "健康检查: http://localhost:8081/actuator/health"
