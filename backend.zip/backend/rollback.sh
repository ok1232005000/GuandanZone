#!/bin/bash

# 掼蛋游戏后端回滚脚本
# 用法: ./rollback.sh [备份目录]
# 示例: ./rollback.sh backups/20260116_120000

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 参数检查
BACKUP_DIR=${1:-}

if [ -z "$BACKUP_DIR" ]; then
    log_error "请指定备份目录"
    log_info "用法: ./rollback.sh [备份目录]"
    log_info "可用备份目录:"
    ls -d backups/*/ 2>/dev/null | head -n 5 || log_warn "未找到备份目录"
    exit 1
fi

if [ ! -d "$BACKUP_DIR" ]; then
    log_error "备份目录不存在: $BACKUP_DIR"
    exit 1
fi

log_info "开始回滚 - 备份目录: $BACKUP_DIR"

# 1. 停止当前服务
log_info "停止当前服务..."
docker-compose down

# 2. 恢复JAR文件
log_info "恢复JAR文件..."
JAR_FILE=$(find "$BACKUP_DIR" -name "guandan-backend-*.jar" | head -n 1)

if [ -z "$JAR_FILE" ]; then
    log_error "备份目录中未找到JAR文件"
    exit 1
fi

# 创建target目录（如果不存在）
mkdir -p target

# 复制JAR文件
cp "$JAR_FILE" target/
log_info "JAR文件已恢复: $JAR_FILE"

# 3. 重新构建Docker镜像
log_info "重新构建Docker镜像..."
docker-compose build --no-cache backend

if [ $? -ne 0 ]; then
    log_error "Docker镜像构建失败"
    exit 1
fi

# 4. 启动服务
log_info "启动服务..."
docker-compose up -d

if [ $? -ne 0 ]; then
    log_error "服务启动失败"
    exit 1
fi

# 5. 等待服务启动
log_info "等待服务启动..."
sleep 10

# 6. 健康检查
log_info "执行健康检查..."
MAX_RETRIES=30
RETRY_COUNT=0

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
    if curl -f http://localhost:8081/actuator/health > /dev/null 2>&1; then
        log_info "健康检查通过"
        break
    fi
    
    RETRY_COUNT=$((RETRY_COUNT + 1))
    log_warn "健康检查失败，重试 $RETRY_COUNT/$MAX_RETRIES..."
    sleep 5
done

if [ $RETRY_COUNT -eq $MAX_RETRIES ]; then
    log_error "健康检查失败，服务可能未正常启动"
    log_error "查看日志: docker-compose logs backend"
    exit 1
fi

# 7. 显示服务状态
log_info "服务状态:"
docker-compose ps

log_info "回滚完成！"
log_info "服务地址: http://localhost:8081"
