<template>
  <div class="game-container" @mouseup="stopDragging" @mouseleave="stopDragging">
    <!-- 准备阶段（默认显示） -->
    <transition name="fade">
      <div class="prepare-stage" v-if="gameState === 'prepare'">
        <div class="room-info">房间号：{{ roomId }}</div>
        <div class="room-info">当前人数：{{ playerCount }}/4</div>

        <!-- 玩家信息面板 -->
        <div class="players-panel" v-if="roomPlayers.length > 0">
          <div class="panel-title">房间玩家</div>
          <div class="players-list">
            <div class="player-item" v-for="(player, index) in roomPlayers" :key="index">
              <div class="player-avatar">
                <el-avatar :size="50" :src="getPlayerAvatar(player)">
                  {{ getPlayerNickname(player) }}
                </el-avatar>
              </div>
              <div class="player-info">
                <div class="player-name">{{ getPlayerNickname(player) }}</div>
                <div class="player-account">账号：{{ player.username || player.userId }}</div>
                <div class="player-status">
                  <el-tag :type="player.isReady === 1 ? 'success' : 'info'" size="small">
                    {{ player.isReady === 1 ? '已准备' : '未准备' }}
                  </el-tag>
                  <el-tag :type="player.online === 1 ? 'success' : 'warning'" size="small" style="margin-left: 6px">
                    {{ player.online === 1 ? '在线' : '离线' }}
                  </el-tag>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="prepare-btns">
          <!-- 准备就绪按钮 - 所有人都有，包括房主 -->
          <el-button
              :type="isReady ? 'info' : 'primary'"
              size="large"
              @click="toggleReady"
          >
            {{ isReady ? '取消准备' : '准备就绪' }}
          </el-button>

          <!-- 开始游戏按钮 - 只有房主可见 -->
          <el-button
              type="success"
              size="large"
              @click="handleStartGame"
              :disabled="!canStartGame"
              v-if="isRoomOwner"
          >
            开始游戏
          </el-button>

          <el-button type="warning" size="large" @click="goBackToLobby">返回大厅</el-button>
        </div>
      </div>
    </transition>

    <!-- 游戏阶段（准备后显示） -->
    <transition name="fade">
      <div class="game-stage" v-if="gameState !== 'prepare'">
        <!-- 左上角级牌显示框 -->
        <div class="level-card-container">
          <div class="level-card-title">当前级牌</div>
          <div class="level-card-display">
            <div class="level-card-text">{{ getLevelCardName() }}</div>
          </div>
        </div>

        <!-- 顶部退出按钮 -->
        <div class="exit-btn-container">
          <el-button type="danger" plain @click="exitAndDissolveRoom">退出房间</el-button>
        </div>

        <!-- 队友信息和牌 -->
        <div class="player-section top">
          <div class="player-info">
            <div class="player-avatar">
              <el-avatar :size="40" :src="getInGameAvatar('队友')">
                {{ getInGameName('队友').slice(0, 1) }}
              </el-avatar>
              <span v-if="getFinishLabel('队友')" class="finish-badge">{{ getFinishLabel('队友') }}</span>
              <div v-if="chatBubbles['队友']" class="chat-bubble">{{ chatBubbles['队友'] }}</div>
            </div>
            <div class="player-details">
              <div class="player-name">{{ getInGameName('队友') }}</div>
              <div class="player-status">剩余 {{ teammateCards.length }} 张</div>
            </div>
          </div>
          <div class="player-cards">
            <div v-for="(card, index) in teammateCards" :key="'teammate-' + index" class="card back"> </div>
          </div>
        </div>

        <!-- 左对手信息和牌 -->
        <div class="player-section left">
          <div class="player-info">
            <div class="player-avatar">
              <el-avatar :size="40" :src="getInGameAvatar('左对手')">
                {{ getInGameName('左对手').slice(0, 1) }}
              </el-avatar>
              <span v-if="getFinishLabel('左对手')" class="finish-badge">{{ getFinishLabel('左对手') }}</span>
              <div v-if="chatBubbles['左对手']" class="chat-bubble">{{ chatBubbles['左对手'] }}</div>
            </div>
            <div class="player-details">
              <div class="player-name">{{ getInGameName('左对手') }}</div>
              <div class="player-status">剩余 {{ leftOpponentCards.length }} 张</div>
            </div>
          </div>
          <div class="player-cards vertical">
            <div v-for="(card, index) in leftOpponentCards" :key="'left-' + index" class="card back"></div>
          </div>
        </div>

        <!-- 右对手信息和牌 -->
        <div class="player-section right">
          <div class="player-info">
            <div class="player-details">
              <div class="player-name">{{ getInGameName('右对手') }}</div>
              <div class="player-status">剩余 {{ rightOpponentCards.length }} 张</div>
            </div>
            <div class="player-avatar">
              <el-avatar :size="40" :src="getInGameAvatar('右对手')">
                {{ getInGameName('右对手').slice(0, 1) }}
              </el-avatar>
              <span v-if="getFinishLabel('右对手')" class="finish-badge">{{ getFinishLabel('右对手') }}</span>
              <div v-if="chatBubbles['右对手']" class="chat-bubble">{{ chatBubbles['右对手'] }}</div>
            </div>
          </div>
          <div class="player-cards vertical">
            <div v-for="(card, index) in rightOpponentCards" :key="'right-' + index" class="card back"></div>
          </div>
        </div>

        <!-- 中央桌子区域 -->
        <div class="desk-center">
          <div class="table-area">
            <div class="desk-slots">
              <div v-for="(cards, player) in deskDisplay" :key="player" :class="['played-slot', getPlayerPosClass(player)]">
                <transition name="fade">
                  <div class="played-cards-group" v-if="cards.length > 0">
                    <div v-for="(card, index) in cards" :key="index">
                      <div v-if="card.type === 'pass'" class="pass-indicator">不要</div>
                      <div v-else class="card small-on-desk">
                        <img :src="getCardImage(card)" class="card-img">
                      </div>
                    </div>
                  </div>
                </transition>
              </div>
            </div>

            <!-- 倒计时和操作按钮 -->
            <div class="action-area">
              <div class="countdown" v-if="currentPlayer === '我'">
                <div class="countdown-circle">{{ countdown }}</div>
              </div>
              <div class="action-buttons" v-show="currentPlayer === '我'">
                <button class="btn btn-pass" @click="pass">不出</button>
                <button class="btn btn-hint" @click="hint">提示</button>
                <button class="btn btn-play" @click="playCards" :disabled="selectedCards.length === 0">出牌</button>
              </div>
              <div class="current-player" v-if="currentPlayer !== '我'">{{ currentPlayer }}的回合</div>
            </div>
          </div>
        </div>

        <!-- 我的信息、牌和快捷文字 -->
        <div class="player-section bottom">
          <div class="my-info-section">
            <div class="player-avatar">
              <el-avatar :size="40" :src="getInGameAvatar('我')">
                {{ getInGameName('我').slice(0, 1) }}
              </el-avatar>
              <span v-if="getFinishLabel('我')" class="finish-badge">{{ getFinishLabel('我') }}</span>
              <div v-if="chatBubbles['我']" class="chat-bubble">{{ chatBubbles['我'] }}</div>
            </div>
            <div class="player-details">
              <div class="player-name">{{ getInGameName('我') }}</div>
              <div class="player-status">剩余 {{ myCards.length }} 张</div>
            </div>
            <div class="quick-texts">
              <div class="quick-texts-title">快捷文字</div>
              <div class="quick-text-buttons">
                <button class="quick-text-btn" @click="sendQuickText('快点出牌')">快点出牌</button>
                <button class="quick-text-btn" @click="sendQuickText('这牌怎么打')">这牌怎么打</button>
                <button class="quick-text-btn" @click="sendQuickText('我走了')">我走了</button>
              </div>
            </div>
          </div>

          <div class="my-hand" @mousedown="startDragging">
            <div v-for="(card, index) in myCards" :key="'my-' + index"
                 class="card"
                 :class="{ selected: selectedCards.includes(index), suggested: suggestedCards.includes(index) }"
                 draggable="true"
                 @mousedown.stop="handleCardMousedown(index, $event)"
                 @mouseup.stop="handleCardMouseup"
                 @mouseleave="handleCardMouseup"
                 @mouseenter="handleCardMouseenter(index, $event)"
                 @dragstart="handleDragStart(index, $event)"
                 @dragover.prevent
                 @drop="handleDragDrop(index, $event)">
              <img :src="getCardImage(card)" :alt="getCardName(card)" class="card-img">
            </div>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import '../assets/card.css'
import { idToCard, cardsToIds } from '../utils/cardConverter'
import webSocketService, { WS_MESSAGE_TYPES } from '../api/websocket'
import { getRoomDetail, ready, exitRoom } from '../api/game'
import soundManager from '../utils/soundManager'

// 路由实例
const router = useRouter()
const route = useRoute()

// 响应式数据
const roomId = ref(route.query.roomId || '未知房间') // 从路由获取房间号
const isReady = ref(false) // 是否准备就绪
const playerCount = ref(0) // 当前房间人数
const roomPlayers = ref([]) // 房间玩家列表
const currentUserId = ref('')
const wsConnected = ref(false)
const wsJoined = ref(false)
const gameState = ref('prepare') // prepare, playing, finished
const roomCreatorId = ref(null)

// 玩家ID和位置映射
const myPlayerId = ref(null)
const playerPositions = ref({
  '我': null,
  '右对手': null,
  '队友': null,
  '左对手': null
})

const handleTableClear = () => {
  try {
    deskDisplay.value = {
      '我': [], '右对手': [], '队友': [], '左对手': []
    }
  } catch (e) {
  }
}

// 计算属性：获取当前用户名
const username = computed(() => {
  const userInfo = JSON.parse(sessionStorage.getItem('userInfo') || localStorage.getItem('userInfo') || '{}')
  return userInfo.nickname || sessionStorage.getItem('nickname') || localStorage.getItem('nickname') || '未知玩家'
})

// 玩家名称映射
const playerNames = ref({
  '我': username.value,
  '右对手': '右对手',
  '队友': '队友',
  '左对手': '左对手'
})

const levelCard = ref({
  rankIndex: null
})

const getGameRoomId = () => {
  const id = String(roomId.value || '')
  if (!id) return ''
  return id.startsWith('room_') ? id : `room_${id}`
}

const mapLevelIndexToCardRank = (rankIndex) => {
  if (rankIndex === null || rankIndex === undefined) return null
  const idx = Number(rankIndex)
  if (Number.isNaN(idx)) return null
  // 0-12 对应 3,4,5,6,7,8,9,10,J,Q,K,A,2
  if (idx >= 0 && idx <= 10) return idx + 3
  if (idx === 11) return 1
  if (idx === 12) return 2
  return null
}

// 计算属性：判断是否为房主
const isRoomOwner = computed(() => {
  if (roomCreatorId.value === null || roomCreatorId.value === undefined) return false
  return String(roomCreatorId.value) === String(currentUserId.value)
})

// 计算属性：判断是否可以开始游戏（所有人包括房主都要准备）
const canStartGame = computed(() => {
  if (!isRoomOwner.value) return false
  if (!roomPlayers.value || roomPlayers.value.length < 2) return false
  return roomPlayers.value
      .filter(p => String(p.userId) !== String(currentUserId.value))
      .every(p => p.isReady === 1)
})

// 生成模拟手牌（27张）
const generateMockCards = () => {
  const cards = []
  const suits = ['hearts', 'diamonds', 'clubs', 'spades']
  const ranks = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]

  // 生成普通牌
  for (let i = 0; i < 27; i++) {
    const suit = suits[Math.floor(Math.random() * suits.length)]
    const rank = ranks[Math.floor(Math.random() * ranks.length)]
    cards.push({ suit, rank })
  }

  // 随机添加大小王
  const hasSmallJoker = Math.random() > 0.5
  const hasBigJoker = Math.random() > 0.5

  if (hasSmallJoker) cards.push({ suit: 'jokers', rank: 14 })
  if (hasBigJoker) cards.push({ suit: 'jokers', rank: 15 })

  return cards.slice(0, 27) // 确保正好27张
}

const myCards = ref(generateMockCards())
const teammateCards = ref(Array(27).fill(null))
const leftOpponentCards = ref(Array(27).fill(null))
const rightOpponentCards = ref(Array(27).fill(null))
const selectedCards = ref([])
const suggestedCards = ref([])
const currentPlayer = ref('我')
const isDragging = ref(false)
const dragType = ref(true)
const mouseDownX = ref(0) // 记录鼠标按下时的X坐标
const mouseDownY = ref(0) // 记录鼠标按下时的Y坐标
const deskDisplay = ref({
  '我': [], '右对手': [], '队友': [], '左对手': []
})

const finishOrder = ref([])
const finishLabels = ref({})

const getFinishLabel = (position) => {
  return finishLabels.value[position] || ''
}

const updateFinishLabelsFromOrder = () => {
  const labels = {}
  if (finishOrder.value.length >= 1) labels[finishOrder.value[0]] = '头游'
  if (finishOrder.value.length >= 2) labels[finishOrder.value[1]] = '二游'
  if (finishOrder.value.length >= 3) labels[finishOrder.value[2]] = '三游'

  const allPositions = ['我', '右对手', '队友', '左对手']
  const remaining = allPositions.filter(p => !finishOrder.value.includes(p))
  if (finishOrder.value.length >= 3 && remaining.length === 1) {
    labels[remaining[0]] = '末游'
  }
  finishLabels.value = labels
}

const markFinishedIfNeeded = (position) => {
  if (gameState.value !== 'playing') return
  if (!position) return
  if (finishOrder.value.includes(position)) return

  let remaining = null
  if (position === '我') remaining = myCards.value.length
  if (position === '队友') remaining = teammateCards.value.length
  if (position === '左对手') remaining = leftOpponentCards.value.length
  if (position === '右对手') remaining = rightOpponentCards.value.length

  if (remaining !== 0) return

  finishOrder.value.push(position)
  updateFinishLabelsFromOrder()

  if (finishOrder.value.length === 3) {
    gameState.value = 'finished'
    if (countdownTimer) {
      clearInterval(countdownTimer)
      countdownTimer = null
    }
    ElMessage.success('本局结束')
  }
}

// 倒计时相关
const countdown = ref(30) // 默认30秒倒计时
let countdownTimer = null // 倒计时定时器
let isAutoPlay = false // 是否是自动出牌

// 开始倒计时
const startCountdown = () => {
  if (countdownTimer) {
    clearInterval(countdownTimer)
  }
  countdown.value = 30
  countdownTimer = setInterval(() => {
    countdown.value--
    if (countdown.value <= 0) {
      clearInterval(countdownTimer)

      // 判断是否是自由出牌（其他人都不要）
      const isFreePlay = checkIsFreePlay()

      if (isFreePlay) {
        // 自由出牌，自动出最小的牌
        autoPlaySmallestCard()
      } else {
        // 跟牌，自动不出
        pass()
      }
    }
  }, 1000)
}

// 检查是否是自由出牌（其他人都不要）
const checkIsFreePlay = () => {
  // 检查其他三个玩家的桌面显示
  const otherPlayers = ['右对手', '队友', '左对手']

  for (const player of otherPlayers) {
    const display = deskDisplay.value[player]
    // 如果有玩家出了牌（不是"不要"），说明我在跟牌，不是自由出牌
    if (display && display.length > 0 && display[0] && display[0].type !== 'pass') {
      return false
    }
  }

  // 其他人都显示"不要"或为空，说明是自由出牌
  return true
}

// 自动出最小的牌
const autoPlaySmallestCard = () => {
  if (currentPlayer.value !== '我' || myCards.value.length === 0) {
    return
  }

  // 标记为自动出牌
  isAutoPlay = true

  // 尝试获取提示
  webSocketService.send(WS_MESSAGE_TYPES.SUGGEST_CARDS, {})
}

// 重置倒计时
const resetCountdown = () => {
  if (countdownTimer) {
    clearInterval(countdownTimer)
  }
  countdown.value = 30
}

// 发送快捷文字
const sendQuickText = (text) => {
  // 模拟发送快捷文字到聊天
  ElMessage.info(`发送了快捷文字：${text}`)
  // 实际项目中，这里应该通过WebSocket发送消息给其他玩家
  webSocketService.send(WS_MESSAGE_TYPES.CHAT_MESSAGE, {
    roomId: roomId.value,
    message: text,
    type: 'quick'
  })
}

const getInGameName = (position) => {
  const pid = playerPositions.value?.[position]
  if (!pid) return position
  if (String(pid).includes('ai_player_')) return 'AI玩家'
  return getPlayerNickname(pid)
}

const getInGameAvatar = (position) => {
  const pid = playerPositions.value?.[position]
  if (!pid) return ''
  if (String(pid).includes('ai_player_')) return ''
  return getPlayerAvatar(pid)
}

const chatBubbles = ref({})
const chatBubbleTimers = {}

const showChatBubble = (position, text) => {
  if (!position) return
  if (chatBubbleTimers[position]) {
    clearTimeout(chatBubbleTimers[position])
    chatBubbleTimers[position] = null
  }
  chatBubbles.value = {
    ...chatBubbles.value,
    [position]: text
  }
  chatBubbleTimers[position] = setTimeout(() => {
    const next = { ...chatBubbles.value }
    delete next[position]
    chatBubbles.value = next
    chatBubbleTimers[position] = null
  }, 3000)
}

const handleChatMessage = (data) => {
  if (!data) return
  const pid = data.playerId
  const msg = data.message
  if (!pid || !msg) return
  const position = Object.keys(playerPositions.value).find(
      pos => String(playerPositions.value[pos]) === String(pid)
  )
  if (!position) return
  showChatBubble(position, msg)
}

// 页面挂载时校验登录状态并初始化WebSocket
onMounted(() => {
  const isLogin = sessionStorage.getItem('isLogin') || localStorage.getItem('isLogin')
  if (!isLogin) {
    ElMessage.warning('请先登录后再进入游戏！')
    router.push('/login')
    return
  }

  // 获取玩家ID
  const userInfo = JSON.parse(sessionStorage.getItem('userInfo') || localStorage.getItem('userInfo') || '{}')
  currentUserId.value = String(userInfo.id || sessionStorage.getItem('userId') || localStorage.getItem('userId') || '')

  console.log('BattleView挂载 - 用户信息:', userInfo)
  console.log('BattleView挂载 - 用户ID:', currentUserId.value)
  console.log('BattleView挂载 - 房间ID:', roomId.value)

  if (!currentUserId.value || currentUserId.value === 'undefined' || currentUserId.value === 'null') {
    ElMessage.error('无法获取用户信息，请重新登录')
    router.push('/login')
    return
  }

  // 获取房间详情（包括当前人数）
  fetchRoomDetail().then(() => {
    connectWebSocket()
  })

  // 监听游戏开始事件
  webSocketService.on(WS_MESSAGE_TYPES.GAME_START, handleGameStart)

  // 监听玩家行动事件
  webSocketService.on(WS_MESSAGE_TYPES.PLAYER_ACTION, handlePlayerAction)

  // 监听回合更新事件
  webSocketService.on(WS_MESSAGE_TYPES.TURN_CHANGE, handleTurnChange)

  // 监听出牌提示成功事件
  webSocketService.on(WS_MESSAGE_TYPES.SUGGEST_CARDS_SUCCESS, handleSuggestCardsSuccess)

  // 监听错误消息
  webSocketService.on(WS_MESSAGE_TYPES.ERROR, handleError)

  // 监听房间更新消息（人数、准备状态）
  webSocketService.on(WS_MESSAGE_TYPES.ROOM_UPDATE, handleRoomUpdate)

  webSocketService.on(WS_MESSAGE_TYPES.CHAT_MESSAGE, handleChatMessage)

  // 监听游戏结束事件
  webSocketService.on(WS_MESSAGE_TYPES.GAME_END, handleGameEnd)

  webSocketService.on(WS_MESSAGE_TYPES.TABLE_CLEAR, handleTableClear)

  webSocketService.on('connect', () => {
    wsConnected.value = true
  })

  webSocketService.on('disconnect', () => {
    wsConnected.value = false
    wsJoined.value = false
  })

  webSocketService.on(WS_MESSAGE_TYPES.JOIN_ROOM_SUCCESS, () => {
    wsJoined.value = true
  })
})

const connectWebSocket = () => {
  try {
    wsConnected.value = false
    wsJoined.value = false
    webSocketService.connect(currentUserId.value, getGameRoomId())
  } catch (error) {
    console.error('WebSocket连接失败:', error)
    ElMessage.error('网络连接失败，请检查网络状态')
  }
}

// 获取房间详情
const fetchRoomDetail = async () => {
  try {
    const response = await getRoomDetail(roomId.value)
    if (response) {
      if (response.playerCount !== undefined) {
        playerCount.value = response.playerCount
      }
      if (response.players) {
        roomPlayers.value = response.players
      }
      if (response.creatorId !== undefined && response.creatorId !== null) {
        roomCreatorId.value = response.creatorId
      }
    }
  } catch (error) {
    console.error('获取房间详情失败:', error)
  }
}

// 获取玩家昵称
const getPlayerNickname = (userId) => {
  if (userId && typeof userId === 'object') {
    if (userId.nickname) return userId.nickname
    if (userId.userId !== undefined && userId.userId !== null) {
      return getPlayerNickname(userId.userId)
    }
  }

  const userInfo = JSON.parse(sessionStorage.getItem('userInfo') || localStorage.getItem('userInfo') || '{}')
  if (userInfo.id == userId) {
    return userInfo.nickname || sessionStorage.getItem('nickname') || localStorage.getItem('nickname') || '未知玩家'
  }
  const matched = roomPlayers.value.find(p => String(p.userId) === String(userId))
  return matched?.nickname || matched?.username || `玩家${userId}`
}

// 获取玩家头像
const getPlayerAvatar = (userId) => {
  if (userId && typeof userId === 'object') {
    if (userId.avatar) return userId.avatar
    if (userId.userId !== undefined && userId.userId !== null) {
      return getPlayerAvatar(userId.userId)
    }
  }

  const userInfo = JSON.parse(sessionStorage.getItem('userInfo') || localStorage.getItem('userInfo') || '{}')
  if (userInfo.id == userId) {
    return userInfo.avatar || ''
  }
  const matched = roomPlayers.value.find(p => String(p.userId) === String(userId))
  return matched?.avatar || ''
}

// 核心方法
// 生成新的级牌
const generateNewLevelCard = () => {
  // 后端返回 0-12 对应 2-A (0=2, 1=3, 2=4, ..., 12=A)
  levelCard.value.rankIndex = 0

  console.log('生成新的级牌:', levelCard.value.rankIndex)

  return getLevelCardName()
}

// 切换准备状态（准备/取消准备）
const toggleReady = () => {
  if (!wsConnected.value) {
    ElMessage.info('网络连接中，请稍后再操作')
    return
  }

  if (!wsJoined.value) {
    ElMessage.info('正在加入房间，请稍后…')
    return
  }

  // 调用准备接口（后端应该支持切换准备状态）
  ready(roomId.value)
      .then(() => {
        isReady.value = !isReady.value
        ElMessage.success(isReady.value ? '已准备' : '已取消准备')
      })
      .catch((e) => {
        ElMessage.error(e?.message || '操作失败')
      })
}

// 房主开始游戏
const handleStartGame = () => {
  if (!isRoomOwner.value) {
    ElMessage.warning('只有房主可以开始游戏')
    return
  }

  if (!canStartGame.value) {
    const unreadyPlayers = roomPlayers.value
        .filter(p => String(p.userId) !== String(currentUserId.value))
        .filter(p => p.isReady !== 1)
        .map(p => getPlayerNickname(p))
        .join('、')
    if (unreadyPlayers) {
      ElMessage.warning(`以下玩家还未准备：${unreadyPlayers}，无法开始游戏`)
    } else {
      ElMessage.warning('等待更多玩家加入或准备')
    }
    return
  }

  if (!wsConnected.value) {
    ElMessage.info('网络连接中，请稍后…')
    return
  }

  ElMessage.success('游戏即将开始...')
  webSocketService.send(WS_MESSAGE_TYPES.START_GAME, {
    roomId: roomId.value
  })
}

// 返回大厅（未准备时）
const goBackToLobby = () => {
  ElMessageBox.confirm(
      '确定要返回大厅吗？',
      '提示',
      { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' }
  ).then(() => {
    tryExitRoomAndDisconnect()
    router.push('/lobby')
  })
}

// 退出并解散房间
const exitAndDissolveRoom = () => {
  ElMessageBox.confirm(
      '确定要退出房间吗？',
      '警告',
      { confirmButtonText: '确定', cancelButtonText: '取消', type: 'error' }
  ).then(() => {
    tryExitRoomAndDisconnect()
    router.push('/lobby')
  })
}

const tryExitRoomAndDisconnect = () => {
  try {
    exitRoom(getGameRoomId())
  } catch (e) {
  }
  try {
    webSocketService.disconnect()
  } catch (e) {
  }
}

const handleBeforeUnload = () => {
  tryExitRoomAndDisconnect()
}

window.addEventListener('beforeunload', handleBeforeUnload)

onBeforeUnmount(() => {
  window.removeEventListener('beforeunload', handleBeforeUnload)
  try {
    webSocketService.off(WS_MESSAGE_TYPES.CHAT_MESSAGE, handleChatMessage)
  } catch (e) {
  }

  try {
    webSocketService.off(WS_MESSAGE_TYPES.TABLE_CLEAR, handleTableClear)
  } catch (e) {
  }
  try {
    Object.keys(chatBubbleTimers).forEach((k) => {
      if (chatBubbleTimers[k]) {
        clearTimeout(chatBubbleTimers[k])
        chatBubbleTimers[k] = null
      }
    })
  } catch (e) {
  }
  chatBubbles.value = {}
  tryExitRoomAndDisconnect()
})

// 获取卡牌图片路径
const getCardImage = (card) => {
  if (!card) return ''

  try {
    if (card.suit === 'jokers') {
      const jokerType = card.rank === 14 ? '小' : '大'
      return new URL(`../assets/joker/${jokerType}.png`, import.meta.url).href
    }

    const suitMap = {
      hearts: 'hearts',
      diamonds: 'diamonds',
      clubs: 'clubs',
      spades: 'spades'
    }

    const suitName = suitMap[card.suit]
    if (!suitName) {
      console.error('未知花色:', card.suit)
      return ''
    }

    const rank = card.rank
    if (rank < 1 || rank > 15) {
      console.error('无效点数:', rank)
      return ''
    }

    return new URL(`../assets/${suitName}/${rank}.png`, import.meta.url).href
  } catch (error) {
    console.error('获取卡牌图片失败:', error, '卡牌信息:', card)
    return ''
  }
}

// 获取级牌图片
const getLevelCardImage = () => {
  try {
    const cardRank = mapLevelIndexToCardRank(levelCard.value.rankIndex)
    if (cardRank === null) return ''
    return new URL(`../assets/spades/${cardRank}.png`, import.meta.url).href
  } catch (error) {
    console.error('获取级牌图片失败:', error)
    return ''
  }
}

// 获取级牌名称
const getLevelCardName = () => {
  const idx = levelCard.value.rankIndex
  if (idx === null || idx === undefined) return ''
  const rankMap = {
    0: '2', 1: '3', 2: '4', 3: '5', 4: '6', 5: '7', 6: '8', 7: '9',
    8: '10', 9: 'J', 10: 'Q', 11: 'K', 12: 'A'
  }
  return rankMap[idx] || ''
}

// 获取卡牌名称
const getCardName = (card) => {
  if (!card) return ''
  if (card.suit === 'jokers') {
    return card.rank === 14 ? '小王' : '大王'
  }
  const rankMap = { 1: 'A', 2: '2', 3: '3', 4: '4', 5: '5', 6: '6', 7: '7', 8: '8', 9: '9', 10: '10', 11: 'J', 12: 'Q', 13: 'K' }
  const suitMap = { hearts: '红桃', diamonds: '方块', clubs: '梅花', spades: '黑桃' }
  return `${suitMap[card.suit]}${rankMap[card.rank]}`
}

const sortCards = () => {
  const suitPriority = { spades: 4, hearts: 3, clubs: 2, diamonds: 1, jokers: 0 }
  const order = [15, 14, 2, 1, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3]
  const rankOrderValue = (rank) => {
    const idx = order.indexOf(Number(rank))
    return idx === -1 ? order.length : idx
  }

  console.log('排序前手牌:', myCards.value)

  myCards.value = [...myCards.value].sort((a, b) => {
    const ra = rankOrderValue(a.rank)
    const rb = rankOrderValue(b.rank)
    if (ra !== rb) return ra - rb
    return (suitPriority[b.suit] || 0) - (suitPriority[a.suit] || 0)
  })

  console.log('排序后手牌:', myCards.value)

  selectedCards.value = []
  suggestedCards.value = []
}

// 拖拽相关方法
const startDragging = () => { isDragging.value = true }
const stopDragging = () => { isDragging.value = false }
const handleCardMousedown = (index, event) => {
  if (currentPlayer.value !== '我') return
  // 记录点击位置，用于区分点击和拖拽
  mouseDownX.value = event.clientX
  mouseDownY.value = event.clientY
  isDragging.value = true
  dragType.value = !selectedCards.value.includes(index)
  toggleCardLogic(index)
}
const handleCardMouseenter = (index, event) => {
  // 只有在鼠标按住拖拽的情况下，划过卡牌才会提起卡牌
  if (!isDragging.value || currentPlayer.value !== '我') return

  // 检查是否有明显的鼠标移动，区分点击和拖拽
  if (Math.abs(event.clientX - mouseDownX.value) < 5 && Math.abs(event.clientY - mouseDownY.value) < 5) {
    return // 没有明显移动，不执行拖拽选择
  }

  // 检查鼠标按键是否真的按住（使用isDragging状态）
  const isIncluded = selectedCards.value.includes(index)
  if (dragType.value && !isIncluded) {
    selectedCards.value.push(index)
  } else if (!dragType.value && isIncluded) {
    selectedCards.value = selectedCards.value.filter(i => i !== index)
  }
}

// 确保在鼠标释放时立即停止拖拽
const handleCardMouseup = () => {
  stopDragging()
}
const toggleCardLogic = (index) => {
  // 用户手动选择卡牌时，清除提示的高亮状态
  if (suggestedCards.value.length > 0) {
    suggestedCards.value = []
  }

  if (selectedCards.value.includes(index)) {
    selectedCards.value = selectedCards.value.filter(i => i !== index)
  } else {
    selectedCards.value.push(index)
  }
}
const toggleCard = (index) => {
  if (currentPlayer.value !== '我') {
    ElMessage.info('现在不是你的回合！')
    return
  }
}

// 卡牌拖拽排序功能
const draggedCardIndex = ref(null)
const handleDragStart = (index, event) => {
  draggedCardIndex.value = index
  event.dataTransfer.effectAllowed = 'move'
}
const handleDragDrop = (targetIndex, event) => {
  event.preventDefault()

  if (draggedCardIndex.value === null || draggedCardIndex.value === targetIndex) return

  // 创建新的手牌数组
  const newCards = [...myCards.value]

  // 移除被拖拽的卡牌
  const [draggedCard] = newCards.splice(draggedCardIndex.value, 1)

  // 将卡牌插入到目标位置
  newCards.splice(targetIndex, 0, draggedCard)

  // 更新手牌
  myCards.value = newCards

  // 重置拖拽状态
  draggedCardIndex.value = null
}

// 出牌逻辑
const playCards = () => {
  if (selectedCards.value.length === 0 || currentPlayer.value !== '我') return

  try {
    // 将前端卡牌对象转换为后端需要的卡牌ID
    const selectedCardObjects = selectedCards.value.map(index => {
      const card = myCards.value[index]
      console.log('选择的卡牌:', card, '索引:', index)
      return card
    })

    const cardIds = cardsToIds(selectedCardObjects)
    console.log('发送的卡牌ID:', cardIds)

    // 发送出牌消息到后端
    webSocketService.send(WS_MESSAGE_TYPES.PLAY_CARD, {
      cards: cardIds
    })

    soundManager.play('play_card') // 播放出牌音效
    // 不再立即更新本地状态，而是等待后端的PLAYER_ACTION消息来确认
    // 这样如果后端返回错误，前端的状态就不会被错误地更新
    selectedCards.value = []

  } catch (error) {
    console.error('出牌失败:', error)
    ElMessage.error('出牌失败，请重试')
  }
}
// 检查是否为顺子（点数连续）
const isStraightHand = (cards) => {
  if (cards.length < 5) return false

  // 排除大小王
  const validCards = cards.filter(card => card.rank < 14)
  if (validCards.length !== cards.length) return false

  // 获取所有点数并排序
  const ranks = validCards.map(card => card.rank).sort((a, b) => a - b)

  // 检查点数是否连续
  for (let i = 1; i < ranks.length; i++) {
    if (ranks[i] !== ranks[i - 1] + 1) {
      return false
    }
  }

  return true
}

// 不出
const pass = () => {
  if (currentPlayer.value !== '我') {
    ElMessage.info('现在不是你的回合！')
    return
  }

  // 发送不出牌消息到后端
  webSocketService.send(WS_MESSAGE_TYPES.PLAY_CARD, {
    cards: [] // 空数组表示不出牌
  })

  // 不再立即更新本地状态，而是等待后端的PLAYER_ACTION消息来确认
}

// 提示
const hint = () => {
  if (currentPlayer.value !== '我') {
    ElMessage.info('现在不是你的回合！')
    return
  }

  // 清除之前的高亮
  suggestedCards.value = []

  // 发送提示请求到后端
  webSocketService.send(WS_MESSAGE_TYPES.SUGGEST_CARDS, {})
}

// 处理出牌提示成功响应
const handleSuggestCardsSuccess = (data) => {
  console.log('收到出牌提示响应:', data)

  if (data.message) {
    if (data.message === '没有合适的牌可出') {
      ElMessage.info('没有合适的牌可出，请选择不出')
      suggestedCards.value = []

      // 如果是自动出牌模式，则不出牌
      if (isAutoPlay) {
        isAutoPlay = false
        pass()
      }
      return
    }
    // 移除了重复的 ElMessage.success(data.message)
    // 因为后面会有更详细的提示信息
  }

  if (data.cards && data.cards.length > 0) {
    // 将后端返回的卡牌ID转换为前端卡牌对象
    const suggestedCardObjects = data.cards.map(id => idToCard(id))

    // 找到这些卡牌在手牌中的索引
    const suggestedIndices = []
    suggestedCardObjects.forEach(suggestedCard => {
      const index = myCards.value.findIndex(card =>
          card.suit === suggestedCard.suit && card.rank === suggestedCard.rank &&
          ((card.deck !== undefined && card.deck !== null && suggestedCard.deck !== undefined && suggestedCard.deck !== null)
              ? card.deck === suggestedCard.deck
              : true)
      )
      if (index !== -1) {
        suggestedIndices.push(index)
      }
    })

    // 清空之前的选中状态
    selectedCards.value = []

    // 高亮显示建议的卡牌
    suggestedCards.value = suggestedIndices

    // 如果是自动出牌模式，直接出牌
    if (isAutoPlay) {
      isAutoPlay = false

      // 将卡牌ID转换为后端需要的格式
      const cardIds = data.cards

      // 发送出牌消息到后端
      webSocketService.send(WS_MESSAGE_TYPES.PLAY_CARD, {
        cards: cardIds
      })

      // 清空选中状态
      selectedCards.value = []

      ElMessage.info('自动出牌：' + suggestedCardObjects.map(card => getCardName(card)).join(', '))
    } else {
      // 手动模式，自动选中建议的卡牌
      selectedCards.value = [...suggestedIndices]

      // 显示提示信息
      const cardNames = suggestedCardObjects.map(card => getCardName(card)).join(', ')
      const cardType = data.cardType || ''
      ElMessage.success(`建议出牌：${cardType} (${cardNames})`)
    }
  }
}

// 处理回合更新消息
const handleTurnChange = (data) => {
  console.log('收到回合更新消息:', data)

  if (data) {
    const isMyTurn = data.myTurn !== undefined ? data.myTurn : data.isMyTurn
    if (isMyTurn) {
      currentPlayer.value = '我'
      ElMessage.info('轮到你出牌了！')
      startCountdown()
      return
    }

    if (countdownTimer) {
      clearInterval(countdownTimer)
      countdownTimer = null
    }

    if (data.currentPlayerId) {
      const position = Object.keys(playerPositions.value).find(
          pos => String(playerPositions.value[pos]) === String(data.currentPlayerId)
      )

      if (position) {
        currentPlayer.value = position
        ElMessage.info(`轮到 ${position} 出牌`)
      } else {
        const name = getPlayerNickname(data.currentPlayerId)
        currentPlayer.value = name
        ElMessage.info(`轮到 ${name} 出牌`)
      }
    }
  } else {
    console.log('回合更新消息数据为空')
  }
}

// 处理游戏开始消息
const handleGameStart = (data) => {
  try {
    console.log('收到游戏开始消息:', data)

    // 检查消息格式是否正确
    if (!data) {
      console.warn('游戏开始消息为空，可能是测试消息')
      return
    }

    // 检查手牌数据
    if (!data.myCards || !Array.isArray(data.myCards) || data.myCards.length === 0) {
      console.warn('游戏开始消息缺少有效手牌数据，可能是连接测试消息')
      return
    }

    console.log('收到游戏开始消息，手牌数量:', data.myCards.length)
    console.log('手牌数据:', data.myCards)

    gameState.value = 'playing'
    finishOrder.value = []
    finishLabels.value = {}

    // 保存当前玩家ID
    if (data.playerId) {
      myPlayerId.value = data.playerId
    }

    // 设置玩家位置映射
    if (data.playerPositions) {
      playerPositions.value = data.playerPositions
      console.log('玩家位置映射:', playerPositions.value)

      // 根据玩家ID设置玩家名称
      Object.keys(playerPositions.value).forEach(position => {
        const playerId = playerPositions.value[position]
        if (playerId) {
          if (playerId.includes('ai_player_')) {
            // AI玩家显示为"AI玩家"
            playerNames.value[position] = 'AI玩家'
          } else if (position === '我') {
            // 自己显示为用户名
            playerNames.value[position] = username.value
          } else {
            // 其他真实玩家显示为"玩家"
            playerNames.value[position] = '玩家'
          }
        }
      })

      console.log('玩家名称映射:', playerNames.value)
    } else {
      // 如果后端没有提供位置映射，使用默认映射
      const userInfo = JSON.parse(sessionStorage.getItem('userInfo') || localStorage.getItem('userInfo') || '{}')
      const userId = userInfo.id || sessionStorage.getItem('userId') || localStorage.getItem('userId') || ''
      playerPositions.value = {
        '我': userId,
        '右对手': null,
        '队友': null,
        '左对手': null
      }
    }

    // 设置级牌信息
    if (data.levelCard !== undefined && data.levelCard !== null) {
      levelCard.value.rankIndex = data.levelCard
      console.log('设置级牌:', levelCard.value.rankIndex)
    }

    let levelCardName = ''
    levelCardName = getLevelCardName()

    // 解析手牌数据，将后端卡牌ID转换为前端卡牌对象
    const handCards = data.myCards.map(id => {
      try {
        const card = idToCard(id)
        console.log(`从后端接收卡牌ID: ${id} ->`, card)
        return card
      } catch (error) {
        console.error('转换卡牌ID失败:', id, error)
        return null
      }
    }).filter(card => card !== null)

    console.log('所有手牌:', handCards)

    // 确保手牌数量正确
    if (handCards.length !== 27) {
      ElMessage.warning(`手牌数量异常: ${handCards.length} 张，应为27张`)
    }

    myCards.value = handCards

    // 自动理牌
    sortCards()

    // 更新其他玩家手牌数量（后端不会发送其他玩家的具体牌，只会发送数量）
    // 初始化时每个玩家应该有27张牌
    teammateCards.value = Array(27).fill(null)
    leftOpponentCards.value = Array(27).fill(null)
    rightOpponentCards.value = Array(27).fill(null)

    // 显示级牌信息
    if (!levelCardName) {
      levelCardName = getLevelCardName()
    }

    soundManager.play('game_start') // 播放游戏开始音效
    ElMessage.success(`游戏开始！当前级牌：${levelCardName}，已为您自动理牌`)
    console.log('游戏开始，已自动理牌')
  } catch (error) {
    console.error('处理游戏开始消息失败:', error)
    ElMessage.error('游戏开始处理失败，请重试')
  }
}

const checkWin = () => {
  markFinishedIfNeeded('我')
}

// 处理玩家行动消息
const handlePlayerAction = (data) => {
  if (!data) return

  const { playerId, cards } = data

  // 根据玩家ID查找对应的位置
  const position = Object.keys(playerPositions.value).find(
      pos => String(playerPositions.value[pos]) === String(playerId)
  )

  if (!position) {
    console.log('未知玩家ID:', playerId, '当前玩家映射:', playerPositions.value)
    return
  }

  // 处理出牌动作
  if (cards && cards.length > 0) {
    // 根据玩家位置更新界面
    if (position === '队友') {
      deskDisplay.value['队友'] = cards.map(id => idToCard(id))
      const nextLen = Math.max(0, teammateCards.value.length - cards.length)
      teammateCards.value = Array(nextLen).fill(null)
      markFinishedIfNeeded('队友')
    } else if (position === '左对手') {
      deskDisplay.value['左对手'] = cards.map(id => idToCard(id))
      const nextLen = Math.max(0, leftOpponentCards.value.length - cards.length)
      leftOpponentCards.value = Array(nextLen).fill(null)
      markFinishedIfNeeded('左对手')
    } else if (position === '右对手') {
      deskDisplay.value['右对手'] = cards.map(id => idToCard(id))
      const nextLen = Math.max(0, rightOpponentCards.value.length - cards.length)
      rightOpponentCards.value = Array(nextLen).fill(null)
      markFinishedIfNeeded('右对手')
    } else if (position === '我') {
      // 处理当前玩家的出牌
      const cardIds = cards
      const cardsToPlay = cardIds.map(id => idToCard(id))

      // 自动排序顺子：如果是5张以上且点数连续，则按点数从小到大排序
      if (cardsToPlay.length >= 5 && isStraightHand(cardsToPlay)) {
        cardsToPlay.sort((a, b) => {
          // 先比较点数
          if (a.rank !== b.rank) {
            return a.rank - b.rank
          }
          // 点数相同则按花色排序（黑桃 > 红桃 > 梅花 > 方块）
          const suitPriority = { spades: 4, hearts: 3, clubs: 2, diamonds: 1, jokers: 0 }
          return (suitPriority[b.suit] || 0) - (suitPriority[a.suit] || 0)
        })
      }

      deskDisplay.value['我'] = cardsToPlay

      // 从手牌中移除出的牌
      myCards.value = myCards.value.filter(card => {
        const cardId = cardsToIds([card])[0]
        return !cardIds.includes(cardId)
      })

      // 检查是否获胜
      checkWin()
      
      // 如果是自己出牌，立即更新当前玩家状态，避免等待 TURN_CHANGE 消息
      if (position === '我') {
        currentPlayer.value = null
        // 清除倒计时
        if (countdownTimer) {
          clearInterval(countdownTimer)
          countdownTimer = null
        }
      }
    }

    // 显示出牌信息
    const cardNames = cards.map(id => idToCard(id)).map(card => getCardName(card)).join(', ')
  } else {
    // 处理不出牌动作
    // 显示"不要"
    if (position === '队友') {
      deskDisplay.value['队友'] = [{ type: 'pass' }]
    } else if (position === '左对手') {
      deskDisplay.value['左对手'] = [{ type: 'pass' }]
    } else if (position === '右对手') {
      deskDisplay.value['右对手'] = [{ type: 'pass' }]
    } else if (position === '我') {
      // 当前玩家不出牌
      deskDisplay.value['我'] = [{ type: 'pass' }]
      
      // 立即更新当前玩家状态，避免等待 TURN_CHANGE 消息
      currentPlayer.value = null
      // 清除倒计时
      if (countdownTimer) {
        clearInterval(countdownTimer)
        countdownTimer = null
      }
    }
  }
}

// 处理房间更新消息（人数、准备状态）
const handleRoomUpdate = (data) => {
  console.log('收到房间更新消息:', data)
  if (!data) return
  if (data.playerCount !== undefined) {
    playerCount.value = data.playerCount
  }
  if (data.players) {
    roomPlayers.value = data.players
  }
  if (data.creatorId !== undefined && data.creatorId !== null) {
    roomCreatorId.value = data.creatorId
  } else {
    if (roomCreatorId.value !== null && roomCreatorId.value !== undefined) {
      const exists = roomPlayers.value.some(p => String(p.userId) === String(roomCreatorId.value))
      if (!exists && roomPlayers.value.length > 0) {
        const idx = Math.floor(Math.random() * roomPlayers.value.length)
        roomCreatorId.value = roomPlayers.value[idx]?.userId ?? roomCreatorId.value
      }
    }
  }
}

// 处理游戏结束消息
const handleGameEnd = (data) => {
  console.log('收到游戏结束消息:', data)
  if (!data) return
  
  const winnerId = data.winnerId
  const score = data.score
  const levelTeamA = data.levelTeamA
  const levelTeamB = data.levelTeamB
  
  // 判断是否是当前玩家获胜
  const isWinner = String(winnerId) === String(currentUserId.value)
  
  // 判断当前玩家所属队伍
  const myPosition = Object.keys(playerPositions.value).find(
    pos => String(playerPositions.value[pos]) === String(currentUserId.value)
  )
  const isTeamA = myPosition === '我' || myPosition === '右对手'
  const myTeamLevel = isTeamA ? levelTeamA : levelTeamB
  const otherTeamLevel = isTeamA ? levelTeamB : levelTeamA
  
  // 获取级牌名称（后端返回0-12对应2-A）
  const getLevelName = (level) => {
    if (level === null || level === undefined) return ''
    const rankMap = {
      0: '2', 1: '3', 2: '4', 3: '5', 4: '6', 5: '7', 6: '8', 7: '9',
      8: '10', 9: 'J', 10: 'Q', 11: 'K', 12: 'A'
    }
    return rankMap[level] || level
  }
  
  if (isWinner) {
    soundManager.play('victory') // 播放胜利音效
    let message = `恭喜你！游戏结束，你获得了胜利！得分：${score}`
    if (myTeamLevel) {
      message += `\n你的队伍升级到 ${getLevelName(myTeamLevel)} 级！`
    }
    ElMessage.success(message)
  } else {
    soundManager.play('defeat') // 播放失败音效
    let message = `游戏结束！玩家 ${winnerId} 获得了胜利。得分：${score}`
    if (myTeamLevel) {
      message += `\n你的队伍当前等级：${getLevelName(myTeamLevel)}`
    }
    ElMessage.info(message)
  }
  
  // 可以在这里添加游戏结束后的处理逻辑，比如显示结算界面、返回大厅等
  // 例如：setTimeout(() => { router.push('/lobby') }, 3000)
}

// 获取玩家位置样式
const getPlayerPosClass = (player) => {
  const map = { '我': 'pos-bottom', '右对手': 'pos-right', '队友': 'pos-top', '左对手': 'pos-left' }
  return map[player]
}

// 处理错误消息
const handleError = (data) => {
  if (!data) return

  console.error('收到错误消息:', data)

  // 如果是出牌错误，显示错误提示
  if (data.message && data.message.includes('出牌')) {
    ElMessage.error(data.message)
    // 不需要回滚状态，因为我们已经改为等待后端确认后再更新
  } else if (data.message) {
    ElMessage.error(data.message)
  }
}
</script>

<style scoped>
/* 字体：统一使用ChillRoundGothic字体 */
@font-face {
  font-family: "ChillRoundGothic";
  src:
      url('../assets/fonts/ChillRoundGothic_Heavy.ttf') format('truetype'),
      local('Microsoft YaHei'),
      local('SimHei'),
      local('sans-serif');
  font-weight: normal;
  font-style: normal;
  font-display: swap;
}

@font-face {
  font-family: "ChillRoundGothic";
  src:
      url('../assets/fonts/ChillRoundGothic_Heavy.ttf') format('truetype'),
      local('Microsoft YaHei Bold'),
      local('SimHei Bold'),
      local('sans-serif');
  font-weight: bold;
  font-style: normal;
  font-display: swap;
}

/* 全局字体应用 */
*:not([class*="el-icon-"]):not(svg):not(path):not(rect):not(text) {
  font-family: "ChillRoundGothic", sans-serif !important;
}

/* 过渡动画 */
.fade-enter-from, .fade-leave-to { opacity: 0; }
.fade-enter-active, .fade-leave-active { transition: opacity 0.3s ease; }
.slide-fade-enter-from { transform: translateY(30px); opacity: 0; }
.slide-fade-enter-active { transition: all 0.3s ease; }

.game-container {
  position: relative;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background:
      linear-gradient(rgba(44, 14, 0, 0.6), rgba(44, 14, 0, 0.6)), /* 暖棕色蒙版，突出按钮 */
      #d6ccc2 radial-gradient(circle, #e3d5ca 0%, #d5bdaf 100%); /* 原有径向渐变 */
  background-image:
      url('../assets/images/bg.jpg'), /* 绘画风风景背景图 */
      linear-gradient(rgba(44, 14, 0, 0.6), rgba(44, 14, 0, 0.6)),
      radial-gradient(circle, #e3d5ca 0%, #d5bdaf 100%);
  background-size: cover; /* 背景图覆盖整个页面 */
  background-position: center; /* 背景图居中 */
  background-attachment: fixed; /* 固定背景不滚动 */
  background-blend-mode: overlay; /* 叠加模式，让背景和渐变融合 */
}
/* 中央桌子区域 */
.table-area {
  background-color: hsl(44, 83%, 93%);
  border-radius: 20px;
  padding: 20px;
  border: 3px solid hsla(19, 100%, 9%, 0.6);
  width: 60%;
  min-height: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotateX(25deg) rotateY(0deg) scale(0.95);
  transform-origin: center center;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
}

/* 桌子出牌槽位 */
.desk-slots {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  grid-template-rows: 1fr 1fr 1fr;
  gap: 20px;
  width: 100%;
  height: 200px;
}

/* 出牌位置 */
.played-slot {
  display: flex;
  justify-content: center;
  align-items: center;
}

.played-slot.pos-top {
  grid-column: 2;
  grid-row: 1;
}

.played-slot.pos-left {
  grid-column: 1;
  grid-row: 2;
}

.played-slot.pos-right {
  grid-column: 3;
  grid-row: 2;
}

.played-slot.pos-bottom {
  grid-column: 2;
  grid-row: 3;
}

/* 出牌组 */
.played-cards-group {
  display: flex;
  gap: -10px;
}
.played-slot.pos-bottom .played-cards-group {
  transform: translateY(80px);
}

/* 小牌样式 */
.card.small-on-desk {
  width: 50px;
  height: 70px;
}

/* 准备阶段样式 */
.prepare-stage {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 30px;
  background: linear-gradient(to bottom, #f5e8d3, #e8d4b8);
  padding: 50px 80px;
  border-radius: 15px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
}
.room-info {
  font-size: 20px;
  color: #2c3e50;
  font-weight: bold;
}
.prepare-btns {
  display: flex;
  gap: 20px;
}

/* 玩家信息面板样式 */
.players-panel {
  background: rgba(232, 218, 197, 0.6);
  border-radius: 15px;
  padding: 20px;
  margin-top: 20px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

.panel-title {
  font-size: 18px;
  font-weight: bold;
  color: #2c3e50;
  margin-bottom: 15px;
  text-align: center;
}

.players-list {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.player-item {
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 10px;
  background: #f8f9fa;
  border-radius: 10px;
  transition: all 0.3s;
}

.player-item:hover {
  background: #e9ecef;
  transform: translateX(5px);
}

.player-avatar {
  flex-shrink: 0;
}

.player-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.player-name {
  font-size: 16px;
  font-weight: bold;
  color: #2c3e50;
}

.player-account {
  font-size: 14px;
  color: #606266;
}

.player-status {
  align-self: flex-start;
}

/* 游戏阶段样式 */
.exit-btn-container {
  position: absolute;
  top: 20px;
  right: 20px;
  z-index: 10;
}

/* 级牌显示框样式 */
.level-card-container {
  position: absolute;
  top: 20px;
  left: 20px;
  z-index: 10;
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 10px;
  padding: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  display: flex;
  flex-direction: column;
  align-items: center;
}

.level-card-title {
  font-size: 14px;
  font-weight: bold;
  margin-bottom: 5px;
  color: #333;
}

.level-card-display {
  padding: 5px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.level-card-display .card {
  width: 80px;
  height: 115px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}

.level-card-text {
  width: 60px;
  height: 85px;
  background: linear-gradient(135deg, #fff 0%, #f5f5f5 100%);
  border-radius: 8px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 32px;
  font-weight: bold;
  color: #333;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  border: 2px solid #e0e0e0;
}

/* 玩家区域布局 */
.player-section {
  position: absolute;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 5px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  backdrop-filter: blur(5px);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

/* 队友（顶部） */
.player-section.top {
  top: 10px;
  left: 50%;
  transform: translateX(-50%);
  width: 60%;
}

/* 左对手（左侧） */
.player-section.left {
  top: 50%;
  left: 10px;
  transform: translateY(-50%);
  width: 120px;
}

/* 右对手（右侧） */
.player-section.right {
  top: 50%;
  right: 10px;
  transform: translateY(-50%);
  width: 120px;
}

/* 我（底部） */
.player-section.bottom {
  bottom: 10px;
  left: 50%;
  transform: translateX(-50%);
  width: 80%;
  max-height: 180px;
}

/* 玩家信息样式 */
.player-info {
  display: flex;
  align-items: center;
  margin-bottom: 5px;
  background-color: rgba(255,255,255,0.2);
  padding: 3px 8px;
  border-radius: 10px;
  width: 100%;
  justify-content: center;
}

/* 右侧玩家信息（右对齐） */
.player-section.right .player-info {
  flex-direction: row-reverse;
}

/* 头像样式 */
.player-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: hsla(19, 100%, 9%, 0.6);
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  margin: 0 10px;
  border: 2px;
  border: 2px solid hsla(19, 100%, 9%, 0.6);
}

.finish-badge {
  position: absolute;
  top: -10px;
  right: -12px;
  padding: 2px 8px;
  border-radius: 999px;
  background: #e74c3c;
  color: #fff;
  font-size: 12px;
  font-weight: bold;
  line-height: 18px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.35);
  border: 2px solid rgba(255, 255, 255, 0.9);
  white-space: nowrap;
}

.chat-bubble {
  position: absolute;
  bottom: 46px;
  left: 50%;
  transform: translateX(-50%);
  max-width: 180px;
  padding: 6px 10px;
  border-radius: 12px;
  background: rgba(0, 0, 0, 0.75);
  color: #fff;
  font-size: 12px;
  line-height: 16px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  z-index: 120;
}

.chat-bubble::after {
  content: '';
  position: absolute;
  left: 50%;
  bottom: -6px;
  transform: translateX(-50%);
  border-width: 6px 6px 0 6px;
  border-style: solid;
  border-color: rgba(0, 0, 0, 0.75) transparent transparent transparent;
}

/* 玩家详情 */
.player-details {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

/* 右侧玩家详情（左对齐） */
.player-section.right .player-details {
  align-items: center;
}

/* 玩家名称和状态 */
.player-name {
  font-weight: bold;
  font-size: 14px;
  color: hsla(19, 100%, 9%, 0.6);
  margin-bottom: 2px;
}

.player-status {
  font-size: 12px;
  color: hsla(19, 100%, 9%, 0.6);
}

/* 玩家卡牌区域 */
.player-cards {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: nowrap;
  height: 120px;
  overflow: hidden;
}

/* 顶部队友卡牌定位和折叠 */
.player-section.top .player-cards {
  position: relative;
  height: 110px;
  width: 600px;
}

.player-section.top .player-cards .card {
  position: absolute;
  transition: all 0.3s ease;
}

/* 为27张牌设置水平位置和z-index，居中显示 */
.player-section.top .player-cards .card:nth-child(1) { transform: translateX(-240px); z-index: 1; }
.player-section.top .player-cards .card:nth-child(2) { transform: translateX(-220px); z-index: 2; }
.player-section.top .player-cards .card:nth-child(3) { transform: translateX(-200px); z-index: 3; }
.player-section.top .player-cards .card:nth-child(4) { transform: translateX(-180px); z-index: 4; }
.player-section.top .player-cards .card:nth-child(5) { transform: translateX(-160px); z-index: 5; }
.player-section.top .player-cards .card:nth-child(6) { transform: translateX(-140px); z-index: 6; }
.player-section.top .player-cards .card:nth-child(7) { transform: translateX(-120px); z-index: 7; }
.player-section.top .player-cards .card:nth-child(8) { transform: translateX(-100px); z-index: 8; }
.player-section.top .player-cards .card:nth-child(9) { transform: translateX(-80px); z-index: 9; }
.player-section.top .player-cards .card:nth-child(10) { transform: translateX(-60px); z-index: 10; }
.player-section.top .player-cards .card:nth-child(11) { transform: translateX(-40px); z-index: 11; }
.player-section.top .player-cards .card:nth-child(12) { transform: translateX(-20px); z-index: 12; }
.player-section.top .player-cards .card:nth-child(13) { transform: translateX(0); z-index: 13; }
.player-section.top .player-cards .card:nth-child(14) { transform: translateX(20px); z-index: 14; }
.player-section.top .player-cards .card:nth-child(15) { transform: translateX(40px); z-index: 15; }
.player-section.top .player-cards .card:nth-child(16) { transform: translateX(60px); z-index: 16; }
.player-section.top .player-cards .card:nth-child(17) { transform: translateX(80px); z-index: 17; }
.player-section.top .player-cards .card:nth-child(18) { transform: translateX(100px); z-index: 18; }
.player-section.top .player-cards .card:nth-child(19) { transform: translateX(120px); z-index: 19; }
.player-section.top .player-cards .card:nth-child(20) { transform: translateX(140px); z-index: 20; }
.player-section.top .player-cards .card:nth-child(21) { transform: translateX(160px); z-index: 21; }
.player-section.top .player-cards .card:nth-child(22) { transform: translateX(180px); z-index: 22; }
.player-section.top .player-cards .card:nth-child(23) { transform: translateX(200px); z-index: 23; }
.player-section.top .player-cards .card:nth-child(24) { transform: translateX(220px); z-index: 24; }
.player-section.top .player-cards .card:nth-child(25) { transform: translateX(240px); z-index: 25; }
.player-section.top .player-cards .card:nth-child(26) { transform: translateX(260px); z-index: 26; }
.player-section.top .player-cards .card:nth-child(27) { transform: translateX(280px); z-index: 27; }

/* 垂直排列的卡牌（左右对手） */
.player-cards.vertical {
  flex-direction: column;
  height: 300px;
  gap: -10px;
}

/* 垂直排列的卡牌间距 */
.player-cards.vertical .card {
  margin: -100px 0;
}

/* 卡牌样式 */
.card {
  width: 70px;
  height: 100px;
  overflow: hidden;
  position: relative;
  cursor: pointer;
  transition: all 0.2s ease;
  margin: 0 -5px;
}

.card.back {
  background: url('../assets/back.jpg');
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
}

.card.selected {
  transform: translateY(-10px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
  z-index: 100;
}

.card.suggested {
  animation: pulse 1.5s ease-in-out infinite;
  box-shadow: 0 0 15px rgba(255, 215, 0, 0.8);
  z-index: 99;
}

@keyframes pulse {
  0%, 100% {
    transform: translateY(-5px);
    box-shadow: 0 0 15px rgba(255, 215, 0, 0.8);
  }
  50% {
    transform: translateY(-10px);
    box-shadow: 0 0 25px rgba(255, 215, 0, 1);
  }
}

.card-img {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: cover;
}

/* 我的手牌样式 */
.my-hand {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: nowrap;
  padding: 10px;
  width: 100%;
  margin-top: 10px;
}

.my-hand .card {
  width: 80px;
  height: 115px;
  margin: 0 -20px;
  position: relative;
  z-index: 1;
}

.my-hand .card.selected {
  transform: translateY(-10px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
}

/* 我的信息区域 */
.my-info-section {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  padding: 5px 15px;
  border-radius: 15px;
}

/* 倒计时和操作区域 */
.action-area {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 50px !important;
  background-color: rgba(255, 255, 255, 0);
  padding: 10px 20px;
  border-radius: 25px;
  width: 100%;
}

/* 倒计时样式 */
.countdown {
  margin-right: 20px;
}

.countdown-circle {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: rgba(255, 194, 26, 0.911);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  font-weight: bold;
  animation: pulse 1s infinite;
}

@keyframes pulse {
  0% { transform: scale(1); }
  50% { transform: scale(1.1); }
  100% { transform: scale(1); }
}

/* 操作按钮 */
.action-buttons {
  display: flex;
  gap: 10px;
}

.btn {
  background-color: rgba(255, 255, 255, 0.9);
  border: 2px solid rgba(255, 255, 255, 0.5);
  border-radius: 8px;
  padding: 8px 16px;
  margin: 0 5px;
  font-size: 14px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.2s;
  color: #333;
}

.btn:hover {
  background-color: rgba(51, 51, 51, 0.8);
  color: white;
  border-color: rgba(255, 255, 255, 0.8);
}

.btn:disabled {
  background-color: rgba(204, 204, 204, 0.5);
  cursor: not-allowed;
  border-color: rgba(153, 153, 153, 0.5);
  color: rgba(102, 102, 102, 0.7);
}

.btn:disabled:hover {
  background-color: rgba(204, 204, 204, 0.5);
  color: rgba(102, 102, 102, 0.7);
}

/* 快捷文字样式 */
.quick-texts {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-left: 20px;
}

.quick-texts-title {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 5px;
}

.quick-text-buttons {
  display: flex;
  gap: 5px;
}

.quick-text-btn {
  padding: 3px 8px;
  background-color: rgba(255, 255, 255, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.5);
  border-radius: 10px;
  font-size: 11px;
  cursor: pointer;
  transition: all 0.2s;
}

.quick-text-btn:hover {
  background-color: rgba(51, 51, 51, 0.7);
  color: white;
}

/* 不要指示器 */
.pass-indicator {
  background-color: rgba(255, 255, 255, 0.7);
  padding: 5px 15px;
  border-radius: 15px;
  font-size: 14px;
  font-weight: bold;
  color: #333;
  margin-top:20px;
}

/* 当前玩家提示 */
.current-player {
  background-color: rgba(255, 255, 255, 0);
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 16px;
  font-weight: bold;
  margin: 50px 0;
  color: hsla(19, 100%, 9%, 0.6);
}
/* 响应式适配 */
@media (max-width: 768px) {
  .card { width: 60px; height: 85px; }
  .prepare-stage { padding: 30px 50px; }
}
@media (max-width: 480px) {
  .card { width: 50px; height: 70px; }
  .prepare-stage { padding: 20px 30px; }
  .prepare-btns { flex-direction: column; }
}
</style>