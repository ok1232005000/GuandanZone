<template>
  <!-- 手势特效组件（匹配成功后显示） -->
  <SpadeGestureEffect :visible="gestureEffectVisible" @complete="onGestureEffectComplete" @cancel="onGestureEffectCancel" />

  <!-- AI助手悬浮球 -->
  <AIAssistant />

  <!-- 全新棋牌风格大厅容器（无白色块） -->
  <div class="new-lobby-container">
    <!-- 顶部通栏：调窄高度 + 标题改为主菜单 -->
    <header class="top-bar">
      <div class="top-bar-inner">
        <!-- 核心修改：标题改为“主菜单” -->
        <h2 class="game-logo">主菜单</h2>
        <div class="user-operations">
          <div class="user-profile">
            <div
                class="user-avatar"
                :style="{ backgroundColor: userInfo.avatarBg || '#E0C7AD' }"
            >
              {{ userInfo.avatarText || (nickname ? nickname.charAt(0).toUpperCase() : '玩') }}
            </div>
            <div class="user-meta">
              <span class="user-name">{{ nickname }}</span>
              <span class="user-account">账号：{{ username }}</span>
            </div>
          </div>
          <div class="btn-group">
            <el-button
                type="text"
                @click="goToPersonalHome"
                class="btn-personal"
            >
              <el-icon><User /></el-icon> 个人主页
            </el-button>
            <el-button
                type="primary"
                @click="handleLogout"
                class="btn-logout"
            >
              退出登录
            </el-button>
          </div>
        </div>
      </div>
    </header>

    <!-- 核心内容区：根据布局模式切换显示 -->
    <main class="main-content">
      <!-- 初始布局：三大功能按钮 -->
      <section v-if="!isJoinRoomMode" class="operation-panel">
        <h3 class="panel-title">快速开始游戏</h3>
        <div class="operation-grid">
          <!-- 快速匹配卡片：移除圆圈，图片铺满卡片 -->
          <div class="operation-card card-match" :class="{ matching: isMatching }" @click="handleMatch">
            <img src="@/assets/images/快速匹配.png" alt="快速匹配" class="card-bg-img" />
            <div class="card-text-area">
              <div class="card-title">{{ isMatching ? '取消匹配' : '快速匹配' }}</div>
              <div class="card-desc">{{ isMatching ? '正在寻找对手...' : '自动匹配在线玩家，即刻开战' }}</div>
            </div>
          </div>

          <!-- 创建房间卡片：移除圆圈，图片铺满卡片 -->
          <div class="operation-card card-create" @click="handleCreateRoom">
            <img src="@/assets/images/创建房间.png" alt="创建房间" class="card-bg-img" />
            <div class="card-text-area">
              <div class="card-title">创建房间</div>
              <div class="card-desc">自定义房间，邀请好友对战</div>
            </div>
          </div>

          <!-- 加入房间卡片：移除圆圈，图片铺满卡片 -->
          <div class="operation-card card-join" @click="switchToJoinRoomMode()">
            <img src="@/assets/images/加入房间.png" alt="加入房间" class="card-bg-img" />
            <div class="card-text-area">
              <div class="card-title">加入房间</div>
              <div class="card-desc">输入房间号或选择空闲房间进行游戏</div>
              <div class="join-form" style="display: none;">
                <el-input
                    v-model="roomId"
                    placeholder="输入6位房间号"
                    maxlength="6"
                    show-word-limit
                    class="room-input"
                />
                <el-button
                    type="success"
                    @click="handleJoinRoom"
                    class="join-btn"
                >
                  立即加入
                </el-button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- 加入房间专属布局 -->
      <section v-if="isJoinRoomMode" class="join-room-panel">
        <div class="join-room-input-area">
          <h3 class="join-room-title">加入房间</h3>
          <div class="room-id-input-wrapper">
            <el-input
                v-model="roomId"
                placeholder="输入6位房间号"
                maxlength="6"
                show-word-limit
                class="small-room-input"
            />
            <el-button
                type="primary"
                @click="handleJoinRoom"
                class="small-join-btn"
            >
              加入
            </el-button>
          </div>
          <el-button
              type="text"
              @click="switchBackToMainMode()"
              class="back-btn"
          >
            <el-icon><ArrowLeft /></el-icon> 返回
          </el-button>
        </div>

        <div class="join-room-list-area">
          <div class="panel-header">
            <h3 class="panel-title">
              <el-icon><Collection /></el-icon> 房间列表
            </h3>
            <div class="room-stats">
              <span class="room-total">{{ roomList.length }} 个可用房间</span>
            </div>
          </div>

          <el-empty
              v-if="roomList.length === 0"
              description="暂无房间，快去创建第一个房间吧！"
              class="empty-state"
          />

          <div class="room-list-grid" v-else>
            <el-card
                v-for="room in roomList"
                :key="room.id"
                class="room-card"
                shadow="hover"
            >
              <div class="room-card-inner">
                <div class="room-info">
                  <span class="room-number">房间号：{{ room.id }}</span>
                  <el-tag
                      :type="room.userCount === 4 ? 'danger' : 'success'"
                      class="user-count-tag"
                  >
                    {{ room.userCount }}/4 人
                  </el-tag>
                </div>
                <div class="room-status">
                  {{ getRoomStatusText(room.status) }}
                </div>
                <el-button
                    type="primary"
                    size="small"
                    @click="enterRoom(room.id)"
                    :disabled="room.status === 1 || room.userCount === 4"
                    class="enter-room-btn"
                >
                  {{ room.status === 1 ? '游戏中' : (room.userCount === 4 ? '已满' : '进入') }}
                </el-button>
              </div>
            </el-card>
          </div>
        </div>
      </section>
    </main>
  </div>
</template>

<script setup>
// 核心逻辑完全不变！！！
import { ref, onMounted, onBeforeUnmount } from 'vue'
import { useRouter } from 'vue-router'
import {
  ElButton, ElInput, ElCard, ElTag, ElEmpty,
  ElMessage, ElIcon, ElMessageBox
} from 'element-plus'
import { Plus, House, Collection, Refresh, User, ArrowLeft } from '@element-plus/icons-vue'
import { joinRoom as joinRoomApi, getRoomDetail, startGame, createRoom, getRooms, joinMatch, cancelMatch, getMatchStatus, getMatchResult } from '@/api/game'
import { logout } from '@/api/auth'
import SpadeGestureEffect from '@/components/SpadeGestureEffect.vue'
import AIAssistant from '@/components/AIAssistant.vue'
import soundManager from '@/utils/soundManager'

const router = useRouter()

const userInfo = ref(JSON.parse(sessionStorage.getItem('userInfo') || localStorage.getItem('userInfo') || '{}'))
const nickname = ref(userInfo.value.nickname || sessionStorage.getItem('nickname') || localStorage.getItem('nickname') || '掼蛋玩家')
const username = ref(userInfo.value.account || sessionStorage.getItem('username') || localStorage.getItem('username') || '未知账号')

const roomId = ref('')
const roomList = ref([])
const isMatching = ref(false)
const matchInterval = ref(null)
const roomListInterval = ref(null) // 添加房间列表定时器
const gestureEffectVisible = ref(false) // 控制手势特效显示

// 获取房间列表
const getRoomList = async () => {
  try {
    const rooms = await getRooms()
    // 过滤房间：只显示有效房间（有人且状态正确）
    roomList.value = rooms
      .filter(room => {
        // 过滤掉空房间（userCount为0或undefined）
        if (!room.userCount || room.userCount === 0) {
          return false
        }
        // 过滤掉状态异常的空房间
        if (room.userCount < 2 && room.status === 1) {
          // 人数少于2但显示游戏中，可能是异常状态，过滤掉
          return false
        }
        return true
      })
      .map(room => ({
        id: room.roomNo,
        userCount: room.userCount || 0,
        status: room.userCount < 2 ? 0 : room.status, // 人数少于2强制设为等待状态
        creatorId: room.creatorId,
        levelTeamA: room.levelTeamA,
        levelTeamB: room.levelTeamB,
        currentPlayerIndex: room.currentPlayerIndex
      }))
  } catch (error) {
    ElMessage.error('获取房间列表失败：' + error.message)
  }
}

const isJoinRoomMode = ref(false)

onMounted(() => {
  const isLogin = sessionStorage.getItem('isLogin') || localStorage.getItem('isLogin')
  if (!isLogin) {
    ElMessage.warning('请先登录后再访问游戏大厅！')
    router.push('/login')
  } else {
    getRoomList()
  }
})

// 组件卸载时清理定时器
onBeforeUnmount(() => {
  stopRoomListRefresh()
  if (matchInterval.value) {
    clearInterval(matchInterval.value)
    matchInterval.value = null
  }
})

const switchToJoinRoomMode = () => {
  isJoinRoomMode.value = true
  getRoomList()
  // 开始定时刷新房间列表
  startRoomListRefresh()
}

const switchBackToMainMode = () => {
  isJoinRoomMode.value = false
  roomId.value = ''
  // 停止定时刷新
  stopRoomListRefresh()
}

// 开始定时刷新房间列表
const startRoomListRefresh = () => {
  stopRoomListRefresh() // 先清除可能存在的定时器
  roomListInterval.value = setInterval(() => {
    getRoomList()
  }, 5000) // 每5秒刷新一次
}

// 停止定时刷新房间列表
const stopRoomListRefresh = () => {
  if (roomListInterval.value) {
    clearInterval(roomListInterval.value)
    roomListInterval.value = null
  }
}

const goToPersonalHome = () => {
  router.push('/personal-home')
}

const handleMatch = async () => {
  soundManager.play('click') // 播放按钮点击音效

  if (isMatching.value) {
    // 取消匹配
    try {
      await cancelMatch()
      isMatching.value = false
      gestureEffectVisible.value = false // 关闭特效
      if (matchInterval.value) {
        clearInterval(matchInterval.value)
        matchInterval.value = null
      }
      ElMessage.success('已取消快速匹配')
    } catch (error) {
      ElMessage.error('取消匹配失败：' + error.message)
    }
    return
  }

  // 开始匹配
  isMatching.value = true
  ElMessage.info('正在快速匹配对手...')

  // 点击匹配按钮后立即开启摄像头和粒子特效
  gestureEffectVisible.value = true

  try {
    await joinMatch()
    ElMessage.success('已加入匹配队列，正在寻找对手...')

    // 轮询匹配结果
    matchInterval.value = setInterval(async () => {
      try {
        const response = await getMatchResult()
        const roomNo = response?.roomNo

        // 如果获取到房间号，说明匹配成功
        if (roomNo) {
          clearInterval(matchInterval.value)
          matchInterval.value = null
          isMatching.value = false

          ElMessage.success(`匹配成功！房间号：${roomNo}`)

          // 匹配成功，保持特效显示3秒后再进入房间
          setTimeout(() => {
            soundManager.play('match_success') // 播放匹配成功音效
            enterRoom(roomNo)
            // 进入房间后再关闭特效
            setTimeout(() => {
              gestureEffectVisible.value = false
            }, 500)
          }, 3000)
        }
      } catch (error) {
        console.error('查询匹配结果失败：', error)
        // 不要清除定时器，继续轮询
      }
    }, 2000) // 每2秒轮询一次
  } catch (error) {
    isMatching.value = false
    gestureEffectVisible.value = false
    ElMessage.error('快速匹配失败：' + error.message)
  }
}

// 手势特效完成回调
const onGestureEffectComplete = () => {
  console.log('手势特效播放完成')
  gestureEffectVisible.value = false
}

// 手势特效取消回调
const onGestureEffectCancel = async () => {
  console.log('用户从手势特效页面取消匹配')
  gestureEffectVisible.value = false

  // 调用取消匹配的逻辑
  try {
    await cancelMatch()
    isMatching.value = false
    if (matchInterval.value) {
      clearInterval(matchInterval.value)
      matchInterval.value = null
    }
    soundManager.play('match_cancel') // 播放取消匹配音效
    ElMessage.success('已取消快速匹配')
  } catch (error) {
    console.error('取消匹配失败：', error)
    // 即使接口调用失败，也关闭特效和重置状态
    isMatching.value = false
    if (matchInterval.value) {
      clearInterval(matchInterval.value)
      matchInterval.value = null
    }
  }
}

const handleCreateRoom = async (isAutoEnter = true) => {
  soundManager.play('click') // 播放按钮点击音效
  try {
    const response = await createRoom({ isPrivate: false, config: null })
    const roomNo = response.roomNo
    ElMessage.success(`房间创建成功！房间号：${roomNo}`)
    getRoomList()
    if (isAutoEnter) {
      setTimeout(() => enterRoom(roomNo), 1000)
    }
  } catch (error) {
    ElMessage.error('房间创建失败：' + error.message)
  }
}

const handleJoinRoom = async () => {
  soundManager.play('click') // 播放按钮点击音效
  if (!roomId.value) {
    ElMessage.warning('请输入房间号！')
    return
  }
  if (roomId.value.length !== 6) {
    ElMessage.warning('房间号必须是6位数字！')
    return
  }
  try {
    const response = await joinRoomApi(roomId.value)
    ElMessage.success(`成功加入房间 ${roomId.value}！`)
    roomId.value = ''
    setTimeout(() => enterRoom(response.roomNo), 1000)
  } catch (error) {
    ElMessage.error('加入房间失败：' + error.message)
  }
}

const enterRoom = async (id) => {
  try {
    const response = await getRoomDetail(id)
    ElMessage.info(`即将进入房间 ${id}，准备开始游戏！`)
    setTimeout(() => {
      router.push({ path: '/battle', query: { roomId: id } })
    }, 1000)
  } catch (error) {
    ElMessage.error('进入房间失败：' + error.message)
  }
}

const getRoomStatusText = (status) => {
  switch (status) {
    case 0:
      return '等待中'
    case 1:
      return '游戏中'
    default:
      return '未知'
  }
}

const handleLogout = () => {
  ElMessageBox.confirm(
      '确定要退出登录吗？',
      '退出提示',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
  ).then(() => {
    localStorage.removeItem('isLogin')
    localStorage.removeItem('token')
    localStorage.removeItem('nickname')
    localStorage.removeItem('username')
    localStorage.removeItem('userInfo')

    sessionStorage.removeItem('isLogin')
    sessionStorage.removeItem('token')
    sessionStorage.removeItem('nickname')
    sessionStorage.removeItem('username')
    sessionStorage.removeItem('userInfo')

    ElMessage.success('退出登录成功！')
    router.push('/login')
  }).catch(() => {
    ElMessage.info('已取消退出登录')
  })
}
</script>

<style scoped>
/* 除按钮上下padding外，其他所有样式完全不变！！！ */
@font-face {
  font-family: "ChillRoundGothic";
  src: url('@/assets/fonts/ChillRoundGothic_Heavy.ttf') format('truetype'),
  local('Microsoft YaHei'), local('SimHei'), local('sans-serif');
  font-weight: normal;
  font-style: normal;
  font-display: swap;
}
@font-face {
  font-family: "ChillRoundGothic";
  src: url('@/assets/fonts/ChillRoundGothic_Heavy.ttf') format('truetype'),
  local('Microsoft YaHei Bold'), local('SimHei Bold'), local('sans-serif');
  font-weight: bold;
  font-style: normal;
  font-display: swap;
}

.new-lobby-container {
  width: 100vw;
  min-height: 100vh;
  background: url('@/assets/images/bg.jpg') no-repeat center center;
  background-size: cover;
  background-attachment: fixed;
  position: relative;
  font-family: "ChillRoundGothic", sans-serif !important;
}
.new-lobby-container::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(232, 218, 197, 0.6);
  z-index: 1;
}
.new-lobby-container > * {
  position: relative;
  z-index: 10;
}

/* 核心修改：顶部菜单栏调窄（padding从12px 0改为6px 0） */
.top-bar {
  background: rgba(224, 199, 172, 0.9);
  border-bottom: 3px solid #915C39;
  padding: 6px 0 !important; /* 调窄高度，从12px改为6px */
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}
.top-bar-inner {
  max-width: 1400px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
}
/* 微调标题字体大小，适配窄菜单栏（可选，保持28px也可以） */
.game-logo {
  font-size: 26px; /* 从28px小幅缩小，适配窄栏，也可改回28px */
  color: #915C39;
  margin: 0;
  text-shadow: 1px 1px 2px rgba(255,255,255,0.8);
}
.user-operations {
  display: flex;
  align-items: center;
  gap: 20px;
}
.user-profile {
  display: flex;
  align-items: center;
  gap: 12px;
}
.user-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 20px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2), inset 0 -2px 4px rgba(0,0,0,0.1);
  border: 2px solid #915C39;
  background: linear-gradient(160deg, #E8D0B0 0%, #D2B48C 50%, #915C39 100%);
}
.user-meta {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.user-name {
  font-size: 16px;
  font-weight: bold;
  color: #915C39;
  text-shadow: 1px 1px 1px rgba(255,255,255,0.8);
}
.user-account {
  font-size: 12px;
  color: #8C6B48;
  text-shadow: 1px 1px 1px rgba(255,255,255,0.8);
}
.btn-group {
  display: flex;
  gap: 10px;
  /* 新增：让按钮容器垂直居中偏下 */
  align-items: flex-end;
  padding-bottom: 4px;
}

/* 1. 文本按钮纵向拉满：上下padding拉到最大 */
.btn-personal {
  color: #915C39;
  font-size: 14px;
  text-shadow: 1px 1px 1px rgba(255,255,255,0.8);
  position: relative;
  transition: all 0.3s ease;
  padding: 30px 16px !important; /* 纵向拉满关键：超大上下padding */
  --el-button-text-color: #915C39 !important;
  /* 新增：退出按钮位置微调 - 向下偏移 */
  transform: translateY(2px);
}
.btn-personal:hover {
  color: #7D4E2F;
  --el-button-text-color: #7D4E2F !important;
  text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
}
.btn-personal::after {
  content: '';
  position: absolute;
  bottom: -2px;
  left: 16px;
  width: calc(100% - 32px);
  height: 3px;
  background: linear-gradient(90deg, #E0C7AD 0%, #915C39 50%, #7D4E2F 100%);
  box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  opacity: 0;
  transition: opacity 0.3s ease;
}
.btn-personal:hover::after {
  opacity: 1;
}

/* 2. 退出登录按钮：适量缩小尺寸（核心修改） */
.btn-logout {
  background: linear-gradient(150deg, #A67A53 0%, #915C39 40%, #7D4E2F 100%) !important;
  border: none !important;
  border-radius: 6px !important;
  padding: 20px 20px !important; /* 从40px 24px 缩小为12px 20px，适度缩小 */
  min-width: 100px !important; /* 从120px 缩小为100px */
  color: #fff !important;
  font-size: 14px !important;
  box-shadow:
      0 4px 0 #6B3F22, /* 阴影同步缩小，保持比例 */
      0 6px 10px rgba(0,0,0,0.2),
      inset 0 2px 0 rgba(255,255,255,0.3);
  transition: all 0.2s ease;
  text-align: center;
  --el-button-primary-bg-color: transparent !important;
  --el-button-primary-border-color: transparent !important;
  display: flex; /* 确保按钮内文字居中 */
  align-items: center;
  justify-content: center;

  transform: translateY(-10px);
}
.btn-logout:hover {
  background: linear-gradient(150deg, #B58A65 0%, #915C39 40%, #855838 100%) !important;
  box-shadow:
      0 6px 0 #6B3F22,
      0 8px 12px rgba(0,0,0,0.25),
      inset 0 2px 0 rgba(255,255,255,0.4);
  transform: translateY(2px); /* 悬浮时抵消部分下移，保持交互效果 */
}
.btn-logout:active {
  box-shadow:
      0 2px 0 #6B3F22,
      0 4px 6px rgba(0,0,0,0.2),
      inset 0 2px 0 rgba(0,0,0,0.1);
  transform: translateY(6px); /* 按下时位移同步调整 */
}

.main-content {
  max-width: 1400px;
  margin: 0 auto;
  padding: 40px 30px;
  display: flex;
  flex-direction: column;
  gap: 40px;
}
.operation-panel {
  border-radius: 20px;
  border: 3px solid #915C39;
  padding: 30px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15), inset 0 1px 0 rgba(255,255,255,0.5);
  background: rgba(248, 240, 228, 0.85);
}
.panel-title {
  font-size: 24px;
  color: #915C39;
  margin: 0 0 25px 0;
  padding-left: 10px;
  border-left: 4px solid #915C39;
  text-shadow: 1px 1px 2px rgba(255,255,255,0.8);
}
.operation-grid {
  display: flex;
  justify-content: space-between;
  gap: 40px; /* 核心修改：增大卡片之间的间距，从25px改为40px */
  flex-wrap: wrap;
}

/* 功能卡片按钮：增强版3D样式（核心修改） */
.operation-card {
  width: 370px;
  flex: none;
  padding: 0 !important;
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1); /* 更丝滑的过渡曲线 */
  /* 增强3D阴影：多层投影+内发光，模拟真实立体质感 */
  box-shadow:
      0 12px 0 2px #805030, /* 深色底影（模拟底座） */
      0 16px 24px rgba(0,0,0,0.2), /* 模糊投影 */
      inset 0 3px 0 rgba(255,255,255,0.7), /* 顶部内高光 */
      inset 0 -3px 0 rgba(0,0,0,0.15); /* 底部内阴影 */
  border: 3px solid #A67A53; /* 加粗边框，增强轮廓 */
  position: relative;
  height: 400px;
  overflow: hidden;
  /* 新增：轻微的立体倒角 */
  transform: perspective(1000px) rotateX(2deg);
}
.operation-card:hover {
  transform: perspective(1000px) rotateX(2deg) translateY(-10px); /* 悬浮上移+保持倒角 */
  box-shadow:
      0 16px 0 2px #805030, /* 底影上移 */
      0 20px 30px rgba(0,0,0,0.25), /* 投影放大 */
      inset 0 3px 0 rgba(255,255,255,0.8), /* 高光更亮 */
      inset 0 -3px 0 rgba(0,0,0,0.2);
}
.operation-card:active {
  transform: perspective(1000px) rotateX(2deg) translateY(4px); /* 按下下沉 */
  box-shadow:
      0 8px 0 2px #805030, /* 底影缩短 */
      0 12px 18px rgba(0,0,0,0.18), /* 投影缩小 */
      inset 0 2px 0 rgba(0,0,0,0.2), /* 内阴影加深 */
      inset 0 -2px 0 rgba(255,255,255,0.5);
}

/* 快速匹配卡片：偏向正红的红色渐变（保留你调整后的配色） */
.operation-card.card-match {
  background: linear-gradient(150deg, #faeeac 0%, #f2d76d 40%, #fce481 100%);
  /* 新增：红色系专属边框，增强质感 */
  border-color: #ebdb43;
}

/* 匹配中状态：改变背景色和边框色 */
.operation-card.card-match.matching {
  background: linear-gradient(150deg, #ffcccc 0%, #ff9999 40%, #ffb3b3 100%);
  border-color: #ff6666;
  animation: pulse 1.5s ease-in-out infinite;
}

/* 匹配中动画效果 */
@keyframes pulse {
  0%, 100% {
    box-shadow:
        0 12px 0 2px #805030,
        0 16px 24px rgba(0,0,0,0.2),
        inset 0 3px 0 rgba(255,255,255,0.7),
        inset 0 -3px 0 rgba(0,0,0,0.15);
  }
  50% {
    box-shadow:
        0 12px 0 2px #805030,
        0 16px 30px rgba(255, 102, 102, 0.4),
        inset 0 3px 0 rgba(255,255,255,0.7),
        inset 0 -3px 0 rgba(0,0,0,0.15);
  }
}

/* 创建房间卡片：保留原有配色 + 增强3D边框 */
.operation-card.card-create {
  background: linear-gradient(150deg, #fce5a6 0%, #fcbd5e 50%, #f2d08a 100%);
  /* 新增：金色系专属边框，增强质感 */
  border-color: #E0B050;
}

/* 加入房间卡片：饱和度稍高的淡橙色（保留你调整后的配色） */
.operation-card.card-join {
  background: linear-gradient(150deg, #f9d3a8 0%, #f4b474 40%, #fcd4ac 100%);
  /* 新增：橙色系专属边框，增强质感 */
  border-color: #E0A060;
}


/* 卡片背景图片：居中显示 + 适配尺寸（核心修改） */
.card-bg-img {
  position: absolute;
  top: 50%; /* 垂直居中 */
  left: 50%; /* 水平居中 */
  transform: translate(-50%, -50%); /* 修正居中偏移 */
  width: 85%; /* 保持原有宽度比例 */
  height: 85%; /* 保持原有高度比例 */
  object-fit: cover; /* 铺满且保持比例，裁剪多余部分 */
  opacity: 0.85; /* 降低透明度，避免遮挡文字 */
  z-index: 1;
}

/* 文字区域：固定在卡片底部，不被图片遮挡 */
.card-text-area {
  position: relative;
  z-index: 2; /* 层级高于图片，保证文字可见 */
  margin-top: auto; /* 自动顶到卡片底部 */
  width: 100%;
  padding: 20px;
  background: rgba(248, 240, 228, 0.9); /* 半透明背景，增强文字可读性 */
  border-top: 2px solid #915C39;
  text-align: center;
}

.card-title {
  font-size: 22px;
  font-weight: bold;
  color: #915C39;
  text-shadow: 1px 1px 2px rgba(255,255,255,0.8);
  margin-bottom: 8px;
}
.card-desc {
  font-size: 15px;
  color: #8C6B48;
  text-align: center;
  text-shadow: 1px 1px 1px rgba(255,255,255,0.8);
}

.join-room-panel {
  border-radius: 20px;
  border: 3px solid #915C39;
  padding: 30px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15), inset 0 1px 0 rgba(255,255,255,0.5);
  background: rgba(248, 240, 228, 0.85);
  display: flex;
  flex-direction: column;
  gap: 30px;
}
.join-room-input-area {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 20px;
  border-bottom: 2px solid #915C39;
  flex-wrap: wrap;
  gap: 15px;
}
.join-room-title {
  font-size: 22px;
  color: #915C39;
  margin: 0;
  text-shadow: 1px 1px 2px rgba(255,255,255,0.8);
}
.room-id-input-wrapper {
  display: flex;
  gap: 10px;
  align-items: center;
  flex: 1;
  max-width: 600px;
}
.small-room-input {
  flex: 1;
  min-width: 200px;
  border-radius: 8px;
  border: 2px solid #915C39;
  padding: 8px 12px;
  font-size: 14px;
  background: linear-gradient(180deg, #fff 0%, #F8F0E4 100%);
  color: #8C6B48;
  box-shadow: inset 0 2px 4px rgba(0,0,0,0.05), 0 1px 0 rgba(255,255,255,0.8);
  transition: all 0.3s ease;
}
.small-room-input:focus {
  border-color: #7D4E2F;
  box-shadow: inset 0 2px 4px rgba(0,0,0,0.1), 0 0 0 2px rgba(145,92,57,0.1);
  outline: none;
}

/* 4. 加入按钮纵向拉满：上下padding拉到最大 */
.small-join-btn {
  background: linear-gradient(150deg, #A67A53 0%, #915C39 40%, #7D4E2F 100%) !important;
  border: none !important;
  border-radius: 8px !important;
  padding: 35px 20px !important; /* 纵向拉满关键：超大上下padding */
  min-width: 100px !important;
  font-size: 14px !important;
  color: #fff !important;
  box-shadow:
      0 5px 0 #6B3F22,
      0 7px 10px rgba(0,0,0,0.2),
      inset 0 2px 0 rgba(255,255,255,0.3);
  transition: all 0.2s ease;
  --el-button-primary-bg-color: transparent !important;
  --el-button-primary-border-color: transparent !important;
}
.small-join-btn:hover {
  background: linear-gradient(150deg, #B58A65 0%, #915C39 40%, #855838 100%) !important;
  box-shadow:
      0 7px 0 #6B3F22,
      0 9px 12px rgba(0,0,0,0.25),
      inset 0 2px 0 rgba(255,255,255,0.4);
  transform: translateY(-2px);
}
.small-join-btn:active {
  box-shadow:
      0 2px 0 #6B3F22,
      0 4px 6px rgba(0,0,0,0.2),
      inset 0 2px 0 rgba(0,0,0,0.1);
  transform: translateY(3px);
}

/* 5. 返回按钮纵向拉满：上下padding拉到最大 */
.back-btn {
  color: #915C39 !important;
  font-size: 14px !important;
  position: relative;
  transition: all 0.3s ease;
  padding: 30px 16px !important; /* 纵向拉满关键：超大上下padding */
  --el-button-text-color: #915C39 !important;
}
.back-btn:hover {
  color: #7D4E2F !important;
  --el-button-text-color: #7D4E2F !important;
}
.back-btn::after {
  content: '';
  position: absolute;
  bottom: -2px;
  left: 16px;
  width: calc(100% - 32px);
  height: 3px;
  background: linear-gradient(90deg, #E0C7AD 0%, #915C39 50%, #7D4E2F 100%);
  box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  opacity: 0;
  transition: opacity 0.3s ease;
}
.back-btn:hover::after {
  opacity: 1;
}

.join-room-list-area {
  width: 100%;
}
.room-list-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
  margin-top: 20px;
}
.room-card {
  border-radius: 12px !important;
  border: 2px solid #915C39 !important;
  overflow: hidden;
  transition: all 0.3s ease;
  background: linear-gradient(180deg, #E8D6BC 0%, #E0C7AD 100%) !important;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1), inset 0 1px 0 rgba(255,255,255,0.6) !important;
  --el-card-bg-color: transparent !important;
}
.room-card:hover {
  transform: translateY(-5px);
  background: linear-gradient(180deg, #F2E4D0 0%, #D2B48C 100%) !important;
  box-shadow: 0 8px 15px rgba(0,0,0,0.15), inset 0 1px 0 rgba(255,255,255,0.7) !important;
  border-color: #7D4E2F !important;
}
.room-card-inner {
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 15px;
}
.room-info {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.room-number {
  font-size: 18px;
  font-weight: bold;
  color: #915C39;
  text-shadow: 1px 1px 1px rgba(255,255,255,0.8);
}
.user-count-tag {
  border-radius: 10px !important;
  background: linear-gradient(150deg, #A67A53 0%, #915C39 100%) !important;
  border: none !important;
  color: #fff !important;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  padding: 4px 12px !important;
}
.room-status {
  font-size: 14px;
  color: #8C6B48;
  text-shadow: 1px 1px 1px rgba(255,255,255,0.8);
}

/* 6. 进入房间按钮纵向拉满：上下padding拉到最大 */
.enter-room-btn {
  width: 100% !important;
  background: linear-gradient(150deg, #A67A53 0%, #915C39 40%, #7D4E2F 100%) !important;
  border: none !important;
  border-radius: 6px !important;
  padding: 30px 0 !important; /* 纵向拉满关键：超大上下padding */
  color: #fff !important;
  font-size: 14px !important;
  box-shadow:
      0 5px 0 #6B3F22,
      0 7px 10px rgba(0,0,0,0.15),
      inset 0 2px 0 rgba(255,255,255,0.3);
  transition: all 0.2s ease;
  --el-button-primary-bg-color: transparent !important;
  --el-button-primary-border-color: transparent !important;
}
.enter-room-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow:
      0 7px 0 #6B3F22,
      0 9px 12px rgba(0,0,0,0.2),
      inset 0 2px 0 rgba(255,255,255,0.4);
}
.enter-room-btn:active:not(:disabled) {
  transform: translateY(3px);
  box-shadow:
      0 2px 0 #6B3F22,
      0 4px 6px rgba(0,0,0,0.15),
      inset 0 2px 0 rgba(0,0,0,0.1);
}
.enter-room-btn:disabled {
  background: linear-gradient(150deg, #C8B8A8 0%, #B5A494 40%, #A39282 100%) !important;
  box-shadow: none !important;
  transform: none !important;
  cursor: not-allowed;
}

.empty-state {
  padding: 40px 0;
  --el-empty-text-color: #915C39;
  --el-empty-font-size: 16px;
  text-shadow: 1px 1px 2px rgba(255,255,255,0.8);
}

*:not([class*="el-icon-"]):not(svg):not(path):not(rect):not(text) {
  font-family: "ChillRoundGothic", sans-serif !important;
}
:deep(.el-input__inner),
:deep(.el-button__text),
:deep(.el-tag),
:deep(.el-empty__description) {
  font-family: "ChillRoundGothic", sans-serif !important;
}

/* 响应式部分：调整功能卡片样式 */
@media (max-width: 992px) {
  .operation-grid {
    flex-direction: column;
    gap: 20px;
    /* 响应式下让卡片居中 */
    align-items: center;
  }
  .operation-card {
    width: 80%; /* 响应式下改为百分比宽度 */
    max-width: 300px;
    height: 350px; /* 响应式调整高度 */
  }
  .top-bar-inner {
    padding: 0 20px;
  }
  .game-logo {
    font-size: 24px; /* 小屏标题再缩小一点 */
  }
  .user-meta {
    display: none;
  }
  .join-room-input-area {
    flex-direction: column;
    align-items: flex-start;
  }
  .room-id-input-wrapper {
    width: 100%;
    max-width: unset;
  }
  .small-room-input {
    min-width: unset;
  }
  .room-list-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .main-content {
    padding: 20px 15px;
    gap: 25px;
  }
  .operation-panel, .join-room-panel {
    padding: 20px 15px;
  }
  .panel-title {
    font-size: 20px;
  }
  .operation-card {
    width: 90%; /* 小屏进一步调整宽度 */
    height: 300px; /* 小屏进一步调整高度 */
  }
  .card-title {
    font-size: 20px;
  }
  .card-desc {
    font-size: 14px;
  }
  .top-bar-inner {
    flex-direction: column;
    gap: 10px;
    align-items: flex-start;
  }
  .user-operations {
    width: 100%;
    justify-content: space-between;
  }
  .btn-logout {
    min-width: unset !important;
    width: 100%;
    padding: 10px 16px !important; /* 小屏进一步适配 */
    /* 小屏下取消下移 */
    transform: translateY(0);
  }
}
</style>