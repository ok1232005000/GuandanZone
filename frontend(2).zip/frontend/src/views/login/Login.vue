<template>
  <div class="login-page">
    <div
        class="title-banner-container"
        :style="{
        paddingTop: activeTab === 'login' ? '26%' : '20%',
        top: activeTab === 'login' ? '8%' : '2%'
      }"
    ></div>

    <div class="login-container">
      <el-tabs v-model="activeTab" type="card" class="login-tabs">
        <el-tab-pane label="玩家登录" name="login">
          <el-form
              :model="loginForm"
              class="login-form"
              label-width="80px"
              :rules="loginRules"
              ref="loginFormRef"
          >
            <el-form-item label="6位账号" prop="username">
              <el-input
                  v-model="loginForm.username"
                  placeholder="请输入系统分配的6位数字账号"
                  :prefix-icon="User"
                  maxlength="6"
                  show-word-limit
                  class="game-input"
              />
            </el-form-item>
            <el-form-item label="登录密码" prop="password">
              <el-input
                  v-model="loginForm.password"
                  type="password"
                  placeholder="请输入密码（10位内）"
                  :prefix-icon="Lock"
                  maxlength="10"
                  show-word-limit
                  class="game-input"
              />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" size="large" round class="login-btn" @click="handleLogin">
                <template #icon><User /></template>
                登录游戏
              </el-button>
              <el-button type="text" class="forget-pwd">忘记密码？</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>

        <el-tab-pane label="玩家注册" name="register">
          <el-form
              :model="registerForm"
              class="login-form"
              label-width="80px"
              :rules="registerRules"
              ref="registerFormRef"
          >
            <el-form-item label="游戏昵称" prop="nickname">
              <el-input
                  v-model="registerForm.nickname"
                  placeholder="请输入昵称（显示用）"
                  :prefix-icon="Avatar"
                  maxlength="10"
                  show-word-limit
                  class="game-input"
              />
              <div class="form-tip">✓ 昵称可输入字母/汉字/数字，最多10位</div>
            </el-form-item>
            <el-form-item label="分配账号" style="margin-top: 12px;">
              <el-input
                  v-model="registerForm.username"
                  placeholder="点击下方按钮生成6位账号"
                  :prefix-icon="Key"
                  readonly
                  class="game-input readonly-input"
              />
              <el-button type="primary" plain size="small" @click="generateRandomAccount" class="gen-account-btn">
                <template #icon><Key /></template>
                生成账号
              </el-button>
            </el-form-item>
            <el-form-item label="设置密码" prop="password">
              <el-input
                  v-model="registerForm.password"
                  type="password"
                  placeholder="请设置登录密码"
                  :prefix-icon="Lock"
                  maxlength="10"
                  show-word-limit
                  class="game-input"
              />
              <div class="form-tip">✓ 密码仅支持字母/数字，最多10位</div>
            </el-form-item>
            <el-form-item label="确认密码" prop="confirmPwd">
              <el-input
                  v-model="registerForm.confirmPwd"
                  type="password"
                  placeholder="请再次输入密码"
                  :prefix-icon="Lock"
                  maxlength="10"
                  show-word-limit
                  class="game-input"
              />
            </el-form-item>
            <el-form-item>
              <el-button type="success" size="large" round class="register-btn" @click="handleRegister">
                <template #icon><Avatar /></template>
                注册账号
              </el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { User, Lock, Avatar, Key } from '@element-plus/icons-vue'
import { login, register } from '../../api/auth'

const router = useRouter()
const activeTab = ref('login')
const loginFormRef = ref(null)
const registerFormRef = ref(null)

const loginForm = reactive({ username: '', password: '' })
const registerForm = reactive({ nickname: '', username: '', password: '', confirmPwd: '' })

const loginRules = reactive({
  username: [
    { required: true, message: '请输入6位数字账号', trigger: 'blur' },
    { pattern: /^\d{6}$/, message: '账号必须是6位纯数字', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { max: 10, message: '密码长度不能超过10位', trigger: 'blur' },
    { pattern: /^[a-zA-Z0-9]+$/, message: '密码只能包含字母和数字', trigger: 'blur' }
  ]
})

const registerRules = reactive({
  nickname: [
    { required: true, message: '请输入用户昵称', trigger: 'blur' },
    { max: 10, message: '昵称长度不能超过10位', trigger: 'blur' },
    { pattern: /^[a-zA-Z0-9\u4e00-\u9fa5]+$/, message: '昵称只能包含字母、数字、汉字', trigger: 'blur' }
  ],
  username: [
    { required: true, message: '请点击生成6位数字账号', trigger: 'blur' },
    { pattern: /^\d{6}$/, message: '账号必须是6位纯数字', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请设置密码', trigger: 'blur' },
    { max: 10, message: '密码长度不能超过10位', trigger: 'blur' },
    { pattern: /^[a-zA-Z0-9]+$/, message: '密码只能包含字母和数字，不能含符号', trigger: 'blur' }
  ],
  confirmPwd: [
    { required: true, message: '请确认密码', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        value !== registerForm.password ? callback(new Error('两次密码输入不一致')) : callback()
      },
      trigger: 'blur'
    }
  ]
})

const generateRandomAccount = () => {
  const randomNum = Math.floor(100000 + Math.random() * 900000)
  registerForm.username = randomNum.toString()
  ElMessage.success(`已生成6位账号：${randomNum}`)
}

const generateAvatar = (nickname) => {
  const colors = ['#8B0000', '#1A237E', '#D4AF37', '#006400', '#2F4F4F'];
  const randomColor = colors[Math.floor(Math.random() * colors.length)];
  const firstChar = nickname?.charAt(0)?.toUpperCase() || '掼';
  const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><rect width="64" height="64" fill="${randomColor}" rx="8"/><text x="32" y="40" font-size="24" text-anchor="middle" fill="#fff">${firstChar}</text></svg>`;
  const encodedSvg = btoa(unescape(encodeURIComponent(svgContent)));
  return { bgColor: randomColor, text: firstChar, avatarUrl: `data:text/svg+xml;base64,${encodedSvg}` }
}

const handleLogin = () => {
  loginFormRef.value.validate((valid) => {
    if (!valid) return
    login(loginForm)
        .then(response => {
          localStorage.setItem('isLogin', 'true')
          localStorage.setItem('token', response.token)
          localStorage.setItem('username', response.username)
          localStorage.setItem('nickname', response.nickname || '掼蛋玩家')
          localStorage.setItem('userInfo', JSON.stringify({
            id: response.userId, username: response.username, nickname: response.nickname, avatar: response.avatar
          }))

          sessionStorage.setItem('isLogin', 'true')
          sessionStorage.setItem('token', response.token)
          sessionStorage.setItem('username', response.username)
          sessionStorage.setItem('nickname', response.nickname || '掼蛋玩家')
          sessionStorage.setItem('userInfo', JSON.stringify({
            id: response.userId, username: response.username, nickname: response.nickname, avatar: response.avatar
          }))

          ElMessage.success('登录成功！即将进入游戏大厅')
          setTimeout(() => router.push('/lobby'), 1000)
        })
        .catch(error => {
          console.error('登录失败:', error)
          ElMessage.error('登录失败，请检查账号和密码')
        })
  })
}

const handleRegister = () => {
  registerFormRef.value.validate((valid) => {
    if (!valid) return

    const avatarInfo = generateAvatar(registerForm.nickname)
    const registerData = {
      nickname: registerForm.nickname,
      username: registerForm.username,
      password: registerForm.password,
      avatar: avatarInfo.avatarUrl
    }
    register(registerData)
        .then(response => {
          ElMessage.success(`注册成功！你的6位账号是：${response.username}，请牢记`)

          // 注册成功后不自动登录：切回登录页，让用户手动登录
          activeTab.value = 'login'
          loginForm.username = response.username
          loginForm.password = ''

          registerForm.nickname = ''
          registerForm.username = ''
          registerForm.password = ''
          registerForm.confirmPwd = ''
        })
        .catch(error => {
          console.error('注册失败:', error)
          ElMessage.error('注册失败，请稍后重试')
        })
  })
}
</script>

<style scoped>
/* ========== 字体核心修复：路径规范化+兼容性优化 ========== */
@font-face {
  font-family: "ChillRoundGothic"; /* 名称统一，不可修改 */
  src:
      url('@/assets/fonts/ChillRoundGothic_Heavy.ttf') format('truetype'), /* 优先加载TTF */
      local('Microsoft YaHei'), /*  fallback：系统字体（防止文件缺失） */
      local('SimHei'),
      local('sans-serif');
  font-weight: normal; /* 常规字重 */
  font-style: normal;
  font-display: swap; /* 优化加载体验，避免文字闪烁 */
}

/* 粗体字重（若有Bold文件则使用，没有则删除此段） */
@font-face {
  font-family: "ChillRoundGothic"; /* 名称必须与上面一致 */
  src:
      url('@/assets/fonts/ChillRoundGothic_Heavy.ttf') format('truetype'),
      local('Microsoft YaHei Bold'),
      local('SimHei Bold'),
      local('sans-serif');
  font-weight: bold; /* 粗体字重 */
  font-style: normal;
  font-display: swap;
}

.login-page {
  width: 100vw;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background:
      linear-gradient(rgba(44, 14, 0, 0.6), rgba(44, 14, 0, 0.6)), /* 暖棕色蒙版，突出按钮 */
      #d6ccc2 radial-gradient(circle, #e3d5ca 0%, #d5bdaf 100%); /* 原有径向渐变 */
  background-image:
      url('@/assets/images/bg.jpg'), /* 绘画风风景背景图 */
      linear-gradient(rgba(44, 14, 0, 0.6), rgba(44, 14, 0, 0.6)),
      radial-gradient(circle, #e3d5ca 0%, #d5bdaf 100%);
  background-size: cover; /* 背景图覆盖整个页面 */
  background-position: center; /* 背景图居中 */
  background-attachment: fixed; /* 固定背景不滚动 */
  background-blend-mode: overlay; /* 叠加模式，让背景和渐变融合 */
  position: relative;
}

.title-banner-container {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  width: 560px;
  height: auto;
  background: url('@/assets/images/title_bg.png') no-repeat center;
  background-size: 80% auto;
  z-index: 999;
  pointer-events: none;
  filter: saturate(0.85) brightness(1.02) contrast(1);
}

.login-container {
  width: 480px;
  padding: 30px 40px;
  background: linear-gradient(to bottom, #f5e8d3, #e8d4b8);
  border-radius: 16px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
  border: 2px solid #c19a6b;
  margin-top: 120px;
  position: relative;
  z-index: 10;
  /* 新增：轻微半透明，透出背景但不影响表单可读性 */
  opacity: 0.98;
}

/* ========== 字体引用：确保所有文字都使用自定义字体 ========== */
*:not([class*="el-icon-"]):not(svg):not(path):not(rect):not(text) {
  font-family: "ChillRoundGothic", sans-serif !important;
}

/* 单独强化关键元素（防止被Element Plus默认样式覆盖） */
.game-title,
.form-tip,
.forget-pwd,
:deep(.el-tabs__item),
:deep(.el-form-item__label),
:deep(.el-input__inner),
:deep(.el-button__text),
:deep(.el-input__placeholder),
:deep(.el-message__content) {
  font-family: "ChillRoundGothic", sans-serif !important;
  font-weight: normal !important; /* 统一字重，避免冲突 */
}

/* ========== 优化按钮样式：添加细边框，增强和背景的区分度 ========== */
.login-btn, .register-btn {
  border: 1px solid rgba(255,255,255,0.4) !important; /* 白色细边框，突出按钮 */
}
.gen-account-btn {
  border: 1px solid rgba(139, 69, 19, 0.5) !important;
}

/* ========== 其他样式保持不变 ========== */
.login-tabs {
  margin-bottom: 25px;
  --el-tabs-card-bg-color: transparent;
  --el-tabs-active-color: #8B4513;
  --el-tabs-card-header-color: #5d4037;
  --el-tabs-card-border-color: #c19a6b;
  --el-tabs-card-header-font-size: 16px;
  position: relative;
  z-index: 20;
}
:deep(.el-tabs__item) {
  border-radius: 8px 8px 0 0 !important;
  margin: 0 4px !important;
  font-weight: 500;
  pointer-events: auto;
  z-index: 21;
}
:deep(.el-tabs__item.is-active) {
  background: linear-gradient(to bottom, #fff8e1, #ffe0b2) !important;
  border-bottom: 2px solid #8B4513 !important;
}

.login-form {
  padding: 0 10px;
}

.form-tip {
  font-size: 12px;
  color: #6d4c41;
  margin-top: 5px;
  line-height: 1.2;
}

:deep(.el-form-item__label) {
  font-size: 14px;
  color: #5d4037;
}

.game-input {
  --el-input-bg-color: rgba(255, 255, 255, 0.8);
  --el-input-border-color: #c19a6b;
  --el-input-hover-border-color: #8B4513;
  --el-input-text-color: #3e2723;
  border-radius: 8px;
  padding: 8px 12px;
  font-size: 14px;
}
.readonly-input {
  --el-input-bg-color: rgba(245, 240, 230, 0.9);
  cursor: not-allowed;
}

.gen-account-btn {
  margin-top: 8px;
  --el-button-primary-text-color: #8B4513;
  --el-button-primary-border-color: #c19a6b;
  --el-button-primary-bg-color: transparent;
  --el-button-primary-hover-bg-color: rgba(139, 69, 19, 0.1);
  font-size: 12px;
}

.login-btn, .register-btn {
  width: 100%;
  padding: 12px 0;
  font-size: 18px;
  margin-top: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  letter-spacing: 1px;
  position: relative;
  z-index: 30;
}
.login-btn {
  --el-button-primary-bg-color: linear-gradient(to right, #8B4513, #A1887F);
  --el-button-primary-border-color: #D4AF37;
  --el-button-primary-hover-bg-color: linear-gradient(to right, #A0522D, #BC8F8F);
  --el-button-primary-active-bg-color: #5D4037;
}
.register-btn {
  --el-button-success-bg-color: linear-gradient(to right, #006400, #558B2F);
  --el-button-success-border-color: #9CCC65;
  --el-button-success-hover-bg-color: linear-gradient(to right, #2E8B57, #66BB6A);
  --el-button-success-active-bg-color: #004D00;
}

.forget-pwd {
  float: right;
  color: #8B4513;
  font-size: 14px;
  margin: 8px 0 0 0;
  position: relative;
  z-index: 30;
}

@media (max-width: 500px) {
  .login-container {
    width: 90%;
    padding: 20px 25px;
    margin-top: 100px;
  }
  .title-banner-container {
    width: 95vw;
    background-size: 90% auto;
  }
}
</style>