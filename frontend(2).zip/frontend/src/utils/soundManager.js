/**
 * 音效管理器
 * 使用 Web Audio API 生成音效，无需外部文件
 */
class SoundManager {
  constructor() {
    this.audioContext = null
    this.enabled = true
    this.volume = 0.3 // 默认音量 30%
  }

  // 初始化音频上下文
  init() {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)()
    }
    if (this.audioContext.state === 'suspended') {
      this.audioContext.resume()
    }
  }

  // 播放音效
  play(type) {
    if (!this.enabled) return
    this.init()

    switch (type) {
      case 'click':
        this.playClick()
        break
      case 'match_success':
        this.playMatchSuccess()
        break
      case 'match_cancel':
        this.playMatchCancel()
        break
      case 'game_start':
        this.playGameStart()
        break
      case 'victory':
        this.playVictory()
        break
      case 'defeat':
        this.playDefeat()
        break
      case 'play_card':
        this.playPlayCard()
        break
      case 'error':
        this.playError()
        break
      case 'notification':
        this.playNotification()
        break
    }
  }

  // 点击音效 - 短促的高频音
  playClick() {
    const osc = this.audioContext.createOscillator()
    const gain = this.audioContext.createGain()

    osc.connect(gain)
    gain.connect(this.audioContext.destination)

    osc.frequency.setValueAtTime(800, this.audioContext.currentTime)
    osc.frequency.exponentialRampToValueAtTime(400, this.audioContext.currentTime + 0.1)

    gain.gain.setValueAtTime(this.volume * 0.3, this.audioContext.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.1)

    osc.start(this.audioContext.currentTime)
    osc.stop(this.audioContext.currentTime + 0.1)
  }

  // 匹配成功音效 - 上升的三连音
  playMatchSuccess() {
    const notes = [523.25, 659.25, 783.99] // C5, E5, G5
    const now = this.audioContext.currentTime

    notes.forEach((freq, index) => {
      const osc = this.audioContext.createOscillator()
      const gain = this.audioContext.createGain()

      osc.connect(gain)
      gain.connect(this.audioContext.destination)

      osc.frequency.setValueAtTime(freq, now + index * 0.15)

      gain.gain.setValueAtTime(0, now + index * 0.15)
      gain.gain.linearRampToValueAtTime(this.volume * 0.4, now + index * 0.15 + 0.05)
      gain.gain.exponentialRampToValueAtTime(0.01, now + index * 0.15 + 0.3)

      osc.start(now + index * 0.15)
      osc.stop(now + index * 0.15 + 0.3)
    })
  }

  // 匹配取消音效 - 下降的音调
  playMatchCancel() {
    const osc = this.audioContext.createOscillator()
    const gain = this.audioContext.createGain()

    osc.connect(gain)
    gain.connect(this.audioContext.destination)

    osc.frequency.setValueAtTime(400, this.audioContext.currentTime)
    osc.frequency.exponentialRampToValueAtTime(200, this.audioContext.currentTime + 0.2)

    gain.gain.setValueAtTime(this.volume * 0.3, this.audioContext.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.2)

    osc.start(this.audioContext.currentTime)
    osc.stop(this.audioContext.currentTime + 0.2)
  }

  // 游戏开始音效 - 激昂的上升音
  playGameStart() {
    const notes = [523.25, 659.25, 783.99, 1046.50] // C5, E5, G5, C6
    const now = this.audioContext.currentTime

    notes.forEach((freq, index) => {
      const osc = this.audioContext.createOscillator()
      const gain = this.audioContext.createGain()

      osc.type = 'triangle'
      osc.connect(gain)
      gain.connect(this.audioContext.destination)

      osc.frequency.setValueAtTime(freq, now + index * 0.1)

      gain.gain.setValueAtTime(0, now + index * 0.1)
      gain.gain.linearRampToValueAtTime(this.volume * 0.3, now + index * 0.1 + 0.05)
      gain.gain.exponentialRampToValueAtTime(0.01, now + index * 0.1 + 0.4)

      osc.start(now + index * 0.1)
      osc.stop(now + index * 0.1 + 0.4)
    })
  }

  // 胜利音效 - 欢快的旋律
  playVictory() {
    const notes = [523.25, 659.25, 783.99, 1046.50, 783.99, 1046.50]
    const now = this.audioContext.currentTime

    notes.forEach((freq, index) => {
      const osc = this.audioContext.createOscillator()
      const gain = this.audioContext.createGain()

      osc.type = 'sine'
      osc.connect(gain)
      gain.connect(this.audioContext.destination)

      const startTime = now + index * 0.12
      osc.frequency.setValueAtTime(freq, startTime)

      gain.gain.setValueAtTime(0, startTime)
      gain.gain.linearRampToValueAtTime(this.volume * 0.4, startTime + 0.05)
      gain.gain.exponentialRampToValueAtTime(0.01, startTime + 0.25)

      osc.start(startTime)
      osc.stop(startTime + 0.25)
    })
  }

  // 失败音效 - 低沉的音调
  playDefeat() {
    const notes = [392, 349.23, 329.63, 293.66] // G4, F4, E4, D4
    const now = this.audioContext.currentTime

    notes.forEach((freq, index) => {
      const osc = this.audioContext.createOscillator()
      const gain = this.audioContext.createGain()

      osc.type = 'triangle'
      osc.connect(gain)
      gain.connect(this.audioContext.destination)

      const startTime = now + index * 0.2
      osc.frequency.setValueAtTime(freq, startTime)

      gain.gain.setValueAtTime(this.volume * 0.3, startTime)
      gain.gain.exponentialRampToValueAtTime(0.01, startTime + 0.4)

      osc.start(startTime)
      osc.stop(startTime + 0.4)
    })
  }

  // 出牌音效 - 轻脆的"嗒"声
  playPlayCard() {
    const osc = this.audioContext.createOscillator()
    const gain = this.audioContext.createGain()

    osc.connect(gain)
    gain.connect(this.audioContext.destination)

    osc.frequency.setValueAtTime(1200, this.audioContext.currentTime)
    osc.frequency.exponentialRampToValueAtTime(600, this.audioContext.currentTime + 0.05)

    gain.gain.setValueAtTime(this.volume * 0.2, this.audioContext.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.05)

    osc.start(this.audioContext.currentTime)
    osc.stop(this.audioContext.currentTime + 0.05)
  }

  // 错误音效 - 低频嗡鸣
  playError() {
    const osc = this.audioContext.createOscillator()
    const gain = this.audioContext.createGain()

    osc.type = 'sawtooth'
    osc.connect(gain)
    gain.connect(this.audioContext.destination)

    osc.frequency.setValueAtTime(150, this.audioContext.currentTime)
    osc.frequency.linearRampToValueAtTime(100, this.audioContext.currentTime + 0.15)

    gain.gain.setValueAtTime(this.volume * 0.2, this.audioContext.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.15)

    osc.start(this.audioContext.currentTime)
    osc.stop(this.audioContext.currentTime + 0.15)
  }

  // 通知音效 - 清脆的提示音
  playNotification() {
    const osc = this.audioContext.createOscillator()
    const gain = this.audioContext.createGain()

    osc.type = 'sine'
    osc.connect(gain)
    gain.connect(this.audioContext.destination)

    osc.frequency.setValueAtTime(880, this.audioContext.currentTime)

    gain.gain.setValueAtTime(this.volume * 0.3, this.audioContext.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.15)

    osc.start(this.audioContext.currentTime)
    osc.stop(this.audioContext.currentTime + 0.15)
  }

  // 设置音量
  setVolume(volume) {
    this.volume = Math.max(0, Math.min(1, volume))
  }

  // 开启音效
  enable() {
    this.enabled = true
  }

  // 关闭音效
  disable() {
    this.enabled = false
  }
}

// 创建单例
const soundManager = new SoundManager()

export default soundManager
