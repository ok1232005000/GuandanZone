/**
 * 掼蛋游戏路由配置 - 无动画版
 * 核心：移除所有过渡动画，直接跳转，强制组件重建
 */
import { createRouter, createWebHashHistory } from 'vue-router'
import { ElMessage } from 'element-plus'

// 同步导入组件，避免懒加载延迟
import Login from '../views/login/Login.vue'
import Lobby from '../views/lobby/Lobby.vue'
import PersonalHome from '../views/PersonalHome.vue'
import BattleView from '../views/BattleView.vue'

// 登录守卫：极简逻辑，立即执行
const loginGuard = (to, from, next) => {
    const isLogin = localStorage.getItem('isLogin')
    if (isLogin) {
        next()
    } else {
        next('/login')
        ElMessage.warning(`请先登录后再访问【${to.name}】页面！`)
    }
}

// 路由规则：完全移除transition动画meta
const routes = [
    { path: '/', redirect: '/login' },
    {
        path: '/login',
        name: '登录',
        component: Login // 无动画meta
    },
    {
        path: '/lobby',
        name: '游戏大厅',
        component: Lobby,
        beforeEnter: loginGuard
    },
    {
        path: '/personal-home',
        name: '个人主页',
        component: PersonalHome,
        beforeEnter: loginGuard
    },
    {
        path: '/battle',
        name: '游戏对战',
        component: BattleView,
        beforeEnter: loginGuard,
        props: (route) => ({
            roomId: route.query.roomId || '未知房间'
        })
    },
    { path: '/:pathMatch(.*)*', redirect: '/login' }
]

// 创建路由实例：hash模式，无滚动动画
const router = createRouter({
    history: createWebHashHistory(import.meta.env.BASE_URL),
    routes,
    // 滚动行为：立即回到顶部，无平滑动画
    scrollBehavior() {
        return { top: 0, behavior: 'instant' }
    }
})

// 全局后置钩子：仅设置标题，无其他逻辑
router.afterEach((to) => {
    document.title = `掼蛋游戏 - ${to.name || '登录'}`
})

// 错误捕获：立即提示，避免卡死
router.onError((err) => {
    console.error('路由错误：', err)
    ElMessage.error('页面加载失败，请重新进入！')
    router.replace('/login')
})

export default router