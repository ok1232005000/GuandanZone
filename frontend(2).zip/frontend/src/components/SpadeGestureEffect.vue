<template>
  <div v-if="visible" class="gesture-overlay" @click="triggerExplosion">
    <!-- 中央内容 -->
    <div class="center-content">
      <div class="loading-spinner"></div>
      <div class="text-main" :style="textStyle">Guandan Zone</div>
      <div class="text-sub">已等待 {{ waitTime }} 秒</div>
      <div class="gesture-tip">伸出食指 👆 控制光影方向，悬停2.5秒取消匹配</div>

      <!-- 取消匹配按钮 -->
      <div class="cancel-btn-wrapper">
        <button class="cancel-match-btn" @click.stop="handleCancelMatch">
          ✕ 取消匹配
        </button>
        <!-- 悬停进度圈 -->
        <svg v-if="hoverProgress > 0" class="hover-progress-ring" viewBox="0 0 100 100">
          <circle
            class="progress-ring-bg"
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="rgba(255, 255, 255, 0.2)"
            stroke-width="6"
          />
          <circle
            class="progress-ring-bar"
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="#fff"
            stroke-width="6"
            :stroke-dasharray="283"
            :stroke-dashoffset="283 - (283 * hoverProgress / 100)"
            transform="rotate(-90 50 50)"
          />
          <text
            x="50"
            y="50"
            text-anchor="middle"
            dy="7"
            fill="white"
            font-size="20"
            font-weight="bold"
          >
            {{ Math.ceil(hoverProgress) }}%
          </text>
        </svg>
      </div>
    </div>
    <!-- 粒子跟随效果 - 使用fixed定位跟随手指 -->
    <div class="particle-follower" :style="particleStyle"></div>
    <div class="particle-trail" :style="trailStyle"></div>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, watch, computed } from 'vue'

const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['complete', 'cancel'])

const waitTime = ref(0)
const fingerPos = ref({ x: 0.5, y: 0.5 })
const baseFingerPos = ref({ x: 0.5, y: 0.5 })
const hoverProgress = ref(0) // 悬停进度 0-100

let waitTimer = null
let hands = null
let camera = null
let gestureState = 'idle'
let lastFingerPos = { x: 0, y: 0 }
let hoverTimer = null // 悬停计时器
let isHoveringButton = false // 是否悬停在按钮上

// 文字阴影样式 - 更强烈的粒子阴影效果
const textStyle = computed(() => {
  const dx = (fingerPos.value.x - baseFingerPos.value.x) * 200
  const dy = (fingerPos.value.y - baseFingerPos.value.y) * 200
  const distance = Math.sqrt(dx * dx + dy * dy)
  const normalizedDx = distance > 0 ? (dx / distance) * 100 : 0
  const normalizedDy = distance > 0 ? (dy / distance) * 100 : 0
  const scale = 0.2 + (fingerPos.value.z || 0) * 3

  return {
    textShadow: `
      ${normalizedDx * scale}px ${normalizedDy * scale}px 2px rgba(255, 255, 255, 0.8),
      ${normalizedDx * 1.5 * scale}px ${normalizedDy * 1.5 * scale}px 6px rgba(255, 200, 100, 0.9),
      ${normalizedDx * 2 * scale}px ${normalizedDy * 2 * scale}px 12px rgba(255, 100, 50, 0.8),
      ${normalizedDx * 2.5 * scale}px ${normalizedDy * 2.5 * scale}px 20px rgba(220, 50, 50, 0.7),
      ${normalizedDx * 3 * scale}px ${normalizedDy * 3 * scale}px 35px rgba(180, 30, 30, 0.5),
      ${normalizedDx * 4 * scale}px ${normalizedDy * 4 * scale}px 60px rgba(140, 20, 20, 0.3)
    `
  }
})

// 粒子跟随样式
const particleStyle = computed(() => {
  const screenX = fingerPos.value.x * window.innerWidth
  const screenY = fingerPos.value.y * window.innerHeight
  const scale = 0.3 + (fingerPos.value.z || 0) * 4
  return {
    left: `${screenX}px`,
    top: `${screenY}px`,
    transform: `translate(-50%, -50%) scale(${scale})`
  }
})

// 拖尾效果样式
const trailStyle = computed(() => {
  const dx = (fingerPos.value.x - baseFingerPos.value.x) * 80
  const dy = (fingerPos.value.y - baseFingerPos.value.y) * 80
  const scale = 0.3 + (fingerPos.value.z || 0) * 3
  return {
    transform: `translate(${dx}px, ${dy}px) scale(${scale})`
  }
})

// ============ MediaPipe 手势跟踪 ============
async function initMediaPipe() {
  try {
    const { Hands } = await import('@mediapipe/hands')
    const { Camera } = await import('@mediapipe/camera_utils')

    hands = new Hands({
      locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
    })

    hands.setOptions({
      maxNumHands: 1,
      modelComplexity: 0,
      minDetectionConfidence: 0.6,
      minTrackingConfidence: 0.5,
      renderLandmarks: false
    })

    hands.onResults(onHandResults)

    const video = document.createElement('video')
    video.autoplay = true
    video.playsInline = true
    video.style.position = 'absolute'
    video.style.top = '-9999px'
    video.style.left = '-9999px'

    camera = new Camera(video, {
      onFrame: async () => {
        if (hands && video.readyState === 4) {
          await hands.send({ image: video })
        }
      },
      width: 320,
      height: 240,
      fps: 30
    })

    await camera.start()
  } catch (error) {
    console.error('MediaPipe初始化失败:', error)
  }
}

function onHandResults(results) {
  if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
    const landmarks = results.multiHandLandmarks[0]
    const indexTip = landmarks[8]

    // 翻转x轴以匹配镜像摄像头
    fingerPos.value = { x: 1 - indexTip.x, y: indexTip.y, z: indexTip.z || 0 }

    if (lastFingerPos.x === 0 && lastFingerPos.y === 0) {
      baseFingerPos.value = { x: 1 - indexTip.x, y: indexTip.y }
    }

    lastFingerPos = { x: 1 - indexTip.x, y: indexTip.y }

    // 检测是否悬停在取消按钮上
    checkButtonHover()
  }
}

// 检测悬停在按钮上
function checkButtonHover() {
  const buttonEl = document.querySelector('.cancel-match-btn')
  if (!buttonEl) {
    resetHover()
    return
  }

  const rect = buttonEl.getBoundingClientRect()
  const screenX = fingerPos.value.x * window.innerWidth
  const screenY = fingerPos.value.y * window.innerHeight

  // 检测小圆点是否在按钮范围内（扩大一点范围方便操作）
  const padding = 20
  const isOverButton =
    screenX >= rect.left - padding &&
    screenX <= rect.right + padding &&
    screenY >= rect.top - padding &&
    screenY <= rect.bottom + padding

  if (isOverButton) {
    if (!isHoveringButton) {
      // 开始悬停
      isHoveringButton = true
      startHoverTimer()
    }
  } else {
    if (isHoveringButton) {
      resetHover()
    }
  }
}

// 开始悬停计时
function startHoverTimer() {
  stopHoverTimer()
  hoverProgress.value = 0

  const duration = 2500 // 2.5秒
  const interval = 50 // 每50ms更新一次
  const steps = duration / interval
  let currentStep = 0

  hoverTimer = setInterval(() => {
    currentStep++
    hoverProgress.value = (currentStep / steps) * 100

    if (currentStep >= steps) {
      // 计时结束，触发点击
      stopHoverTimer()
      handleCancelMatch()
    }
  }, interval)
}

// 停止悬停计时
function stopHoverTimer() {
  if (hoverTimer) {
    clearInterval(hoverTimer)
    hoverTimer = null
  }
}

// 重置悬停状态
function resetHover() {
  isHoveringButton = false
  stopHoverTimer()
  hoverProgress.value = 0
}

// ============ 触发爆炸 ============
function triggerExplosion() {
  console.log('💥 触发爆炸！')
  gestureState = 'exploding'
  
  // 爆炸效果：文字放大+颜色变化
  const textEl = document.querySelector('.text-main')
  if (textEl) {
    textEl.style.transform = 'scale(1.5)'
    textEl.style.filter = 'brightness(2)'
  }
  
  setTimeout(() => {
    gestureState = 'returning'
    if (textEl) {
      textEl.style.transition = 'transform 0.5s ease-out, filter 0.5s ease-out'
      textEl.style.transform = 'scale(1)'
      textEl.style.filter = 'brightness(1)'
    }
    setTimeout(() => {
      gestureState = 'idle'
      if (textEl) {
        textEl.style.transition = 'text-shadow 0.1s ease-out, transform 0.1s ease-out'
      }
    }, 500)
  }, 300)
}

// ============ 取消匹配 ============
function handleCancelMatch() {
  console.log('❌ 用户取消匹配')
  resetHover()
  emit('cancel')
}

// ============ 定时器 ============
function startWaitTimer() {
  waitTime.value = 0
  waitTimer = setInterval(() => {
    waitTime.value++
  }, 1000)
}

function stopWaitTimer() {
  if (waitTimer) {
    clearInterval(waitTimer)
    waitTimer = null
  }
}

// ============ 监听显示状态 ============
watch(() => props.visible, async (newVal) => {
  console.log('🎯 SpadeGestureEffect visible changed:', newVal)
  if (newVal) {
    console.log('✅ 开始手势交互')
    fingerPos.value = { x: 0.5, y: 0.5 }
    baseFingerPos.value = { x: 0.5, y: 0.5 }
    lastFingerPos = { x: 0, y: 0 }
    hoverProgress.value = 0
    startWaitTimer()
    initMediaPipe().catch(err => {
      console.warn('⚠️ MediaPipe初始化失败:', err)
    })
  } else {
    console.log('❌ 关闭手势交互')
    stopWaitTimer()
    stopHoverTimer()
    if (camera) {
      await camera.stop()
      camera = null
    }
    hands = null
    waitTime.value = 0
    hoverProgress.value = 0
    gestureState = 'idle'
    fingerPos.value = { x: 0.5, y: 0.5 }
    isHoveringButton = false
  }
})

onMounted(() => {
  console.log('🔧 SpadeGestureEffect mounted')
})

onBeforeUnmount(() => {
  console.log('🔧 SpadeGestureEffect unmounted')
  stopWaitTimer()
  stopHoverTimer()
  if (camera) camera.stop().catch(console.error)
})
</script>

<style scoped>
.gesture-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.4);
  backdrop-filter: blur(3px);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: fadeIn 0.3s ease-out;
  cursor: pointer;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.center-content {
  position: relative;
  z-index: 10000;
  display: flex;
  flex-direction: column;
  align-items: center;
  pointer-events: none;
}

.loading-spinner {
  width: 50px;
  height: 50px;
  border: 3px solid rgba(183, 28, 28, 0.2);
  border-top-color: #D32F2F;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin: 0 auto 30px;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.text-main {
  font-size: 42px;
  font-weight: bold;
  color: #fff;
  margin-bottom: 25px;
  font-family: "ChillRoundGothic", Arial, sans-serif;
  transition: text-shadow 0.1s ease-out;
  pointer-events: none;
}

.text-sub {
  font-size: 18px;
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 30px;
}

.gesture-tip {
  font-size: 14px;
  color: rgba(255, 255, 255, 0.6);
  animation: pulse 2s ease-in-out infinite;
  margin-bottom: 30px;
}

@keyframes pulse {
  0%, 100% { opacity: 0.6; }
  50% { opacity: 1; }
}

/* 取消匹配按钮外层包装 */
.cancel-btn-wrapper {
  position: relative;
  margin-top: 20px;
  display: inline-block;
}

/* 取消匹配按钮 */
.cancel-match-btn {
  padding: 12px 30px;
  font-size: 16px;
  font-weight: bold;
  color: #fff;
  background: rgba(220, 50, 50, 0.8);
  border: 2px solid rgba(255, 100, 100, 0.8);
  border-radius: 25px;
  cursor: pointer;
  pointer-events: auto;
  transition: all 0.3s ease;
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
}

.cancel-match-btn:hover {
  background: rgba(255, 50, 50, 0.9);
  border-color: rgba(255, 150, 150, 1);
  transform: scale(1.05);
  box-shadow: 0 6px 20px rgba(255, 50, 50, 0.5);
}

.cancel-match-btn:active {
  transform: scale(0.95);
}

/* 悬停进度圈 */
.hover-progress-ring {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 120px;
  height: 120px;
  pointer-events: none;
  z-index: 10;
}

.progress-ring-bg {
  opacity: 0.3;
}

.progress-ring-bar {
  transition: stroke-dashoffset 0.05s linear;
  filter: drop-shadow(0 0 4px rgba(255, 255, 255, 0.8));
}

/* 粒子跟随效果 */
.particle-follower {
  position: fixed;
  width: 20px;
  height: 20px;
  background: radial-gradient(circle, rgba(255, 255, 255, 0.9) 0%, rgba(255, 200, 100, 0.6) 40%, rgba(255, 100, 50, 0.3) 70%, transparent 100%);
  border-radius: 50%;
  pointer-events: none;
  transform: translate(-50%, -50%);
  box-shadow:
    0 0 20px rgba(255, 200, 100, 0.8),
    0 0 40px rgba(255, 100, 50, 0.6),
    0 0 60px rgba(220, 50, 50, 0.4),
    0 0 80px rgba(180, 30, 30, 0.2);
  animation: particlePulse 0.5s ease-in-out infinite alternate;
  z-index: 10001;
}

.particle-trail {
  position: fixed;
  width: 60px;
  height: 60px;
  background: radial-gradient(circle, rgba(255, 255, 255, 0.3) 0%, rgba(255, 150, 0, 0.2) 50%, transparent 80%);
  border-radius: 50%;
  pointer-events: none;
  transform: translate(-50%, -50%);
  animation: trailFade 0.8s ease-out infinite;
  z-index: 10000;
}

@keyframes particlePulse {
  from {
    transform: translate(-50%, -50%) scale(1);
    opacity: 0.8;
  }
  to {
    transform: translate(-50%, -50%) scale(1.3);
    opacity: 1;
  }
}

@keyframes trailFade {
  0% {
    transform: translate(-50%, -50%) scale(1);
    opacity: 0.5;
  }
  100% {
    transform: translate(-50%, -50%) scale(1.5);
    opacity: 0;
  }
}

@media (max-width: 768px) {
  .text-main { font-size: 28px; }
  .text-sub { font-size: 14px; }
  .gesture-tip { font-size: 12px; }
}
</style>
