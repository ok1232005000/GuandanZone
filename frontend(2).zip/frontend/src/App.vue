<template>
  <!-- 根容器：仅保留基础布局，无动画 -->
  <div id="app">
    <router-view v-slot="{ Component, route }">
      <!-- 🔥 完全移除transition动画，直接渲染组件 -->
      <!-- 关键：用fullPath + 时间戳，强制每次跳转重建组件，杜绝缓存 -->
      <div v-if="Component" :key="route.fullPath + Date.now()">
        <component :is="Component" />
      </div>
      <!-- 加载兜底（无动画，仅纯文本提示） -->
      <div v-else class="loading">
        <p>正在进入{{ route.name || '页面' }}...</p>
      </div>
    </router-view>
  </div>
</template>

<script setup>
// 仅保留必要的全局样式和组件挂载
import 'element-plus/dist/index.css'
import { ElMessage, ElMessageBox } from 'element-plus'
import { provide } from 'vue'

// 全局挂载提示组件，避免异步导入延迟
provide('$message', ElMessage)
provide('$confirm', ElMessageBox.confirm)
// 直接挂载到window，确保所有页面能立即使用
window.$message = ElMessage
</script>

<style scoped>
/* 根容器：彻底放开滚动，无任何动画相关样式 */
#app {
  width: 100%;
  min-height: 100vh;
  margin: 0;
  padding: 0;
  font-family: "Microsoft YaHei", "PingFang SC", sans-serif;
  color: #333;
  /* 仅禁止横向滚动，纵向完全放开 */
  overflow-x: hidden;
  overflow-y: auto;
  /* 修复移动端滚动卡顿 */
  -webkit-overflow-scrolling: touch;
}

/* 加载提示：极简样式，无动画 */
.loading {
  width: 100%;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #409eff;
  font-size: 16px;
}
</style>

<!-- 全局样式：仅保留必要的滚动条和Element样式，无动画 -->
<style>
/* 全局滚动条优化 */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 3px; }
::-webkit-scrollbar-thumb { background: #c1c1c1; border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: #a8a8a8; }

/* Element Plus 基础样式统一 */
.el-button { font-family: "Microsoft YaHei", "PingFang SC", sans-serif; }
.el-card { border: none; box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.05); }
.el-input__wrapper { box-shadow: none; border-radius: 8px; }
.el-message { top: 20px; }
.el-message-box { border-radius: 10px; }
</style>