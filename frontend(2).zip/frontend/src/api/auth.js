import axiosInstance from './axiosInstance'

export const login = (params) => {
  return axiosInstance.post('/login', params)
}

export const register = (params) => {
  return axiosInstance.post('/register', params)
}

export const logout = () => {
  return axiosInstance.post('/user/logout')
}

export const changePassword = (params) => {
  return axiosInstance.post('/user/change-password', params)
}

export const checkUsername = (username) => {
  return axiosInstance.get('/user/check-username', { params: { username } })
}

export const getUserInfo = () => {
  return axiosInstance.get('/user/info')
}
