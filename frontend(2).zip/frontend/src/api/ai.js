import axiosInstance from './axiosInstance'

// AI聊天接口
export const chatWithAI = (message) => {
  return axiosInstance.post('/ai/chat', { message })
}
