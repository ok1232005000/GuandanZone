import { ElMessage } from 'element-plus';

// 动态获取WebSocket服务器URL
const getWebSocketURL = (playerId, token) => {
  const currentOrigin = window.location.origin
  if (currentOrigin.includes('localhost') || currentOrigin.includes('127.0.0.1')) {
    return `ws://localhost:8081/ws/game/${playerId}?token=${token}`
  }
  const url = new URL(currentOrigin)
  return `${url.protocol === 'https:' ? 'wss:' : 'ws:'}//${url.hostname}:8081/ws/game/${playerId}?token=${token}`
}

// WebSocket消息类型常量
export const WS_MESSAGE_TYPES = {
  // 客户端发送的消息类型
  PLAY_CARD: 'PLAY_CARD',
  JOIN_ROOM: 'JOIN_ROOM',
  HEARTBEAT: 'HEARTBEAT',
  RECONNECT: 'RECONNECT',
  START_GAME: 'START_GAME',
  GAME_OVER: 'GAME_OVER',
  SUGGEST_CARDS: 'SUGGEST_CARDS',
  CHAT_MESSAGE: 'CHAT_MESSAGE',
  
  // 服务器发送的消息类型
  GAME_START: 'GAME_START',
  GAME_END: 'GAME_END',
  PLAYER_ACTION: 'PLAYER_ACTION',
  PLAYER_DISCONNECT: 'PLAYER_DISCONNECT',
  RECONNECT_SUCCESS: 'RECONNECT_SUCCESS',
  TURN_CHANGE: 'TURN_CHANGE',
  SUGGEST_CARDS_SUCCESS: 'SUGGEST_CARDS_SUCCESS',
  ROOM_UPDATE: 'ROOM_UPDATE',
  JOIN_ROOM_SUCCESS: 'JOIN_ROOM_SUCCESS',
  TABLE_CLEAR: 'TABLE_CLEAR',
  ERROR: 'ERROR'
};

class WebSocketService {
  constructor() {
    this.socket = null;
    this.isConnected = false;
    this.playerId = null;
    this.roomId = null;
    this.token = null;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
    this.reconnectInterval = 3000;
    this.heartbeatInterval = 30000; // 30秒心跳
    this.heartbeatTimer = null;
    this.listeners = {};
    this.lastNotReadyToastAt = 0;
  }
  
  /**
   * 连接WebSocket服务器
   * @param {string} playerId - 玩家ID
   * @param {string} roomId - 房间ID（可选）
   * @param {string} token - JWT Token（可选，从localStorage或sessionStorage获取）
   */
  connect(playerId, roomId = null, token = null) {
    if (this.socket && this.isConnected) {
      console.log('WebSocket已连接');
      return;
    }
    
    this.playerId = playerId;
    this.roomId = roomId;
    
    // 获取JWT Token
    if (!token) {
      token = localStorage.getItem('token') || sessionStorage.getItem('token');
    }
    this.token = token;
    
    if (!token) {
      console.error('未找到JWT Token，无法连接WebSocket');
      ElMessage.error('未登录，请先登录');
      return;
    }
    
    const wsUrl = getWebSocketURL(playerId, token);
    console.log('尝试连接WebSocket:', wsUrl);
    
    try {
      this.socket = new WebSocket(wsUrl);
      
      this.socket.onopen = () => {
        console.log('WebSocket连接成功');
        this.isConnected = true;
        this.reconnectAttempts = 0;
        
        // 启动心跳检测
        this.startHeartbeat();
        
        // 加入房间（如果提供了房间ID）
        if (this.roomId) {
          console.log('发送加入房间请求:', this.roomId);
          this.joinRoom(this.roomId);
        }
        
        // 触发连接成功事件
        this.emit('connect');
      };
      
      this.socket.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          console.log('收到WebSocket消息:', message);
          
          // 触发对应类型的事件
          this.emit(message.type, message.data);
          
          // 同时触发通用事件（用于监听所有消息）
          if (message.type) {
            this.emit('message', { type: message.type, data: message.data });
          }
          
          // 特殊处理：心跳响应
          if (message.type === 'pong') {
            console.log('收到心跳响应');
          }
        } catch (error) {
          console.error('WebSocket消息解析失败:', error);
        }
      };
      
      this.socket.onclose = (event) => {
        console.log('WebSocket连接关闭, code:', event.code, 'reason:', event.reason);
        this.isConnected = false;
        
        // 停止心跳检测
        this.stopHeartbeat();
        
        // 触发连接关闭事件
        this.emit('disconnect');
        
        // 如果不是手动关闭，尝试重连
        if (event.code !== 1000) {
          this.attemptReconnect();
        }
      };
      
      this.socket.onerror = (error) => {
        console.error('WebSocket错误:', error);
        
        // 触发错误事件
        this.emit('error', error);
      };
    } catch (error) {
      console.error('WebSocket连接失败:', error);
      this.emit('error', error);
      
      // 尝试重连
      this.attemptReconnect();
    }
  }
  
  /**
   * 断开WebSocket连接
   */
  disconnect() {
    if (this.socket) {
      this.socket.close();
      this.socket = null;
      this.isConnected = false;
      
      // 停止心跳检测
      this.stopHeartbeat();
      
      // 清除玩家和房间信息
      this.playerId = null;
      this.roomId = null;
      
      console.log('WebSocket已手动断开');
    }
  }
  
  /**
   * 发送消息
   * @param {string} type - 消息类型
   * @param {Object} data - 消息数据
   */
  send(type, data = {}) {
    console.log('WebSocket.send调用 - type:', type, 'data:', data);
    console.log('WebSocket状态:', this.socket ? this.socket.readyState : 'null');
    
    if (!this.socket) {
      console.error('WebSocket未初始化，无法发送消息');
      ElMessage.error('网络未连接，请稍后重试');
      return false;
    }
    
    if (this.socket.readyState !== WebSocket.OPEN) {
      console.error('WebSocket未就绪，当前状态:', this.socket.readyState);
      const now = Date.now();
      if (this.socket.readyState === WebSocket.CONNECTING) {
        if (now - this.lastNotReadyToastAt > 1500) {
          ElMessage.info('网络连接中，请稍后…');
          this.lastNotReadyToastAt = now;
        }
      } else {
        if (now - this.lastNotReadyToastAt > 1500) {
          ElMessage.error('网络连接未就绪，请稍后重试');
          this.lastNotReadyToastAt = now;
        }
      }
      return false;
    }
    
    try {
      const message = {
        type,
        data
      };
      
      this.socket.send(JSON.stringify(message));
      console.log('发送WebSocket消息成功:', message);
      return true;
    } catch (error) {
      console.error('发送WebSocket消息失败:', error);
      ElMessage.error('消息发送失败');
      return false;
    }
  }
  
  /**
   * 加入房间
   * @param {string} roomId - 房间ID
   */
  joinRoom(roomId) {
    this.roomId = roomId;
    return this.send(WS_MESSAGE_TYPES.JOIN_ROOM, { roomId });
  }
  
  /**
   * 出牌
   * @param {Array<number>} cards - 要出的牌ID数组
   */
  playCard(cards) {
    return this.send(WS_MESSAGE_TYPES.PLAY_CARD, { cards });
  }
  
  /**
   * 发送心跳
   */
  sendHeartbeat() {
    return this.send(WS_MESSAGE_TYPES.HEARTBEAT, { timestamp: Date.now() });
  }
  
  /**
   * 请求重连
   */
  reconnect() {
    return this.send(WS_MESSAGE_TYPES.RECONNECT);
  }
  
  /**
   * 启动心跳检测
   */
  startHeartbeat() {
    // 停止之前的心跳检测
    this.stopHeartbeat();
    
    // 每30秒发送一次心跳
    this.heartbeatTimer = setInterval(() => {
      this.sendHeartbeat();
    }, this.heartbeatInterval);
  }
  
  /**
   * 停止心跳检测
   */
  stopHeartbeat() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }
  
  /**
   * 尝试重连
   */
  attemptReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('WebSocket重连失败，已达到最大重连次数');
      ElMessage.error('网络连接失败，请刷新页面重试');
      return;
    }
    
    this.reconnectAttempts++;
    console.log(`WebSocket尝试重连(${this.reconnectAttempts}/${this.maxReconnectAttempts})...`);
    
    // 延迟重连
    setTimeout(() => {
      this.connect(this.playerId, this.roomId);
    }, this.reconnectInterval);
  }
  
  /**
   * 注册事件监听器
   * @param {string} event - 事件类型
   * @param {Function} callback - 回调函数
   */
  on(event, callback) {
    if (!this.listeners[event]) {
      this.listeners[event] = [];
    }
    this.listeners[event].push(callback);
  }
  
  /**
   * 移除事件监听器
   * @param {string} event - 事件类型
   * @param {Function} callback - 回调函数
   */
  off(event, callback) {
    if (this.listeners[event]) {
      this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
    }
  }
  
  /**
   * 触发事件
   * @param {string} event - 事件类型
   * @param {*} data - 事件数据
   */
  emit(event, data) {
    if (this.listeners[event]) {
      this.listeners[event].forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error('事件处理函数执行失败:', error);
        }
      });
    }
  }
}

// 创建单例实例
const webSocketService = new WebSocketService();

export default webSocketService;