import { createApp } from 'vue'
import App from './App.vue'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
// 新增：导入路由时增加错误捕获，便于排查
import router from './router'
import '@/assets/styles/font.css'
// 1. 新增：路由加载错误捕获（排查BattleView加载失败的关键）
router.onError((err) => {
    console.error('路由加载失败：', err.message)
    // 如果是BattleView加载失败，直接提示路径问题
    if (err.message.includes('BattleView')) {
        alert('BattleView组件加载失败！请检查：1.文件路径 2.文件名大小写 3.组件语法')
    }
})

const app = createApp(App)
app.use(ElementPlus)

// 注册Element Plus图标（原逻辑不变）
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
    app.component(key, component)
}

// 2. 新增：路由注册后验证（确认路由是否成功挂载）
app.use(router).mount('#app')

// 验证：打印路由列表，确认/battle路由存在
console.log('已注册的路由列表：', router.getRoutes().map(route => route.path))